﻿
Public Class Form1
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim arr() As Integer = {13, 17, 22, 23, 34, 39, 42, 46, 66, 71, 74, 83, 91, 94, 95}
        Dim i = 0
        Dim j = 0
        Dim count = 0
        Dim filerd As System.IO.FileStream

        For i = 0 To 14

            For j = 1 To 2
                If j < 2 Then
                    filerd = New System.IO.FileStream("C:\Users\yaren\Desktop\Yaren Gündüz COMP4437 PROJECT DATA-ARFF & MATLAB FILES\BackUp ARFFs\callt" & arr(i) & "0" & j & ".arff", IO.FileMode.Open, IO.FileAccess.Read)
                    Dim lala As New System.IO.StreamReader(filerd)

                    Dim str As String = ""

                    While str Is Nothing & str.CompareTo("@data")
                        str = lala.ReadLine
                        count += 1
                    End While

                    Dim filewr As System.IO.FileStream
                    filewr = New System.IO.FileStream("C:\Users\yaren\Desktop\Yaren Gündüz COMP4437 PROJECT DATA-ARFF & MATLAB FILES\ARFFs\callt" & arr(i) & "0" & j & ".arff", IO.FileMode.Create, IO.FileAccess.Write)
                    Dim wrt As New System.IO.StreamWriter(filewr)

                    wrt.WriteLine("@relation callt" & arr(i) & "0" & j)

                    wrt.WriteLine("@attribute phonenumber_oid numeric")
                    wrt.WriteLine("@attribute duration numeric")
                    wrt.WriteLine("@attribute wd {1,2,3,4,5,6,7}")
                    wrt.WriteLine("@attribute mn {1,2,3,4,5,6,7,8,9,10,11,12}")
                    wrt.WriteLine("@attribute stime numeric")
                    wrt.WriteLine("@attribute dirid {1,2,3}")
                    wrt.WriteLine("@attribute cnid {1,2}")
                    wrt.WriteLine("@attribute deid {1,2,3}")
                    wrt.WriteLine("@attribute dd {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31}")
                    wrt.WriteLine("@attribute person {YES,NO}")
                    wrt.WriteLine("@data")
                    While lala.Peek > -1
                        count += 1
                        str = lala.ReadLine
                        Dim tmp As String() = str.Split(",")
                        Dim str_to_write = tmp(0) & "," & tmp(1) & "," & tmp(2) & "," & tmp(3) & "," & tmp(4) & "," & tmp(5) & "," & tmp(6) & "," & tmp(7) & "," & tmp(8) & "," & tmp(9)
                        wrt.WriteLine(str_to_write)
                    End While
                    wrt.Close()

                    filewr.Close()
                End If
                If j = 10 Then
                    filerd = New System.IO.FileStream("C:\Users\yaren\Desktop\Yaren Gündüz COMP4437 PROJECT DATA-ARFF & MATLAB FILES\BackUp ARFFs\callt" & arr(i) & j & ".arff", IO.FileMode.Open, IO.FileAccess.Read)
                    Dim lala As New System.IO.StreamReader(filerd)
                    Dim str As String = ""
                    While str Is Nothing & str.CompareTo("@data")
                        str = lala.ReadLine
                        count += 1
                    End While

                    Dim filewr As System.IO.FileStream
                    filewr = New System.IO.FileStream("C:\Users\yaren\Desktop\Yaren Gündüz COMP4437 PROJECT DATA-ARFF & MATLAB FILES\ARFFs\callt" & arr(i) & j & ".arff", IO.FileMode.Create, IO.FileAccess.Write)
                    Dim wrt As New System.IO.StreamWriter(filewr)

                    wrt.WriteLine("@relation callt" & arr(i) & j)

                    wrt.WriteLine("@attribute phonenumber_oid numeric")
                    wrt.WriteLine("@attribute duration numeric")
                    wrt.WriteLine("@attribute wd {1,2,3,4,5,6,7}")
                    wrt.WriteLine("@attribute mn {1,2,3,4,5,6,7,8,9,10,11,12}")
                    wrt.WriteLine("@attribute stime numeric")
                    wrt.WriteLine("@attribute dirid {1,2,3}")
                    wrt.WriteLine("@attribute cnid {1,2}")
                    wrt.WriteLine("@attribute deid {1,2,3}")
                    wrt.WriteLine("@attribute dd {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31}")
                    wrt.WriteLine("@attribute person {YES,NO}")
                    wrt.WriteLine("@data")
                    While lala.Peek > -1
                        count += 1
                        str = lala.ReadLine
                        Dim tmp As String() = str.Split(",")
                        Dim str_to_write = tmp(0) & "," & tmp(1) & "," & tmp(2) & "," & tmp(3) & "," & tmp(4) & "," & tmp(5) & "," & tmp(6) & "," & tmp(7) & "," & tmp(8) & "," & tmp(9)
                        wrt.WriteLine(str_to_write)
                    End While
                    wrt.Close()

                    filewr.Close()
                End If



            Next


        Next

    End Sub
End Class

