﻿Imports Microsoft.VisualBasic

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim arr() As Integer = {13, 17, 22, 23, 34, 39, 42, 46, 66, 71, 74, 83, 91, 94, 95}
        Dim i = 0
        Dim j = 0
        Dim count = 0
        Dim filerd As System.IO.FileStream

        For i = 0 To 16

            For j = 1 To 11
                filerd = New System.IO.FileStream("C:\Users\yaren\Desktop\Yaren Gündüz COMP4437 PROJECT DATA-ARFF & MATLAB FILES\deneme\activity" & arr(i) & "0" & j & ".arff", IO.FileMode.Open, IO.FileAccess.Read)
                Dim lala As New System.IO.StreamReader(filerd)
                Dim str As String = ""
                While str.CompareTo("@data")
                    str = lala.ReadLine
                    count += 1
                End While

                Dim filewr As System.IO.FileStream
                filewr = New System.IO.FileStream("C:\Users\yaren\Desktop\Yaren Gündüz COMP4437 PROJECT DATA-ARFF & MATLAB FILES\DATA FILES\activity" & arr(i) & "0" & j & ".data", IO.FileMode.Create, IO.FileAccess.Write)
                Dim wrt As New System.IO.StreamWriter(filewr)
                wrt.WriteLine("5")
                wrt.WriteLine("#n duration dd wd mn stime")
                While lala.Peek > -1
                    count += 1
                    str = lala.ReadLine
                    Dim tmp As String() = str.Split(",")
                    Dim str_to_write = tmp(0) & vbTab & tmp(1) & vbTab & tmp(2) & vbTab & tmp(3) & vbTab & tmp(4) & vbTab & tmp(5)
                    wrt.WriteLine(str_to_write)
                End While
                wrt.Close()

                filewr.Close()

            Next


        Next

    End Sub
End Class
