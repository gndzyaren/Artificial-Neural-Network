SELECT * FROM activityt1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

