SELECT * FROM activityt1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

