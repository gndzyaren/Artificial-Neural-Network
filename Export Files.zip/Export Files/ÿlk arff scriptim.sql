SELECT * FROM activity1301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

