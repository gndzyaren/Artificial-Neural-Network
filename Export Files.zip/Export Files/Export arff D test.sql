SELECT * FROM activityt1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

