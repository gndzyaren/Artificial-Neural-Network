SELECT * FROM activity1301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1701 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1701.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3901 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3901.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9501 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9501.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1702 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1702.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3902 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3902.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9502 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9502.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1703 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1703.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3903 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3903.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9503 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9503.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1704 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1704.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3904 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3904.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9504 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9504.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1705 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1705.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3905 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3905.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9505 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9505.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1706 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1706.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3906 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3906.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9506 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9506.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1707 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1707.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3907 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3907.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9507 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9507.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1708 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1708.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3908 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3908.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9508 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9508.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1709 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1709.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3909 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3909.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9509 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9509.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1710 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1710.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3910 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3910.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9510 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9510.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1701 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1701.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3901 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3901.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9501 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9501.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1702 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1702.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3902 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3902.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9502 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9502.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1703 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1703.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3903 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3903.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9503 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9503.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1704 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1704.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3904 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3904.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9504 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9504.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1705 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1705.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3905 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3905.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9505 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9505.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1706 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1706.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3906 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3906.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9506 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9506.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1707 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1707.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3907 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3907.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9507 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9507.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1708 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1708.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3908 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3908.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9508 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9508.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1709 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1709.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3909 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3909.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9509 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9509.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1710 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1710.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3910 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3910.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9510 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9510.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1701 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1701.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3901 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3901.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9501 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9501.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1702 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1702.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3902 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3902.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9502 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9502.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1703 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1703.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3903 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3903.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9503 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9503.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1704 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1704.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3904 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3904.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9504 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9504.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1705 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1705.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3905 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3905.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9505 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9505.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1706 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1706.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3906 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3906.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9506 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9506.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1707 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1707.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3907 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3907.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9507 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9507.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1708 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1708.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3908 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3908.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9508 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9508.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1709 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1709.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3909 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3909.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9509 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9509.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1710 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1710.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3910 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3910.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9510 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9510.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1701 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1701.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3901 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3901.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4201 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4201.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6601 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6601.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8301 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8301.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9101 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9101.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9401 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9401.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9501 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9501.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1702 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1702.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3902 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3902.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4202 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4202.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6602 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6602.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8302 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8302.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9102 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9102.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9402 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9402.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9502 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9502.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1703 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1703.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3903 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3903.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4203 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4203.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6603 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6603.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8303 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8303.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9103 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9103.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9403 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9403.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9503 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9503.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1704 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1704.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3904 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3904.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4204 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4204.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6604 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6604.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8304 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8304.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9104 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9104.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9404 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9404.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9504 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9504.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1705 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1705.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3905 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3905.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4205 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4205.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6605 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6605.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8305 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8305.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9105 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9105.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9405 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9405.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9505 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9505.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1706 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1706.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3906 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3906.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4206 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4206.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6606 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6606.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8306 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8306.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9106 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9106.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9406 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9406.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9506 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9506.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1707 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1707.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3907 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3907.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4207 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4207.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6607 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6607.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8307 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8307.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9107 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9107.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9407 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9407.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9507 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9507.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1708 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1708.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3908 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3908.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4208 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4208.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6608 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6608.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8308 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8308.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9108 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9108.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9408 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9408.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9508 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9508.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1709 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1709.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3909 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3909.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4209 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4209.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6609 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6609.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8309 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8309.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9109 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9109.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9409 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9409.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9509 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9509.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1710 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1710.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3910 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3910.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4210 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4210.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6610 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6610.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8310 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8310.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9110 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9110.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9410 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9410.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9510 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9510.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

