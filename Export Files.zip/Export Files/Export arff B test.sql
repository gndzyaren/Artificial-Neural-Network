SELECT * FROM activityt1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activityt9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activityt9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM devicet9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/devicet9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM callt9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/callt9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cst9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cst9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

