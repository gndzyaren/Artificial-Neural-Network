SELECT * FROM activity1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1702b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1702b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3902b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3902b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9502b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9502b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1703b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1703b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3903b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3903b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9503b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9503b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1704b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1704b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3904b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3904b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9504b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9504b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1705b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1705b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3905b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3905b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9505b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9505b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1706b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1706b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3906b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3906b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9506b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9506b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1707b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1707b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3907b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3907b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9507b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9507b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1708b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1708b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3908b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3908b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9508b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9508b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1709b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1709b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3909b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3909b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9509b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9509b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1710b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1710b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3910b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3910b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9510b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9510b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1702b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1702b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3902b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3902b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9502b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9502b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1703b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1703b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3903b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3903b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9503b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9503b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1704b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1704b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3904b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3904b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9504b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9504b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1705b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1705b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3905b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3905b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9505b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9505b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1706b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1706b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3906b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3906b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9506b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9506b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1707b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1707b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3907b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3907b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9507b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9507b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1708b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1708b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3908b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3908b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9508b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9508b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1709b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1709b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3909b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3909b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9509b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9509b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1710b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1710b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3910b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3910b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9510b
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9510b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1702b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1702b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3902b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3902b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9502b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9502b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1703b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1703b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3903b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3903b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9503b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9503b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1704b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1704b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3904b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3904b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9504b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9504b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1705b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1705b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3905b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3905b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9505b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9505b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1706b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1706b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3906b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3906b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9506b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9506b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1707b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1707b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3907b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3907b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9507b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9507b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1708b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1708b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3908b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3908b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9508b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9508b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1709b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1709b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3909b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3909b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9509b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9509b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1710b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1710b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3910b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3910b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9510b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9510b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1701b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1701b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3901b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3901b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4201b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4201b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6601b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6601b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8301b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8301b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9101b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9101b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9401b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9401b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9501b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9501b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1702b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1702b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3902b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3902b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4202b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4202b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6602b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6602b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8302b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8302b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9102b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9102b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9402b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9402b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9502b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9502b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1703b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1703b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3903b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3903b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4203b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4203b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6603b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6603b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8303b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8303b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9103b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9103b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9403b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9403b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9503b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9503b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1704b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1704b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3904b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3904b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4204b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4204b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6604b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6604b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8304b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8304b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9104b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9104b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9404b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9404b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9504b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9504b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1705b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1705b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3905b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3905b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4205b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4205b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6605b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6605b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8305b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8305b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9105b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9105b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9405b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9405b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9505b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9505b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1706b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1706b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3906b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3906b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4206b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4206b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6606b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6606b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8306b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8306b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9106b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9106b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9406b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9406b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9506b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9506b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1707b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1707b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3907b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3907b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4207b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4207b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6607b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6607b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8307b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8307b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9107b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9107b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9407b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9407b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9507b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9507b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1708b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1708b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3908b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3908b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4208b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4208b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6608b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6608b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8308b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8308b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9108b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9108b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9408b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9408b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9508b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9508b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1709b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1709b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3909b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3909b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4209b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4209b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6609b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6609b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8309b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8309b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9109b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9109b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9409b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9409b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9509b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9509b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1710b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1710b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3910b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3910b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4210b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4210b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6610b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6610b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8310b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8310b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9110b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9110b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9410b 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9410b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9510b
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9510b.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

