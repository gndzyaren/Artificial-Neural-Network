SELECT * FROM activity1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1702a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1702a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3902a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3902a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9502a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9502a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1703a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1703a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3903a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3903a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9503a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9503a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1704a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1704a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3904a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3904a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9504a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9504a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1705a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1705a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3905a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3905a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9505a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9505a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1706a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1706a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3906a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3906a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9506a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9506a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1707a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1707a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3907a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3907a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9507a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9507a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1708a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1708a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3908a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3908a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9508a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9508a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1709a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1709a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3909a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3909a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9509a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9509a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1710a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1710a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3910a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3910a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9510a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9510a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1702a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1702a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3902a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3902a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9502a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9502a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1703a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1703a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3903a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3903a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9503a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9503a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1704a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1704a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3904a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3904a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9504a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9504a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1705a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1705a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3905a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3905a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9505a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9505a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1706a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1706a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3906a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3906a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9506a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9506a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1707a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1707a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3907a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3907a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9507a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9507a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1708a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1708a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3908a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3908a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9508a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9508a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1709a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1709a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3909a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3909a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9509a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9509a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1710a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1710a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3910a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3910a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9510a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9510a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1702a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1702a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3902a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3902a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9502a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9502a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1703a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1703a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3903a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3903a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9503a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9503a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1704a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1704a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3904a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3904a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9504a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9504a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1705a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1705a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3905a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3905a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9505a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9505a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1706a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1706a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3906a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3906a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9506a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9506a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1707a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1707a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3907a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3907a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9507a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9507a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1708a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1708a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3908a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3908a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9508a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9508a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1709a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1709a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3909a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3909a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9509a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9509a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1710a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1710a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3910a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3910a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9510a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9510a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1701a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1701a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3901a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3901a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4201a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4201a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6601a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6601a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8301a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8301a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9101a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9101a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9401a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9401a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9501a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9501a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1702a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1702a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3902a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3902a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4202a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4202a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6602a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6602a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8302a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8302a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9102a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9102a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9402a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9402a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9502a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9502a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1703a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1703a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3903a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3903a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4203a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4203a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6603a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6603a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8303a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8303a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9103a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9103a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9403a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9403a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9503a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9503a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1704a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1704a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3904a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3904a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4204a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4204a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6604a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6604a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8304a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8304a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9104a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9104a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9404a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9404a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9504a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9504a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1705a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1705a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3905a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3905a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4205a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4205a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6605a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6605a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8305a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8305a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9105a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9105a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9405a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9405a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9505a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9505a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1706a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1706a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3906a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3906a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4206a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4206a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6606a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6606a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8306a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8306a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9106a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9106a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9406a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9406a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9506a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9506a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1707a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1707a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3907a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3907a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4207a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4207a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6607a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6607a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8307a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8307a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9107a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9107a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9407a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9407a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9507a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9507a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1708a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1708a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3908a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3908a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4208a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4208a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6608a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6608a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8308a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8308a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9108a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9108a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9408a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9408a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9508a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9508a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1709a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1709a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3909a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3909a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4209a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4209a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6609a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6609a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8309a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8309a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9109a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9109a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9409a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9409a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9509a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9509a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1710a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1710a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3910a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3910a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4210a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4210a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6610a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6610a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8310a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8310a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9110a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9110a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9410a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9410a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9510a 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9510a.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

