SELECT * FROM activity1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1702c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1702c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3902c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3902c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9502c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9502c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1703c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1703c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3903c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3903c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9503c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9503c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1704c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1704c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3904c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3904c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9504c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9504c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1705c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1705c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3905c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3905c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9505c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9505c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1706c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1706c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3906c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3906c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9506c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9506c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1707c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1707c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3907c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3907c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9507c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9507c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1708c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1708c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3908c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3908c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9508c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9508c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1709c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1709c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3909c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3909c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9509c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9509c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1710c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1710c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3910c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3910c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9510c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9510c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1702c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1702c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3902c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3902c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9502c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9502c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1703c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1703c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3903c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3903c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9503c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9503c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1704c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1704c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3904c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3904c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9504c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9504c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1705c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1705c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3905c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3905c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9505c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9505c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1706c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1706c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3906c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3906c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9506c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9506c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1707c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1707c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3907c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3907c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9507c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9507c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1708c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1708c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3908c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3908c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9508c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9508c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1709c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1709c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3909c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3909c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9509c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9509c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1710c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1710c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3910c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3910c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9510c
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9510c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1702c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1702c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3902c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3902c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9502c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9502c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1703c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1703c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3903c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3903c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9503c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9503c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1704c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1704c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3904c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3904c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9504c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9504c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1705c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1705c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3905c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3905c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9505c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9505c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1706c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1706c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3906c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3906c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9506c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9506c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1707c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1707c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3907c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3907c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9507c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9507c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1708c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1708c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3908c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3908c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9508c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9508c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1709c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1709c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3909c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3909c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9509c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9509c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1710c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1710c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3910c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3910c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9510c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9510c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1701c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1701c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3901c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3901c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4201c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4201c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6601c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6601c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8301c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8301c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9101c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9101c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9401c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9401c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9501c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9501c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1702c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1702c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3902c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3902c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4202c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4202c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6602c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6602c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8302c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8302c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9102c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9102c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9402c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9402c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9502c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9502c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1703c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1703c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3903c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3903c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4203c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4203c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6603c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6603c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8303c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8303c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9103c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9103c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9403c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9403c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9503c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9503c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1704c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1704c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3904c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3904c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4204c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4204c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6604c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6604c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8304c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8304c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9104c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9104c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9404c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9404c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9504c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9504c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1705c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1705c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3905c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3905c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4205c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4205c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6605c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6605c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8305c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8305c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9105c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9105c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9405c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9405c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9505c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9505c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1706c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1706c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3906c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3906c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4206c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4206c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6606c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6606c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8306c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8306c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9106c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9106c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9406c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9406c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9506c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9506c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1707c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1707c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3907c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3907c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4207c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4207c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6607c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6607c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8307c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8307c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9107c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9107c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9407c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9407c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9507c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9507c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1708c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1708c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3908c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3908c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4208c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4208c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6608c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6608c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8308c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8308c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9108c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9108c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9408c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9408c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9508c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9508c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1709c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1709c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3909c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3909c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4209c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4209c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6609c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6609c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8309c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8309c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9109c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9109c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9409c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9409c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9509c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9509c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1710c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1710c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3910c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3910c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4210c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4210c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6610c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6610c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8310c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8310c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9110c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9110c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9410c 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9410c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9510c
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9510c.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

