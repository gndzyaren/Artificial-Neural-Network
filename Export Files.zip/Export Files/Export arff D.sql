SELECT * FROM activity1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1702d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1702d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3902d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3902d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9502d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9502d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1703d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1703d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3903d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3903d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9503d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9503d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1704d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1704d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3904d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3904d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9504d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9504d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1705d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1705d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3905d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3905d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9505d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9505d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1706d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1706d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3906d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3906d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9506d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9506d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1707d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1707d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3907d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3907d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9507d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9507d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1708d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1708d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3908d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3908d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9508d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9508d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1709d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1709d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3909d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3909d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9509d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9509d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity1710d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity1710d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity2310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity2310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity3910d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity3910d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity4610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity4610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity6610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity6610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity7410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity7410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity8310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity8310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM activity9510d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/activity9510d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1702d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1702d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3902d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3902d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9502d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9502d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1703d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1703d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3903d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3903d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9503d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9503d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1704d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1704d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3904d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3904d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9504d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9504d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1705d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1705d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3905d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3905d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9505d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9505d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1706d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1706d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3906d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3906d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9506d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9506d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1707d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1707d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3907d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3907d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9507d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9507d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1708d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1708d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3908d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3908d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9508d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9508d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1709d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1709d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3909d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3909d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9509d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9509d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device1710d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device1710d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device2310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device2310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device3910d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device3910d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device4610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device4610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device6610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device6610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device7410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device7410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device8310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device8310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM device9510d
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/device9510d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1702d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1702d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3902d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3902d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9502d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9502d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1703d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1703d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3903d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3903d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9503d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9503d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1704d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1704d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3904d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3904d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9504d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9504d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1705d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1705d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3905d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3905d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9505d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9505d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1706d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1706d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3906d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3906d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9506d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9506d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1707d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1707d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3907d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3907d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9507d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9507d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1708d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1708d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3908d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3908d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9508d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9508d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1709d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1709d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3909d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3909d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9509d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9509d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call1710d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call1710d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call2310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call2310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call3910d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call3910d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call4610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call4610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call6610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call6610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call7410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call7410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call8310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call8310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM call9510d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/call9510d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1701d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1701d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3901d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3901d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4201d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4201d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6601d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6601d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8301d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8301d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9101d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9101d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9401d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9401d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9501d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9501d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1702d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1702d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3902d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3902d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4202d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4202d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6602d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6602d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8302d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8302d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9102d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9102d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9402d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9402d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9502d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9502d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1703d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1703d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3903d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3903d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4203d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4203d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6603d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6603d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8303d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8303d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9103d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9103d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9403d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9403d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9503d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9503d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1704d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1704d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3904d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3904d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4204d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4204d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6604d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6604d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8304d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8304d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9104d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9104d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9404d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9404d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9504d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9504d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1705d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1705d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3905d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3905d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4205d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4205d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6605d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6605d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8305d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8305d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9105d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9105d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9405d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9405d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9505d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9505d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1706d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1706d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3906d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3906d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4206d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4206d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6606d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6606d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8306d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8306d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9106d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9106d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9406d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9406d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9506d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9506d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1707d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1707d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3907d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3907d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4207d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4207d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6607d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6607d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8307d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8307d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9107d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9107d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9407d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9407d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9507d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9507d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1708d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1708d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3908d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3908d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4208d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4208d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6608d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6608d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8308d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8308d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9108d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9108d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9408d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9408d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9508d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9508d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1709d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1709d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3909d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3909d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4209d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4209d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6609d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6609d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8309d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8309d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9109d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9109d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9409d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9409d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9509d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9509d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs1710d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs1710d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs2310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs2310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs3910d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs3910d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4210d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4210d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs4610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs4610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs6610d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs6610d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs7410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs7410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs8310d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs8310d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9110d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9110d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9410d 
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9410d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';
SELECT * FROM cs9510d
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/cs9510d.arff' FIELDS TERMINATED BY ','  LINES TERMINATED BY '\r\n';

