insert into call1301 (select * from call1301y);
insert into call1301(select * from call1701n);
insert into call1301(select * from call2201n);
insert into call1301(select * from call2301n);
insert into call1301(select * from call3401n);
insert into call1301(select * from call3901n);
insert into call1301(select * from call4201n);
insert into call1301(select * from call4601n);
insert into call1301(select * from call6601n);
insert into call1301(select * from call7101n);
insert into call1301(select * from call7401n);
insert into call1301(select * from call8301n);
insert into call1301(select * from call9101n);
insert into call1301(select * from call9401n);
insert into call1301(select * from call9501n);

insert into call1302 (select * from call1302y);
insert into call1302(select * from call1702n);
insert into call1302(select * from call2202n);
insert into call1302(select * from call2302n);
insert into call1302(select * from call3402n);
insert into call1302(select * from call3902n);
insert into call1302(select * from call4202n);
insert into call1302(select * from call4602n);
insert into call1302(select * from call6602n);
insert into call1302(select * from call7102n);
insert into call1302(select * from call7402n);
insert into call1302(select * from call8302n);
insert into call1302(select * from call9102n);
insert into call1302(select * from call9402n);
insert into call1302(select * from call9502n);


insert into call1303 (select * from call1303y);
insert into call1303(select * from call1703n);
insert into call1303(select * from call2203n);
insert into call1303(select * from call2303n);
insert into call1303(select * from call3403n);
insert into call1303(select * from call3903n);
insert into call1303(select * from call4203n);
insert into call1303(select * from call4603n);
insert into call1303(select * from call6603n);
insert into call1303(select * from call7103n);
insert into call1303(select * from call7403n);
insert into call1303(select * from call8303n);
insert into call1303(select * from call9103n);
insert into call1303(select * from call9403n);
insert into call1303(select * from call9503n);


insert into call1304 (select * from call1304y);
insert into call1304(select * from call1704n);
insert into call1304(select * from call2204n);
insert into call1304(select * from call2304n);
insert into call1304(select * from call3404n);
insert into call1304(select * from call3904n);
insert into call1304(select * from call4204n);
insert into call1304(select * from call4604n);
insert into call1304(select * from call6604n);
insert into call1304(select * from call7104n);
insert into call1304(select * from call7404n);
insert into call1304(select * from call8304n);
insert into call1304(select * from call9104n);
insert into call1304(select * from call9404n);
insert into call1304(select * from call9504n);

insert into call1305 (select * from call1305y);
insert into call1305(select * from call1705n);
insert into call1305(select * from call2205n);
insert into call1305(select * from call2305n);
insert into call1305(select * from call3405n);
insert into call1305(select * from call3905n);
insert into call1305(select * from call4205n);
insert into call1305(select * from call4605n);
insert into call1305(select * from call6605n);
insert into call1305(select * from call7105n);
insert into call1305(select * from call7405n);
insert into call1305(select * from call8305n);
insert into call1305(select * from call9105n);
insert into call1305(select * from call9405n);
insert into call1305(select * from call9505n);

insert into call1306 (select * from call1306y);
insert into call1306(select * from call1706n);
insert into call1306(select * from call2206n);
insert into call1306(select * from call2306n);
insert into call1306(select * from call3406n);
insert into call1306(select * from call3906n);
insert into call1306(select * from call4206n);
insert into call1306(select * from call4606n);
insert into call1306(select * from call6606n);
insert into call1306(select * from call7106n);
insert into call1306(select * from call7406n);
insert into call1306(select * from call8306n);
insert into call1306(select * from call9106n);
insert into call1306(select * from call9406n);
insert into call1306(select * from call9506n);

insert into call1307 (select * from call1307y);
insert into call1307(select * from call1707n);
insert into call1307(select * from call2207n);
insert into call1307(select * from call2307n);
insert into call1307(select * from call3407n);
insert into call1307(select * from call3907n);
insert into call1307(select * from call4207n);
insert into call1307(select * from call4607n);
insert into call1307(select * from call6607n);
insert into call1307(select * from call7107n);
insert into call1307(select * from call7407n);
insert into call1307(select * from call8307n);
insert into call1307(select * from call9107n);
insert into call1307(select * from call9407n);
insert into call1307(select * from call9507n);

insert into call1308 (select * from call1308y);
insert into call1308(select * from call1708n);
insert into call1308(select * from call2208n);
insert into call1308(select * from call2308n);
insert into call1308(select * from call3408n);
insert into call1308(select * from call3908n);
insert into call1308(select * from call4208n);
insert into call1308(select * from call4608n);
insert into call1308(select * from call6608n);
insert into call1308(select * from call7108n);
insert into call1308(select * from call7408n);
insert into call1308(select * from call8308n);
insert into call1308(select * from call9108n);
insert into call1308(select * from call9408n);
insert into call1308(select * from call9508n);

insert into call1309 (select * from call1309y);
insert into call1309(select * from call1709n);
insert into call1309(select * from call2209n);
insert into call1309(select * from call2309n);
insert into call1309(select * from call3409n);
insert into call1309(select * from call3909n);
insert into call1309(select * from call4209n);
insert into call1309(select * from call4609n);
insert into call1309(select * from call6609n);
insert into call1309(select * from call7109n);
insert into call1309(select * from call7409n);
insert into call1309(select * from call8309n);
insert into call1309(select * from call9109n);
insert into call1309(select * from call9409n);
insert into call1309(select * from call9509n);

insert into call1310 (select * from call1310y);
insert into call1310(select * from call1710n);
insert into call1310(select * from call2210n);
insert into call1310(select * from call2310n);
insert into call1310(select * from call3410n);
insert into call1310(select * from call3910n);
insert into call1310(select * from call4210n);
insert into call1310(select * from call4610n);
insert into call1310(select * from call6610n);
insert into call1310(select * from call7110n);
insert into call1310(select * from call7410n);
insert into call1310(select * from call8310n);
insert into call1310(select * from call9110n);
insert into call1310(select * from call9410n);
insert into call1310(select * from call9510n);

-----------------------------------------------------------

insert into call1701 (select * from call1701y);
insert into call1701(select * from call1301n);
insert into call1701(select * from call2201n);
insert into call1701(select * from call2301n);
insert into call1701(select * from call3401n);
insert into call1701(select * from call3901n);
insert into call1701(select * from call4201n);
insert into call1701(select * from call4601n);
insert into call1701(select * from call6601n);
insert into call1701(select * from call7101n);
insert into call1701(select * from call7401n);
insert into call1701(select * from call8301n);
insert into call1701(select * from call9101n);
insert into call1701(select * from call9401n);
insert into call1701(select * from call9501n);

insert into call1702 (select * from call1702y);
insert into call1702(select * from call1302n);
insert into call1702(select * from call2202n);
insert into call1702(select * from call2302n);
insert into call1702(select * from call3402n);
insert into call1702(select * from call3902n);
insert into call1702(select * from call4202n);
insert into call1702(select * from call4602n);
insert into call1702(select * from call6602n);
insert into call1702(select * from call7102n);
insert into call1702(select * from call7402n);
insert into call1702(select * from call8302n);
insert into call1702(select * from call9102n);
insert into call1702(select * from call9402n);
insert into call1702(select * from call9502n);

insert into call1703 (select * from call1703y);
insert into call1703(select * from call1303n);
insert into call1703(select * from call2203n);
insert into call1703(select * from call2303n);
insert into call1703(select * from call3403n);
insert into call1703(select * from call3903n);
insert into call1703(select * from call4203n);
insert into call1703(select * from call4603n);
insert into call1703(select * from call6603n);
insert into call1703(select * from call7103n);
insert into call1703(select * from call7403n);
insert into call1703(select * from call8303n);
insert into call1703(select * from call9103n);
insert into call1703(select * from call9403n);
insert into call1703(select * from call9503n);

insert into call1704 (select * from call1704y);
insert into call1704(select * from call1304n);
insert into call1704(select * from call2204n);
insert into call1704(select * from call2304n);
insert into call1704(select * from call3404n);
insert into call1704(select * from call3904n);
insert into call1704(select * from call4204n);
insert into call1704(select * from call4604n);
insert into call1704(select * from call6604n);
insert into call1704(select * from call7104n);
insert into call1704(select * from call7404n);
insert into call1704(select * from call8304n);
insert into call1704(select * from call9104n);
insert into call1704(select * from call9404n);
insert into call1704(select * from call9504n);

insert into call1705 (select * from call1705y);
insert into call1705(select * from call1305n);
insert into call1705(select * from call2205n);
insert into call1705(select * from call2305n);
insert into call1705(select * from call3405n);
insert into call1705(select * from call3905n);
insert into call1705(select * from call4205n);
insert into call1705(select * from call4605n);
insert into call1705(select * from call6605n);
insert into call1705(select * from call7105n);
insert into call1705(select * from call7405n);
insert into call1705(select * from call8305n);
insert into call1705(select * from call9105n);
insert into call1705(select * from call9405n);
insert into call1705(select * from call9505n);

insert into call1706 (select * from call1706y);
insert into call1706(select * from call1306n);
insert into call1706(select * from call2206n);
insert into call1706(select * from call2306n);
insert into call1706(select * from call3406n);
insert into call1706(select * from call3906n);
insert into call1706(select * from call4206n);
insert into call1706(select * from call4606n);
insert into call1706(select * from call6606n);
insert into call1706(select * from call7106n);
insert into call1706(select * from call7406n);
insert into call1706(select * from call8306n);
insert into call1706(select * from call9106n);
insert into call1706(select * from call9406n);
insert into call1706(select * from call9506n);

insert into call1707 (select * from call1707y);
insert into call1707(select * from call1307n);
insert into call1707(select * from call2207n);
insert into call1707(select * from call2307n);
insert into call1707(select * from call3407n);
insert into call1707(select * from call3907n);
insert into call1707(select * from call4207n);
insert into call1707(select * from call4607n);
insert into call1707(select * from call6607n);
insert into call1707(select * from call7107n);
insert into call1707(select * from call7407n);
insert into call1707(select * from call8307n);
insert into call1707(select * from call9107n);
insert into call1707(select * from call9407n);
insert into call1707(select * from call9507n);

insert into call1708 (select * from call1708y);
insert into call1708(select * from call1308n);
insert into call1708(select * from call2208n);
insert into call1708(select * from call2308n);
insert into call1708(select * from call3408n);
insert into call1708(select * from call3908n);
insert into call1708(select * from call4208n);
insert into call1708(select * from call4608n);
insert into call1708(select * from call6608n);
insert into call1708(select * from call7108n);
insert into call1708(select * from call7408n);
insert into call1708(select * from call8308n);
insert into call1708(select * from call9108n);
insert into call1708(select * from call9408n);
insert into call1708(select * from call9508n);

insert into call1709 (select * from call1709y);
insert into call1709(select * from call1309n);
insert into call1709(select * from call2209n);
insert into call1709(select * from call2309n);
insert into call1709(select * from call3409n);
insert into call1709(select * from call3909n);
insert into call1709(select * from call4209n);
insert into call1709(select * from call4609n);
insert into call1709(select * from call6609n);
insert into call1709(select * from call7109n);
insert into call1709(select * from call7409n);
insert into call1709(select * from call8309n);
insert into call1709(select * from call9109n);
insert into call1709(select * from call9409n);
insert into call1709(select * from call9509n);

insert into call1710(select * from call1710y);
insert into call1710(select * from call1310n);
insert into call1710(select * from call2210n);
insert into call1710(select * from call2310n);
insert into call1710(select * from call3410n);
insert into call1710(select * from call3910n);
insert into call1710(select * from call4210n);
insert into call1710(select * from call4610n);
insert into call1710(select * from call6610n);
insert into call1710(select * from call7110n);
insert into call1710(select * from call7410n);
insert into call1710(select * from call8310n);
insert into call1710(select * from call9110n);
insert into call1710(select * from call9410n);
insert into call1710(select * from call9510n);
-----------------------------------------------------


insert into call2201 (select * from call2201y);
insert into call2201(select * from call1301n);
insert into call2201(select * from call1701n);
insert into call2201(select * from call2301n);
insert into call2201(select * from call3401n);
insert into call2201(select * from call3901n);
insert into call2201(select * from call4201n);
insert into call2201(select * from call4601n);
insert into call2201(select * from call6601n);
insert into call2201(select * from call7101n);
insert into call2201(select * from call7401n);
insert into call2201(select * from call8301n);
insert into call2201(select * from call9101n);
insert into call2201(select * from call9401n);
insert into call2201(select * from call9501n);

insert into call2202 (select * from call2202y);
insert into call2202(select * from call1302n);
insert into call2202(select * from call1702n);
insert into call2202(select * from call2302n);
insert into call2202(select * from call3402n);
insert into call2202(select * from call3902n);
insert into call2202(select * from call4202n);
insert into call2202(select * from call4602n);
insert into call2202(select * from call6602n);
insert into call2202(select * from call7102n);
insert into call2202(select * from call7402n);
insert into call2202(select * from call8302n);
insert into call2202(select * from call9102n);
insert into call2202(select * from call9402n);
insert into call2202(select * from call9502n);

insert into call2203 (select * from call2203y);
insert into call2203(select * from call1303n);
insert into call2203(select * from call1703n);
insert into call2203(select * from call2303n);
insert into call2203(select * from call3403n);
insert into call2203(select * from call3903n);
insert into call2203(select * from call4203n);
insert into call2203(select * from call4603n);
insert into call2203(select * from call6603n);
insert into call2203(select * from call7103n);
insert into call2203(select * from call7403n);
insert into call2203(select * from call8303n);
insert into call2203(select * from call9103n);
insert into call2203(select * from call9403n);
insert into call2203(select * from call9503n);

insert into call2204 (select * from call2204y);
insert into call2204(select * from call1304n);
insert into call2204(select * from call1704n);
insert into call2204(select * from call2304n);
insert into call2204(select * from call3404n);
insert into call2204(select * from call3904n);
insert into call2204(select * from call4204n);
insert into call2204(select * from call4604n);
insert into call2204(select * from call6604n);
insert into call2204(select * from call7104n);
insert into call2204(select * from call7404n);
insert into call2204(select * from call8304n);
insert into call2204(select * from call9104n);
insert into call2204(select * from call9404n);
insert into call2204(select * from call9504n);

insert into call2205 (select * from call2205y);
insert into call2205(select * from call1305n);
insert into call2205(select * from call1705n);
insert into call2205(select * from call2305n);
insert into call2205(select * from call3405n);
insert into call2205(select * from call3905n);
insert into call2205(select * from call4205n);
insert into call2205(select * from call4605n);
insert into call2205(select * from call6605n);
insert into call2205(select * from call7105n);
insert into call2205(select * from call7405n);
insert into call2205(select * from call8305n);
insert into call2205(select * from call9105n);
insert into call2205(select * from call9405n);
insert into call2205(select * from call9505n);

insert into call2206 (select * from call2206y);
insert into call2206(select * from call1306n);
insert into call2206(select * from call1706n);
insert into call2206(select * from call2306n);
insert into call2206(select * from call3406n);
insert into call2206(select * from call3906n);
insert into call2206(select * from call4206n);
insert into call2206(select * from call4606n);
insert into call2206(select * from call6606n);
insert into call2206(select * from call7106n);
insert into call2206(select * from call7406n);
insert into call2206(select * from call8306n);
insert into call2206(select * from call9106n);
insert into call2206(select * from call9406n);
insert into call2206(select * from call9506n);

insert into call2207 (select * from call2207y);
insert into call2207(select * from call1307n);
insert into call2207(select * from call1707n);
insert into call2207(select * from call2307n);
insert into call2207(select * from call3407n);
insert into call2207(select * from call3907n);
insert into call2207(select * from call4207n);
insert into call2207(select * from call4607n);
insert into call2207(select * from call6607n);
insert into call2207(select * from call7107n);
insert into call2207(select * from call7407n);
insert into call2207(select * from call8307n);
insert into call2207(select * from call9107n);
insert into call2207(select * from call9407n);
insert into call2207(select * from call9507n);

insert into call2208 (select * from call2208y);
insert into call2208(select * from call1308n);
insert into call2208(select * from call1708n);
insert into call2208(select * from call2308n);
insert into call2208(select * from call3408n);
insert into call2208(select * from call3908n);
insert into call2208(select * from call4208n);
insert into call2208(select * from call4608n);
insert into call2208(select * from call6608n);
insert into call2208(select * from call7108n);
insert into call2208(select * from call7408n);
insert into call2208(select * from call8308n);
insert into call2208(select * from call9108n);
insert into call2208(select * from call9408n);
insert into call2208(select * from call9508n);

insert into call2209 (select * from call2209y);
insert into call2209(select * from call1309n);
insert into call2209(select * from call1709n);
insert into call2209(select * from call2309n);
insert into call2209(select * from call3409n);
insert into call2209(select * from call3909n);
insert into call2209(select * from call4209n);
insert into call2209(select * from call4609n);
insert into call2209(select * from call6609n);
insert into call2209(select * from call7109n);
insert into call2209(select * from call7409n);
insert into call2209(select * from call8309n);
insert into call2209(select * from call9109n);
insert into call2209(select * from call9409n);
insert into call2209(select * from call9509n);

insert into call2210 (select * from call2210y);
insert into call2210(select * from call1310n);
insert into call2210(select * from call1710n);
insert into call2210(select * from call2310n);
insert into call2210(select * from call3410n);
insert into call2210(select * from call3910n);
insert into call2210(select * from call4210n);
insert into call2210(select * from call4610n);
insert into call2210(select * from call6610n);
insert into call2210(select * from call7110n);
insert into call2210(select * from call7410n);
insert into call2210(select * from call8310n);
insert into call2210(select * from call9110n);
insert into call2210(select * from call9410n);
insert into call2210(select * from call9510n);
-----------------------------------------------------

insert into call2301 (select * from call2301y);
insert into call2301(select * from call1301n);
insert into call2301(select * from call1701n);
insert into call2301(select * from call2201n);
insert into call2301(select * from call3401n);
insert into call2301(select * from call3901n);
insert into call2301(select * from call4201n);
insert into call2301(select * from call4601n);
insert into call2301(select * from call6601n);
insert into call2301(select * from call7101n);
insert into call2301(select * from call7401n);
insert into call2301(select * from call8301n);
insert into call2301(select * from call9101n);
insert into call2301(select * from call9401n);
insert into call2301(select * from call9501n);

insert into call2302 (select * from call2302y);
insert into call2302(select * from call1302n);
insert into call2302(select * from call1702n);
insert into call2302(select * from call2202n);
insert into call2302(select * from call3402n);
insert into call2302(select * from call3902n);
insert into call2302(select * from call4202n);
insert into call2302(select * from call4602n);
insert into call2302(select * from call6602n);
insert into call2302(select * from call7102n);
insert into call2302(select * from call7402n);
insert into call2302(select * from call8302n);
insert into call2302(select * from call9102n);
insert into call2302(select * from call9402n);
insert into call2302(select * from call9502n);


insert into call2303 (select * from call2303y);
insert into call2303(select * from call1303n);
insert into call2303(select * from call1703n);
insert into call2303(select * from call2203n);
insert into call2303(select * from call3403n);
insert into call2303(select * from call3903n);
insert into call2303(select * from call4203n);
insert into call2303(select * from call4603n);
insert into call2303(select * from call6603n);
insert into call2303(select * from call7103n);
insert into call2303(select * from call7403n);
insert into call2303(select * from call8303n);
insert into call2303(select * from call9103n);
insert into call2303(select * from call9403n);
insert into call2303(select * from call9503n);


insert into call2304 (select * from call2304y);
insert into call2304(select * from call1304n);
insert into call2304(select * from call1704n);
insert into call2304(select * from call2204n);
insert into call2304(select * from call3404n);
insert into call2304(select * from call3904n);
insert into call2304(select * from call4204n);
insert into call2304(select * from call4604n);
insert into call2304(select * from call6604n);
insert into call2304(select * from call7104n);
insert into call2304(select * from call7404n);
insert into call2304(select * from call8304n);
insert into call2304(select * from call9104n);
insert into call2304(select * from call9404n);
insert into call2304(select * from call9504n);


insert into call2305 (select * from call2305y);
insert into call2305(select * from call1305n);
insert into call2305(select * from call1705n);
insert into call2305(select * from call2205n);
insert into call2305(select * from call3405n);
insert into call2305(select * from call3905n);
insert into call2305(select * from call4205n);
insert into call2305(select * from call4605n);
insert into call2305(select * from call6605n);
insert into call2305(select * from call7105n);
insert into call2305(select * from call7405n);
insert into call2305(select * from call8305n);
insert into call2305(select * from call9105n);
insert into call2305(select * from call9405n);
insert into call2305(select * from call9505n);


insert into call2306 (select * from call2306y);
insert into call2306(select * from call1306n);
insert into call2306(select * from call1706n);
insert into call2306(select * from call2206n);
insert into call2306(select * from call3406n);
insert into call2306(select * from call3906n);
insert into call2306(select * from call4206n);
insert into call2306(select * from call4606n);
insert into call2306(select * from call6606n);
insert into call2306(select * from call7106n);
insert into call2306(select * from call7406n);
insert into call2306(select * from call8306n);
insert into call2306(select * from call9106n);
insert into call2306(select * from call9406n);
insert into call2306(select * from call9506n);


insert into call2307 (select * from call2307y);
insert into call2307(select * from call1307n);
insert into call2307(select * from call1707n);
insert into call2307(select * from call2207n);
insert into call2307(select * from call3407n);
insert into call2307(select * from call3907n);
insert into call2307(select * from call4207n);
insert into call2307(select * from call4607n);
insert into call2307(select * from call6607n);
insert into call2307(select * from call7107n);
insert into call2307(select * from call7407n);
insert into call2307(select * from call8307n);
insert into call2307(select * from call9107n);
insert into call2307(select * from call9407n);
insert into call2307(select * from call9507n);


insert into call2308 (select * from call2308y);
insert into call2308(select * from call1308n);
insert into call2308(select * from call1708n);
insert into call2308(select * from call2208n);
insert into call2308(select * from call3408n);
insert into call2308(select * from call3908n);
insert into call2308(select * from call4208n);
insert into call2308(select * from call4608n);
insert into call2308(select * from call6608n);
insert into call2308(select * from call7108n);
insert into call2308(select * from call7408n);
insert into call2308(select * from call8308n);
insert into call2308(select * from call9108n);
insert into call2308(select * from call9408n);
insert into call2308(select * from call9508n);


insert into call2309 (select * from call2309y);
insert into call2309(select * from call1309n);
insert into call2309(select * from call1709n);
insert into call2309(select * from call2209n);
insert into call2309(select * from call3409n);
insert into call2309(select * from call3909n);
insert into call2309(select * from call4209n);
insert into call2309(select * from call4609n);
insert into call2309(select * from call6609n);
insert into call2309(select * from call7109n);
insert into call2309(select * from call7409n);
insert into call2309(select * from call8309n);
insert into call2309(select * from call9109n);
insert into call2309(select * from call9409n);
insert into call2309(select * from call9509n);

insert into call2310 (select * from call2310y);
insert into call2310(select * from call1310n);
insert into call2310(select * from call1710n);
insert into call2310(select * from call2210n);
insert into call2310(select * from call3410n);
insert into call2310(select * from call3910n);
insert into call2310(select * from call4210n);
insert into call2310(select * from call4610n);
insert into call2310(select * from call6610n);
insert into call2310(select * from call7110n);
insert into call2310(select * from call7410n);
insert into call2310(select * from call8310n);
insert into call2310(select * from call9110n);
insert into call2310(select * from call9410n);
insert into call2310(select * from call9510n);

-----------------------------------------------------

insert into call3401 (select * from call3401y);
insert into call3401(select * from call1301n);
insert into call3401(select * from call1701n);
insert into call3401(select * from call2201n);
insert into call3401(select * from call2301n);
insert into call3401(select * from call3901n);
insert into call3401(select * from call4201n);
insert into call3401(select * from call4601n);
insert into call3401(select * from call6601n);
insert into call3401(select * from call7101n);
insert into call3401(select * from call7401n);
insert into call3401(select * from call8301n);
insert into call3401(select * from call9101n);
insert into call3401(select * from call9401n);
insert into call3401(select * from call9501n);

insert into call3402 (select * from call3402y);
insert into call3402(select * from call1302n);
insert into call3402(select * from call1702n);
insert into call3402(select * from call2202n);
insert into call3402(select * from call2302n);
insert into call3402(select * from call3902n);
insert into call3402(select * from call4202n);
insert into call3402(select * from call4602n);
insert into call3402(select * from call6602n);
insert into call3402(select * from call7102n);
insert into call3402(select * from call7402n);
insert into call3402(select * from call8302n);
insert into call3402(select * from call9102n);
insert into call3402(select * from call9402n);
insert into call3402(select * from call9502n);


insert into call3403 (select * from call3403y);
insert into call3403(select * from call1303n);
insert into call3403(select * from call1703n);
insert into call3403(select * from call2203n);
insert into call3403(select * from call2303n);
insert into call3403(select * from call3903n);
insert into call3403(select * from call4203n);
insert into call3403(select * from call4603n);
insert into call3403(select * from call6603n);
insert into call3403(select * from call7103n);
insert into call3403(select * from call7403n);
insert into call3403(select * from call8303n);
insert into call3403(select * from call9103n);
insert into call3403(select * from call9403n);
insert into call3403(select * from call9503n);


insert into call3404 (select * from call3404y);
insert into call3404(select * from call1304n);
insert into call3404(select * from call1704n);
insert into call3404(select * from call2204n);
insert into call3404(select * from call2304n);
insert into call3404(select * from call3904n);
insert into call3404(select * from call4204n);
insert into call3404(select * from call4604n);
insert into call3404(select * from call6604n);
insert into call3404(select * from call7104n);
insert into call3404(select * from call7404n);
insert into call3404(select * from call8304n);
insert into call3404(select * from call9104n);
insert into call3404(select * from call9404n);
insert into call3404(select * from call9504n);


insert into call3405 (select * from call3405y);
insert into call3405(select * from call1305n);
insert into call3405(select * from call1705n);
insert into call3405(select * from call2205n);
insert into call3405(select * from call2305n);
insert into call3405(select * from call3905n);
insert into call3405(select * from call4205n);
insert into call3405(select * from call4605n);
insert into call3405(select * from call6605n);
insert into call3405(select * from call7105n);
insert into call3405(select * from call7405n);
insert into call3405(select * from call8305n);
insert into call3405(select * from call9105n);
insert into call3405(select * from call9405n);
insert into call3405(select * from call9505n);

insert into call3406 (select * from call3406y);
insert into call3406(select * from call1306n);
insert into call3406(select * from call1706n);
insert into call3406(select * from call2206n);
insert into call3406(select * from call2306n);
insert into call3406(select * from call3906n);
insert into call3406(select * from call4206n);
insert into call3406(select * from call4606n);
insert into call3406(select * from call6606n);
insert into call3406(select * from call7106n);
insert into call3406(select * from call7406n);
insert into call3406(select * from call8306n);
insert into call3406(select * from call9106n);
insert into call3406(select * from call9406n);
insert into call3406(select * from call9506n);


insert into call3407 (select * from call3407y);
insert into call3407(select * from call1307n);
insert into call3407(select * from call1707n);
insert into call3407(select * from call2207n);
insert into call3407(select * from call2307n);
insert into call3407(select * from call3907n);
insert into call3407(select * from call4207n);
insert into call3407(select * from call4607n);
insert into call3407(select * from call6607n);
insert into call3407(select * from call7107n);
insert into call3407(select * from call7407n);
insert into call3407(select * from call8307n);
insert into call3407(select * from call9107n);
insert into call3407(select * from call9407n);
insert into call3407(select * from call9507n);


insert into call3408 (select * from call3408y);
insert into call3408(select * from call1308n);
insert into call3408(select * from call1708n);
insert into call3408(select * from call2208n);
insert into call3408(select * from call2308n);
insert into call3408(select * from call3908n);
insert into call3408(select * from call4208n);
insert into call3408(select * from call4608n);
insert into call3408(select * from call6608n);
insert into call3408(select * from call7108n);
insert into call3408(select * from call7408n);
insert into call3408(select * from call8308n);
insert into call3408(select * from call9108n);
insert into call3408(select * from call9408n);
insert into call3408(select * from call9508n);


insert into call3409 (select * from call3409y);
insert into call3409(select * from call1309n);
insert into call3409(select * from call1709n);
insert into call3409(select * from call2209n);
insert into call3409(select * from call2309n);
insert into call3409(select * from call3909n);
insert into call3409(select * from call4209n);
insert into call3409(select * from call4609n);
insert into call3409(select * from call6609n);
insert into call3409(select * from call7109n);
insert into call3409(select * from call7409n);
insert into call3409(select * from call8309n);
insert into call3409(select * from call9109n);
insert into call3409(select * from call9409n);
insert into call3409(select * from call9509n);


insert into call3410 (select * from call3410y);
insert into call3410(select * from call1310n);
insert into call3410(select * from call1710n);
insert into call3410(select * from call2210n);
insert into call3410(select * from call2310n);
insert into call3410(select * from call3910n);
insert into call3410(select * from call4210n);
insert into call3410(select * from call4610n);
insert into call3410(select * from call6610n);
insert into call3410(select * from call7110n);
insert into call3410(select * from call7410n);
insert into call3410(select * from call8310n);
insert into call3410(select * from call9110n);
insert into call3410(select * from call9410n);
insert into call3410(select * from call9510n);

------------------------------------------------------

insert into call3901 (select * from call3901y);
insert into call3901(select * from call1301n);
insert into call3901(select * from call1701n);
insert into call3901(select * from call2201n);
insert into call3901(select * from call2301n);
insert into call3901(select * from call3401n);
insert into call3901(select * from call4201n);
insert into call3901(select * from call4601n);
insert into call3901(select * from call6601n);
insert into call3901(select * from call7101n);
insert into call3901(select * from call7401n);
insert into call3901(select * from call8301n);
insert into call3901(select * from call9101n);
insert into call3901(select * from call9401n);
insert into call3901(select * from call9501n);


insert into call3902 (select * from call3902y);
insert into call3902(select * from call1302n);
insert into call3902(select * from call1702n);
insert into call3902(select * from call2202n);
insert into call3902(select * from call2302n);
insert into call3902(select * from call3402n);
insert into call3902(select * from call4202n);
insert into call3902(select * from call4602n);
insert into call3902(select * from call6602n);
insert into call3902(select * from call7102n);
insert into call3902(select * from call7402n);
insert into call3902(select * from call8302n);
insert into call3902(select * from call9102n);
insert into call3902(select * from call9402n);
insert into call3902(select * from call9502n);


insert into call3903 (select * from call3903y);
insert into call3903(select * from call1303n);
insert into call3903(select * from call1703n);
insert into call3903(select * from call2203n);
insert into call3903(select * from call2303n);
insert into call3903(select * from call3403n);
insert into call3903(select * from call4203n);
insert into call3903(select * from call4603n);
insert into call3903(select * from call6603n);
insert into call3903(select * from call7103n);
insert into call3903(select * from call7403n);
insert into call3903(select * from call8303n);
insert into call3903(select * from call9103n);
insert into call3903(select * from call9403n);
insert into call3903(select * from call9503n);


insert into call3904 (select * from call3904y);
insert into call3904(select * from call1304n);
insert into call3904(select * from call1704n);
insert into call3904(select * from call2204n);
insert into call3904(select * from call2304n);
insert into call3904(select * from call3404n);
insert into call3904(select * from call4204n);
insert into call3904(select * from call4604n);
insert into call3904(select * from call6604n);
insert into call3904(select * from call7104n);
insert into call3904(select * from call7404n);
insert into call3904(select * from call8304n);
insert into call3904(select * from call9104n);
insert into call3904(select * from call9404n);
insert into call3904(select * from call9504n);


insert into call3905 (select * from call3905y);
insert into call3905(select * from call1305n);
insert into call3905(select * from call1705n);
insert into call3905(select * from call2205n);
insert into call3905(select * from call2305n);
insert into call3905(select * from call3405n);
insert into call3905(select * from call4205n);
insert into call3905(select * from call4605n);
insert into call3905(select * from call6605n);
insert into call3905(select * from call7105n);
insert into call3905(select * from call7405n);
insert into call3905(select * from call8305n);
insert into call3905(select * from call9105n);
insert into call3905(select * from call9405n);
insert into call3905(select * from call9505n);


insert into call3906 (select * from call3906y);
insert into call3906(select * from call1306n);
insert into call3906(select * from call1706n);
insert into call3906(select * from call2206n);
insert into call3906(select * from call2306n);
insert into call3906(select * from call3406n);
insert into call3906(select * from call4206n);
insert into call3906(select * from call4606n);
insert into call3906(select * from call6606n);
insert into call3906(select * from call7106n);
insert into call3906(select * from call7406n);
insert into call3906(select * from call8306n);
insert into call3906(select * from call9106n);
insert into call3906(select * from call9406n);
insert into call3906(select * from call9506n);


insert into call3907 (select * from call3907y);
insert into call3907(select * from call1307n);
insert into call3907(select * from call1707n);
insert into call3907(select * from call2207n);
insert into call3907(select * from call2307n);
insert into call3907(select * from call3407n);
insert into call3907(select * from call4207n);
insert into call3907(select * from call4607n);
insert into call3907(select * from call6607n);
insert into call3907(select * from call7107n);
insert into call3907(select * from call7407n);
insert into call3907(select * from call8307n);
insert into call3907(select * from call9107n);
insert into call3907(select * from call9407n);
insert into call3907(select * from call9507n);


insert into call3908 (select * from call3908y);
insert into call3908(select * from call1308n);
insert into call3908(select * from call1708n);
insert into call3908(select * from call2208n);
insert into call3908(select * from call2308n);
insert into call3908(select * from call3408n);
insert into call3908(select * from call4208n);
insert into call3908(select * from call4608n);
insert into call3908(select * from call6608n);
insert into call3908(select * from call7108n);
insert into call3908(select * from call7408n);
insert into call3908(select * from call8308n);
insert into call3908(select * from call9108n);
insert into call3908(select * from call9408n);
insert into call3908(select * from call9508n);


insert into call3909 (select * from call3909y);
insert into call3909(select * from call1309n);
insert into call3909(select * from call1709n);
insert into call3909(select * from call2209n);
insert into call3909(select * from call2309n);
insert into call3909(select * from call3409n);
insert into call3909(select * from call4209n);
insert into call3909(select * from call4609n);
insert into call3909(select * from call6609n);
insert into call3909(select * from call7109n);
insert into call3909(select * from call7409n);
insert into call3909(select * from call8309n);
insert into call3909(select * from call9109n);
insert into call3909(select * from call9409n);
insert into call3909(select * from call9509n);


insert into call3910 (select * from call3910y);
insert into call3910(select * from call1310n);
insert into call3910(select * from call1710n);
insert into call3910(select * from call2210n);
insert into call3910(select * from call2310n);
insert into call3910(select * from call3410n);
insert into call3910(select * from call4210n);
insert into call3910(select * from call4610n);
insert into call3910(select * from call6610n);
insert into call3910(select * from call7110n);
insert into call3910(select * from call7410n);
insert into call3910(select * from call8310n);
insert into call3910(select * from call9110n);
insert into call3910(select * from call9410n);
insert into call3910(select * from call9510n);

------------------------------------------------------------

insert into call4201 (select * from call4201y);
insert into call4201(select * from call1301n);
insert into call4201(select * from call1701n);
insert into call4201(select * from call2201n);
insert into call4201(select * from call2301n);
insert into call4201(select * from call3401n);
insert into call4201(select * from call3901n);
insert into call4201(select * from call4601n);
insert into call4201(select * from call6601n);
insert into call4201(select * from call7101n);
insert into call4201(select * from call7401n);
insert into call4201(select * from call8301n);
insert into call4201(select * from call9101n);
insert into call4201(select * from call9401n);
insert into call4201(select * from call9501n);

insert into call4202 (select * from call4202y);
insert into call4202(select * from call1302n);
insert into call4202(select * from call1702n);
insert into call4202(select * from call2202n);
insert into call4202(select * from call2302n);
insert into call4202(select * from call3402n);
insert into call4202(select * from call3902n);
insert into call4202(select * from call4602n);
insert into call4202(select * from call6602n);
insert into call4202(select * from call7102n);
insert into call4202(select * from call7402n);
insert into call4202(select * from call8302n);
insert into call4202(select * from call9102n);
insert into call4202(select * from call9402n);
insert into call4202(select * from call9502n);

insert into call4203 (select * from call4203y);
insert into call4203(select * from call1303n);
insert into call4203(select * from call1703n);
insert into call4203(select * from call2203n);
insert into call4203(select * from call2303n);
insert into call4203(select * from call3403n);
insert into call4203(select * from call3903n);
insert into call4203(select * from call4603n);
insert into call4203(select * from call6603n);
insert into call4203(select * from call7103n);
insert into call4203(select * from call7403n);
insert into call4203(select * from call8303n);
insert into call4203(select * from call9103n);
insert into call4203(select * from call9403n);
insert into call4203(select * from call9503n);

insert into call4204 (select * from call4204y);
insert into call4204(select * from call1304n);
insert into call4204(select * from call1704n);
insert into call4204(select * from call2204n);
insert into call4204(select * from call2304n);
insert into call4204(select * from call3404n);
insert into call4204(select * from call3904n);
insert into call4204(select * from call4604n);
insert into call4204(select * from call6604n);
insert into call4204(select * from call7104n);
insert into call4204(select * from call7404n);
insert into call4204(select * from call8304n);
insert into call4204(select * from call9104n);
insert into call4204(select * from call9404n);
insert into call4204(select * from call9504n);


insert into call4205 (select * from call4205y);
insert into call4205(select * from call1305n);
insert into call4205(select * from call1705n);
insert into call4205(select * from call2205n);
insert into call4205(select * from call2305n);
insert into call4205(select * from call3405n);
insert into call4205(select * from call3905n);
insert into call4205(select * from call4605n);
insert into call4205(select * from call6605n);
insert into call4205(select * from call7105n);
insert into call4205(select * from call7405n);
insert into call4205(select * from call8305n);
insert into call4205(select * from call9105n);
insert into call4205(select * from call9405n);
insert into call4205(select * from call9505n);

insert into call4206 (select * from call4206y);
insert into call4206(select * from call1306n);
insert into call4206(select * from call1706n);
insert into call4206(select * from call2206n);
insert into call4206(select * from call2306n);
insert into call4206(select * from call3406n);
insert into call4206(select * from call3906n);
insert into call4206(select * from call4606n);
insert into call4206(select * from call6606n);
insert into call4206(select * from call7106n);
insert into call4206(select * from call7406n);
insert into call4206(select * from call8306n);
insert into call4206(select * from call9106n);
insert into call4206(select * from call9406n);
insert into call4206(select * from call9506n);

insert into call4207 (select * from call4207y);
insert into call4207(select * from call1307n);
insert into call4207(select * from call1707n);
insert into call4207(select * from call2207n);
insert into call4207(select * from call2307n);
insert into call4207(select * from call3407n);
insert into call4207(select * from call3907n);
insert into call4207(select * from call4607n);
insert into call4207(select * from call6607n);
insert into call4207(select * from call7107n);
insert into call4207(select * from call7407n);
insert into call4207(select * from call8307n);
insert into call4207(select * from call9107n);
insert into call4207(select * from call9407n);
insert into call4207(select * from call9507n);

insert into call4208 (select * from call4208y);
insert into call4208(select * from call1308n);
insert into call4208(select * from call1708n);
insert into call4208(select * from call2208n);
insert into call4208(select * from call2308n);
insert into call4208(select * from call3408n);
insert into call4208(select * from call3908n);
insert into call4208(select * from call4608n);
insert into call4208(select * from call6608n);
insert into call4208(select * from call7108n);
insert into call4208(select * from call7408n);
insert into call4208(select * from call8308n);
insert into call4208(select * from call9108n);
insert into call4208(select * from call9408n);
insert into call4208(select * from call9508n);

insert into call4209 (select * from call4209y);
insert into call4209(select * from call1309n);
insert into call4209(select * from call1709n);
insert into call4209(select * from call2209n);
insert into call4209(select * from call2309n);
insert into call4209(select * from call3409n);
insert into call4209(select * from call3909n);
insert into call4209(select * from call4609n);
insert into call4209(select * from call6609n);
insert into call4209(select * from call7109n);
insert into call4209(select * from call7409n);
insert into call4209(select * from call8309n);
insert into call4209(select * from call9109n);
insert into call4209(select * from call9409n);
insert into call4209(select * from call9509n);

insert into call4210 (select * from call4210y);
insert into call4210(select * from call1310n);
insert into call4210(select * from call1710n);
insert into call4210(select * from call2210n);
insert into call4210(select * from call2310n);
insert into call4210(select * from call3410n);
insert into call4210(select * from call3910n);
insert into call4210(select * from call4610n);
insert into call4210(select * from call6610n);
insert into call4210(select * from call7110n);
insert into call4210(select * from call7410n);
insert into call4210(select * from call8310n);
insert into call4210(select * from call9110n);
insert into call4210(select * from call9410n);
insert into call4210(select * from call9510n);

-----------------------------------------------------------------

insert into call4601 (select * from call4601y);
insert into call4601(select * from call1301n);
insert into call4601(select * from call1701n);
insert into call4601(select * from call2201n);
insert into call4601(select * from call2301n);
insert into call4601(select * from call3401n);
insert into call4601(select * from call3901n);
insert into call4601(select * from call4201n);
insert into call4601(select * from call6601n);
insert into call4601(select * from call7101n);
insert into call4601(select * from call7401n);
insert into call4601(select * from call8301n);
insert into call4601(select * from call9101n);
insert into call4601(select * from call9401n);
insert into call4601(select * from call9501n);

insert into call4602 (select * from call4602y);
insert into call4602(select * from call1302n);
insert into call4602(select * from call1702n);
insert into call4602(select * from call2202n);
insert into call4602(select * from call2302n);
insert into call4602(select * from call3402n);
insert into call4602(select * from call3902n);
insert into call4602(select * from call4202n);
insert into call4602(select * from call6602n);
insert into call4602(select * from call7102n);
insert into call4602(select * from call7402n);
insert into call4602(select * from call8302n);
insert into call4602(select * from call9102n);
insert into call4602(select * from call9402n);
insert into call4602(select * from call9502n);

insert into call4603 (select * from call4603y);
insert into call4603(select * from call1303n);
insert into call4603(select * from call1703n);
insert into call4603(select * from call2203n);
insert into call4603(select * from call2303n);
insert into call4603(select * from call3403n);
insert into call4603(select * from call3903n);
insert into call4603(select * from call4203n);
insert into call4603(select * from call6603n);
insert into call4603(select * from call7103n);
insert into call4603(select * from call7403n);
insert into call4603(select * from call8303n);
insert into call4603(select * from call9103n);
insert into call4603(select * from call9403n);
insert into call4603(select * from call9503n);

insert into call4604 (select * from call4604y);
insert into call4604(select * from call1304n);
insert into call4604(select * from call1704n);
insert into call4604(select * from call2204n);
insert into call4604(select * from call2304n);
insert into call4604(select * from call3404n);
insert into call4604(select * from call3904n);
insert into call4604(select * from call4204n);
insert into call4604(select * from call6604n);
insert into call4604(select * from call7104n);
insert into call4604(select * from call7404n);
insert into call4604(select * from call8304n);
insert into call4604(select * from call9104n);
insert into call4604(select * from call9404n);
insert into call4604(select * from call9504n);

insert into call4605 (select * from call4605y);
insert into call4605(select * from call1305n);
insert into call4605(select * from call1705n);
insert into call4605(select * from call2205n);
insert into call4605(select * from call2305n);
insert into call4605(select * from call3405n);
insert into call4605(select * from call3905n);
insert into call4605(select * from call4205n);
insert into call4605(select * from call6605n);
insert into call4605(select * from call7105n);
insert into call4605(select * from call7405n);
insert into call4605(select * from call8305n);
insert into call4605(select * from call9105n);
insert into call4605(select * from call9405n);
insert into call4605(select * from call9505n);

insert into call4606 (select * from call4606y);
insert into call4606(select * from call1306n);
insert into call4606(select * from call1706n);
insert into call4606(select * from call2206n);
insert into call4606(select * from call2306n);
insert into call4606(select * from call3406n);
insert into call4606(select * from call3906n);
insert into call4606(select * from call4206n);
insert into call4606(select * from call6606n);
insert into call4606(select * from call7106n);
insert into call4606(select * from call7406n);
insert into call4606(select * from call8306n);
insert into call4606(select * from call9106n);
insert into call4606(select * from call9406n);
insert into call4606(select * from call9506n);

insert into call4607 (select * from call4607y);
insert into call4607(select * from call1307n);
insert into call4607(select * from call1707n);
insert into call4607(select * from call2207n);
insert into call4607(select * from call2307n);
insert into call4607(select * from call3407n);
insert into call4607(select * from call3907n);
insert into call4607(select * from call4207n);
insert into call4607(select * from call6607n);
insert into call4607(select * from call7107n);
insert into call4607(select * from call7407n);
insert into call4607(select * from call8307n);
insert into call4607(select * from call9107n);
insert into call4607(select * from call9407n);
insert into call4607(select * from call9507n);

insert into call4608 (select * from call4608y);
insert into call4608(select * from call1308n);
insert into call4608(select * from call1708n);
insert into call4608(select * from call2208n);
insert into call4608(select * from call2308n);
insert into call4608(select * from call3408n);
insert into call4608(select * from call3908n);
insert into call4608(select * from call4208n);
insert into call4608(select * from call6608n);
insert into call4608(select * from call7108n);
insert into call4608(select * from call7408n);
insert into call4608(select * from call8308n);
insert into call4608(select * from call9108n);
insert into call4608(select * from call9408n);
insert into call4608(select * from call9508n);

insert into call4609 (select * from call4609y);
insert into call4609(select * from call1309n);
insert into call4609(select * from call1709n);
insert into call4609(select * from call2209n);
insert into call4609(select * from call2309n);
insert into call4609(select * from call3409n);
insert into call4609(select * from call3909n);
insert into call4609(select * from call4209n);
insert into call4609(select * from call6609n);
insert into call4609(select * from call7109n);
insert into call4609(select * from call7409n);
insert into call4609(select * from call8309n);
insert into call4609(select * from call9109n);
insert into call4609(select * from call9409n);
insert into call4609(select * from call9509n);

insert into call4610 (select * from call4610y);
insert into call4610(select * from call1310n);
insert into call4610(select * from call1710n);
insert into call4610(select * from call2210n);
insert into call4610(select * from call2310n);
insert into call4610(select * from call3410n);
insert into call4610(select * from call3910n);
insert into call4610(select * from call4210n);
insert into call4610(select * from call6610n);
insert into call4610(select * from call7110n);
insert into call4610(select * from call7410n);
insert into call4610(select * from call8310n);
insert into call4610(select * from call9110n);
insert into call4610(select * from call9410n);
insert into call4610(select * from call9510n);

----------------------------------------------------
insert into call6601 (select * from call6601y);
insert into call6601(select * from call1301n);
insert into call6601(select * from call1701n);
insert into call6601(select * from call2201n);
insert into call6601(select * from call2301n);
insert into call6601(select * from call3401n);
insert into call6601(select * from call3901n);
insert into call6601(select * from call4201n);
insert into call6601(select * from call4601n);
insert into call6601(select * from call7101n);
insert into call6601(select * from call7401n);
insert into call6601(select * from call8301n);
insert into call6601(select * from call9101n);
insert into call6601(select * from call9401n);
insert into call6601(select * from call9501n);


insert into call6602 (select * from call6602y);
insert into call6602(select * from call1302n);
insert into call6602(select * from call1702n);
insert into call6602(select * from call2202n);
insert into call6602(select * from call2302n);
insert into call6602(select * from call3402n);
insert into call6602(select * from call3902n);
insert into call6602(select * from call4202n);
insert into call6602(select * from call4602n);
insert into call6602(select * from call7102n);
insert into call6602(select * from call7402n);
insert into call6602(select * from call8302n);
insert into call6602(select * from call9102n);
insert into call6602(select * from call9402n);
insert into call6602(select * from call9502n);

insert into call6603 (select * from call6603y);
insert into call6603(select * from call1303n);
insert into call6603(select * from call1703n);
insert into call6603(select * from call2203n);
insert into call6603(select * from call2303n);
insert into call6603(select * from call3403n);
insert into call6603(select * from call3903n);
insert into call6603(select * from call4203n);
insert into call6603(select * from call4603n);
insert into call6603(select * from call7103n);
insert into call6603(select * from call7403n);
insert into call6603(select * from call8303n);
insert into call6603(select * from call9103n);
insert into call6603(select * from call9403n);
insert into call6603(select * from call9503n);

insert into call6604 (select * from call6604y);
insert into call6604(select * from call1304n);
insert into call6604(select * from call1704n);
insert into call6604(select * from call2204n);
insert into call6604(select * from call2304n);
insert into call6604(select * from call3404n);
insert into call6604(select * from call3904n);
insert into call6604(select * from call4204n);
insert into call6604(select * from call4604n);
insert into call6604(select * from call7104n);
insert into call6604(select * from call7404n);
insert into call6604(select * from call8304n);
insert into call6604(select * from call9104n);
insert into call6604(select * from call9404n);
insert into call6604(select * from call9504n);

insert into call6605 (select * from call6605y);
insert into call6605(select * from call1305n);
insert into call6605(select * from call1705n);
insert into call6605(select * from call2205n);
insert into call6605(select * from call2305n);
insert into call6605(select * from call3405n);
insert into call6605(select * from call3905n);
insert into call6605(select * from call4205n);
insert into call6605(select * from call4605n);
insert into call6605(select * from call7105n);
insert into call6605(select * from call7405n);
insert into call6605(select * from call8305n);
insert into call6605(select * from call9105n);
insert into call6605(select * from call9405n);
insert into call6605(select * from call9505n);

insert into call6606 (select * from call6606y);
insert into call6606(select * from call1306n);
insert into call6606(select * from call1706n);
insert into call6606(select * from call2206n);
insert into call6606(select * from call2306n);
insert into call6606(select * from call3406n);
insert into call6606(select * from call3906n);
insert into call6606(select * from call4206n);
insert into call6606(select * from call4606n);
insert into call6606(select * from call7106n);
insert into call6606(select * from call7406n);
insert into call6606(select * from call8306n);
insert into call6606(select * from call9106n);
insert into call6606(select * from call9406n);
insert into call6606(select * from call9506n);

insert into call6607 (select * from call6607y);
insert into call6607(select * from call1307n);
insert into call6607(select * from call1707n);
insert into call6607(select * from call2207n);
insert into call6607(select * from call2307n);
insert into call6607(select * from call3407n);
insert into call6607(select * from call3907n);
insert into call6607(select * from call4207n);
insert into call6607(select * from call4607n);
insert into call6607(select * from call7107n);
insert into call6607(select * from call7407n);
insert into call6607(select * from call8307n);
insert into call6607(select * from call9107n);
insert into call6607(select * from call9407n);
insert into call6607(select * from call9507n);

insert into call6608 (select * from call6608y);
insert into call6608(select * from call1308n);
insert into call6608(select * from call1708n);
insert into call6608(select * from call2208n);
insert into call6608(select * from call2308n);
insert into call6608(select * from call3408n);
insert into call6608(select * from call3908n);
insert into call6608(select * from call4208n);
insert into call6608(select * from call4608n);
insert into call6608(select * from call7108n);
insert into call6608(select * from call7408n);
insert into call6608(select * from call8308n);
insert into call6608(select * from call9108n);
insert into call6608(select * from call9408n);
insert into call6608(select * from call9508n);

insert into call6609 (select * from call6609y);
insert into call6609(select * from call1309n);
insert into call6609(select * from call1709n);
insert into call6609(select * from call2209n);
insert into call6609(select * from call2309n);
insert into call6609(select * from call3409n);
insert into call6609(select * from call3909n);
insert into call6609(select * from call4209n);
insert into call6609(select * from call4609n);
insert into call6609(select * from call7109n);
insert into call6609(select * from call7409n);
insert into call6609(select * from call8309n);
insert into call6609(select * from call9109n);
insert into call6609(select * from call9409n);
insert into call6609(select * from call9509n);

insert into call6610 (select * from call6610y);
insert into call6610(select * from call1310n);
insert into call6610(select * from call1710n);
insert into call6610(select * from call2210n);
insert into call6610(select * from call2310n);
insert into call6610(select * from call3410n);
insert into call6610(select * from call3910n);
insert into call6610(select * from call4210n);
insert into call6610(select * from call4610n);
insert into call6610(select * from call7110n);
insert into call6610(select * from call7410n);
insert into call6610(select * from call8310n);
insert into call6610(select * from call9110n);
insert into call6610(select * from call9410n);
insert into call6610(select * from call9510n);

-----------------------------------------------------

insert into call7101 (select * from call7101y);
insert into call7101(select * from call1301n);
insert into call7101(select * from call1701n);
insert into call7101(select * from call2201n);
insert into call7101(select * from call2301n);
insert into call7101(select * from call3401n);
insert into call7101(select * from call3901n);
insert into call7101(select * from call4201n);
insert into call7101(select * from call4601n);
insert into call7101(select * from call6601n);
insert into call7101(select * from call7401n);
insert into call7101(select * from call8301n);
insert into call7101(select * from call9101n);
insert into call7101(select * from call9401n);
insert into call7101(select * from call9501n);

insert into call7102 (select * from call7102y);
insert into call7102(select * from call1302n);
insert into call7102(select * from call1702n);
insert into call7102(select * from call2202n);
insert into call7102(select * from call2302n);
insert into call7102(select * from call3402n);
insert into call7102(select * from call3902n);
insert into call7102(select * from call4202n);
insert into call7102(select * from call4602n);
insert into call7102(select * from call6602n);
insert into call7102(select * from call7402n);
insert into call7102(select * from call8302n);
insert into call7102(select * from call9102n);
insert into call7102(select * from call9402n);
insert into call7102(select * from call9502n);

insert into call7103 (select * from call7103y);
insert into call7103(select * from call1303n);
insert into call7103(select * from call1703n);
insert into call7103(select * from call2203n);
insert into call7103(select * from call2303n);
insert into call7103(select * from call3403n);
insert into call7103(select * from call3903n);
insert into call7103(select * from call4203n);
insert into call7103(select * from call4603n);
insert into call7103(select * from call6603n);
insert into call7103(select * from call7403n);
insert into call7103(select * from call8303n);
insert into call7103(select * from call9103n);
insert into call7103(select * from call9403n);
insert into call7103(select * from call9503n);

insert into call7104 (select * from call7104y);
insert into call7104(select * from call1304n);
insert into call7104(select * from call1704n);
insert into call7104(select * from call2204n);
insert into call7104(select * from call2304n);
insert into call7104(select * from call3404n);
insert into call7104(select * from call3904n);
insert into call7104(select * from call4204n);
insert into call7104(select * from call4604n);
insert into call7104(select * from call6604n);
insert into call7104(select * from call7404n);
insert into call7104(select * from call8304n);
insert into call7104(select * from call9104n);
insert into call7104(select * from call9404n);
insert into call7104(select * from call9504n);

insert into call7105 (select * from call7105y);
insert into call7105(select * from call1305n);
insert into call7105(select * from call1705n);
insert into call7105(select * from call2205n);
insert into call7105(select * from call2305n);
insert into call7105(select * from call3405n);
insert into call7105(select * from call3905n);
insert into call7105(select * from call4205n);
insert into call7105(select * from call4605n);
insert into call7105(select * from call6605n);
insert into call7105(select * from call7405n);
insert into call7105(select * from call8305n);
insert into call7105(select * from call9105n);
insert into call7105(select * from call9405n);
insert into call7105(select * from call9505n);

insert into call7106 (select * from call7106y);
insert into call7106(select * from call1306n);
insert into call7106(select * from call1706n);
insert into call7106(select * from call2206n);
insert into call7106(select * from call2306n);
insert into call7106(select * from call3406n);
insert into call7106(select * from call3906n);
insert into call7106(select * from call4206n);
insert into call7106(select * from call4606n);
insert into call7106(select * from call6606n);
insert into call7106(select * from call7406n);
insert into call7106(select * from call8306n);
insert into call7106(select * from call9106n);
insert into call7106(select * from call9406n);
insert into call7106(select * from call9506n);

insert into call7107 (select * from call7107y);
insert into call7107(select * from call1307n);
insert into call7107(select * from call1707n);
insert into call7107(select * from call2207n);
insert into call7107(select * from call2307n);
insert into call7107(select * from call3407n);
insert into call7107(select * from call3907n);
insert into call7107(select * from call4207n);
insert into call7107(select * from call4607n);
insert into call7107(select * from call6607n);
insert into call7107(select * from call7407n);
insert into call7107(select * from call8307n);
insert into call7107(select * from call9107n);
insert into call7107(select * from call9407n);
insert into call7107(select * from call9507n);

insert into call7108 (select * from call7108y);
insert into call7108(select * from call1308n);
insert into call7108(select * from call1708n);
insert into call7108(select * from call2208n);
insert into call7108(select * from call2308n);
insert into call7108(select * from call3408n);
insert into call7108(select * from call3908n);
insert into call7108(select * from call4208n);
insert into call7108(select * from call4608n);
insert into call7108(select * from call6608n);
insert into call7108(select * from call7408n);
insert into call7108(select * from call8308n);
insert into call7108(select * from call9108n);
insert into call7108(select * from call9408n);
insert into call7108(select * from call9508n);

insert into call7109 (select * from call7109y);
insert into call7109(select * from call1309n);
insert into call7109(select * from call1709n);
insert into call7109(select * from call2209n);
insert into call7109(select * from call2309n);
insert into call7109(select * from call3409n);
insert into call7109(select * from call3909n);
insert into call7109(select * from call4209n);
insert into call7109(select * from call4609n);
insert into call7109(select * from call6609n);
insert into call7109(select * from call7409n);
insert into call7109(select * from call8309n);
insert into call7109(select * from call9109n);
insert into call7109(select * from call9409n);
insert into call7109(select * from call9509n);

insert into call7110 (select * from call7110y);
insert into call7110(select * from call1310n);
insert into call7110(select * from call1710n);
insert into call7110(select * from call2210n);
insert into call7110(select * from call2310n);
insert into call7110(select * from call3410n);
insert into call7110(select * from call3910n);
insert into call7110(select * from call4210n);
insert into call7110(select * from call4610n);
insert into call7110(select * from call6610n);
insert into call7110(select * from call7410n);
insert into call7110(select * from call8310n);
insert into call7110(select * from call9110n);
insert into call7110(select * from call9410n);
insert into call7110(select * from call9510n);


---------------------------------------------------
insert into call7401 (select * from call7401y);
insert into call7401(select * from call1301n);
insert into call7401(select * from call1740n);
insert into call7401(select * from call2201n);
insert into call7401(select * from call2301n);
insert into call7401(select * from call3401n);
insert into call7401(select * from call3901n);
insert into call7401(select * from call4201n);
insert into call7401(select * from call4601n);
insert into call7401(select * from call6601n);
insert into call7401(select * from call7101n);
insert into call7401(select * from call8301n);
insert into call7401(select * from call9101n);
insert into call7401(select * from call9401n);
insert into call7401(select * from call9501n);

insert into call7402 (select * from call7402y);
insert into call7402(select * from call1302n);
insert into call7402(select * from call1740n);
insert into call7402(select * from call2202n);
insert into call7402(select * from call2302n);
insert into call7402(select * from call3402n);
insert into call7402(select * from call3902n);
insert into call7402(select * from call4202n);
insert into call7402(select * from call4602n);
insert into call7402(select * from call6602n);
insert into call7402(select * from call7102n);
insert into call7402(select * from call8302n);
insert into call7402(select * from call9102n);
insert into call7402(select * from call9402n);
insert into call7402(select * from call9502n);

insert into call7403 (select * from call7403y);
insert into call7403(select * from call1303n);
insert into call7403(select * from call1740n);
insert into call7403(select * from call2203n);
insert into call7403(select * from call2303n);
insert into call7403(select * from call3403n);
insert into call7403(select * from call3903n);
insert into call7403(select * from call4203n);
insert into call7403(select * from call4603n);
insert into call7403(select * from call6603n);
insert into call7403(select * from call7103n);
insert into call7403(select * from call8303n);
insert into call7403(select * from call9103n);
insert into call7403(select * from call9403n);
insert into call7403(select * from call9503n);

insert into call7404 (select * from call7404y);
insert into call7404(select * from call1304n);
insert into call7404(select * from call1740n);
insert into call7404(select * from call2204n);
insert into call7404(select * from call2304n);
insert into call7404(select * from call3404n);
insert into call7404(select * from call3904n);
insert into call7404(select * from call4204n);
insert into call7404(select * from call4604n);
insert into call7404(select * from call6604n);
insert into call7404(select * from call7104n);
insert into call7404(select * from call8304n);
insert into call7404(select * from call9104n);
insert into call7404(select * from call9404n);
insert into call7404(select * from call9504n);

insert into call7405 (select * from call7405y);
insert into call7405(select * from call1305n);
insert into call7405(select * from call1740n);
insert into call7405(select * from call2205n);
insert into call7405(select * from call2305n);
insert into call7405(select * from call3405n);
insert into call7405(select * from call3905n);
insert into call7405(select * from call4205n);
insert into call7405(select * from call4605n);
insert into call7405(select * from call6605n);
insert into call7405(select * from call7105n);
insert into call7405(select * from call8305n);
insert into call7405(select * from call9105n);
insert into call7405(select * from call9405n);
insert into call7405(select * from call9505n);

insert into call7406 (select * from call7406y);
insert into call7406(select * from call1306n);
insert into call7406(select * from call1740n);
insert into call7406(select * from call2206n);
insert into call7406(select * from call2306n);
insert into call7406(select * from call3406n);
insert into call7406(select * from call3906n);
insert into call7406(select * from call4206n);
insert into call7406(select * from call4606n);
insert into call7406(select * from call6606n);
insert into call7406(select * from call7106n);
insert into call7406(select * from call8306n);
insert into call7406(select * from call9106n);
insert into call7406(select * from call9406n);
insert into call7406(select * from call9506n);

insert into call7407 (select * from call7407y);
insert into call7407(select * from call1307n);
insert into call7407(select * from call1740n);
insert into call7407(select * from call2207n);
insert into call7407(select * from call2307n);
insert into call7407(select * from call3407n);
insert into call7407(select * from call3907n);
insert into call7407(select * from call4207n);
insert into call7407(select * from call4607n);
insert into call7407(select * from call6607n);
insert into call7407(select * from call7107n);
insert into call7407(select * from call8307n);
insert into call7407(select * from call9107n);
insert into call7407(select * from call9407n);
insert into call7407(select * from call9507n);

insert into call7408 (select * from call7408y);
insert into call7408(select * from call1308n);
insert into call7408(select * from call1740n);
insert into call7408(select * from call2208n);
insert into call7408(select * from call2308n);
insert into call7408(select * from call3408n);
insert into call7408(select * from call3908n);
insert into call7408(select * from call4208n);
insert into call7408(select * from call4608n);
insert into call7408(select * from call6608n);
insert into call7408(select * from call7108n);
insert into call7408(select * from call8308n);
insert into call7408(select * from call9108n);
insert into call7408(select * from call9408n);
insert into call7408(select * from call9508n);

insert into call7409 (select * from call7409y);
insert into call7409(select * from call1309n);
insert into call7409(select * from call1740n);
insert into call7409(select * from call2209n);
insert into call7409(select * from call2309n);
insert into call7409(select * from call3409n);
insert into call7409(select * from call3909n);
insert into call7409(select * from call4209n);
insert into call7409(select * from call4609n);
insert into call7409(select * from call6609n);
insert into call7409(select * from call7109n);
insert into call7409(select * from call8309n);
insert into call7409(select * from call9109n);
insert into call7409(select * from call9409n);
insert into call7409(select * from call9509n);

insert into call7410 (select * from call7410y);
insert into call7410(select * from call1310n);
insert into call7410(select * from call1740n);
insert into call7410(select * from call2210n);
insert into call7410(select * from call2310n);
insert into call7410(select * from call3410n);
insert into call7410(select * from call3910n);
insert into call7410(select * from call4210n);
insert into call7410(select * from call4610n);
insert into call7410(select * from call6610n);
insert into call7410(select * from call7110n);
insert into call7410(select * from call8310n);
insert into call7410(select * from call9110n);
insert into call7410(select * from call9410n);
insert into call7410(select * from call9510n);

--------------------------------------------------------
insert into call8301 (select * from call8301y);
insert into call8301(select * from call1301n);
insert into call8301(select * from call1830n);
insert into call8301(select * from call2201n);
insert into call8301(select * from call2301n);
insert into call8301(select * from call3401n);
insert into call8301(select * from call3901n);
insert into call8301(select * from call4201n);
insert into call8301(select * from call4601n);
insert into call8301(select * from call6601n);
insert into call8301(select * from call7101n);
insert into call8301(select * from call7401n);
insert into call8301(select * from call9101n);
insert into call8301(select * from call9401n);
insert into call8301(select * from call9501n);

insert into call8302 (select * from call8302y);
insert into call8302(select * from call1302n);
insert into call8302(select * from call1830n);
insert into call8302(select * from call2202n);
insert into call8302(select * from call2302n);
insert into call8302(select * from call3402n);
insert into call8302(select * from call3902n);
insert into call8302(select * from call4202n);
insert into call8302(select * from call4602n);
insert into call8302(select * from call6602n);
insert into call8302(select * from call7102n);
insert into call8302(select * from call7402n);
insert into call8302(select * from call9102n);
insert into call8302(select * from call9402n);
insert into call8302(select * from call9502n);

insert into call8303 (select * from call8303y);
insert into call8303(select * from call1303n);
insert into call8303(select * from call1830n);
insert into call8303(select * from call2203n);
insert into call8303(select * from call2303n);
insert into call8303(select * from call3403n);
insert into call8303(select * from call3903n);
insert into call8303(select * from call4203n);
insert into call8303(select * from call4603n);
insert into call8303(select * from call6603n);
insert into call8303(select * from call7103n);
insert into call8303(select * from call7403n);
insert into call8303(select * from call9103n);
insert into call8303(select * from call9403n);
insert into call8303(select * from call9503n);

insert into call8304 (select * from call8304y);
insert into call8304(select * from call1304n);
insert into call8304(select * from call1830n);
insert into call8304(select * from call2204n);
insert into call8304(select * from call2304n);
insert into call8304(select * from call3404n);
insert into call8304(select * from call3904n);
insert into call8304(select * from call4204n);
insert into call8304(select * from call4604n);
insert into call8304(select * from call6604n);
insert into call8304(select * from call7104n);
insert into call8304(select * from call7404n);
insert into call8304(select * from call9104n);
insert into call8304(select * from call9404n);
insert into call8304(select * from call9504n);

insert into call8305 (select * from call8305y);
insert into call8305(select * from call1305n);
insert into call8305(select * from call1830n);
insert into call8305(select * from call2205n);
insert into call8305(select * from call2305n);
insert into call8305(select * from call3405n);
insert into call8305(select * from call3905n);
insert into call8305(select * from call4205n);
insert into call8305(select * from call4605n);
insert into call8305(select * from call6605n);
insert into call8305(select * from call7105n);
insert into call8305(select * from call7405n);
insert into call8305(select * from call9105n);
insert into call8305(select * from call9405n);
insert into call8305(select * from call9505n);

insert into call8306 (select * from call8306y);
insert into call8306(select * from call1306n);
insert into call8306(select * from call1830n);
insert into call8306(select * from call2206n);
insert into call8306(select * from call2306n);
insert into call8306(select * from call3406n);
insert into call8306(select * from call3906n);
insert into call8306(select * from call4206n);
insert into call8306(select * from call4606n);
insert into call8306(select * from call6606n);
insert into call8306(select * from call7106n);
insert into call8306(select * from call7406n);
insert into call8306(select * from call9106n);
insert into call8306(select * from call9406n);
insert into call8306(select * from call9506n);

insert into call8307 (select * from call8307y);
insert into call8307(select * from call1307n);
insert into call8307(select * from call1830n);
insert into call8307(select * from call2207n);
insert into call8307(select * from call2307n);
insert into call8307(select * from call3407n);
insert into call8307(select * from call3907n);
insert into call8307(select * from call4207n);
insert into call8307(select * from call4607n);
insert into call8307(select * from call6607n);
insert into call8307(select * from call7107n);
insert into call8307(select * from call7407n);
insert into call8307(select * from call9107n);
insert into call8307(select * from call9407n);
insert into call8307(select * from call9507n);

insert into call8308 (select * from call8308y);
insert into call8308(select * from call1308n);
insert into call8308(select * from call1830n);
insert into call8308(select * from call2208n);
insert into call8308(select * from call2308n);
insert into call8308(select * from call3408n);
insert into call8308(select * from call3908n);
insert into call8308(select * from call4208n);
insert into call8308(select * from call4608n);
insert into call8308(select * from call6608n);
insert into call8308(select * from call7108n);
insert into call8308(select * from call7408n);
insert into call8308(select * from call9108n);
insert into call8308(select * from call9408n);
insert into call8308(select * from call9508n);

insert into call8309 (select * from call8309y);
insert into call8309(select * from call1309n);
insert into call8309(select * from call1830n);
insert into call8309(select * from call2209n);
insert into call8309(select * from call2309n);
insert into call8309(select * from call3409n);
insert into call8309(select * from call3909n);
insert into call8309(select * from call4209n);
insert into call8309(select * from call4609n);
insert into call8309(select * from call6609n);
insert into call8309(select * from call7109n);
insert into call8309(select * from call7409n);
insert into call8309(select * from call9109n);
insert into call8309(select * from call9409n);
insert into call8309(select * from call9509n);

insert into call8310 (select * from call8310y);
insert into call8310(select * from call1310n);
insert into call8310(select * from call1830n);
insert into call8310(select * from call2210n);
insert into call8310(select * from call2310n);
insert into call8310(select * from call3410n);
insert into call8310(select * from call3910n);
insert into call8310(select * from call4210n);
insert into call8310(select * from call4610n);
insert into call8310(select * from call6610n);
insert into call8310(select * from call7110n);
insert into call8310(select * from call7410n);
insert into call8310(select * from call9110n);
insert into call8310(select * from call9410n);
insert into call8310(select * from call9510n);

--------------------------------------------------------
insert into call9101 (select * from call9101y);
insert into call9101(select * from call1301n);
insert into call9101(select * from call1901n);
insert into call9101(select * from call2201n);
insert into call9101(select * from call2301n);
insert into call9101(select * from call3401n);
insert into call9101(select * from call3901n);
insert into call9101(select * from call4201n);
insert into call9101(select * from call4601n);
insert into call9101(select * from call6601n);
insert into call9101(select * from call7101n);
insert into call9101(select * from call7401n);
insert into call9101(select * from call8301n);
insert into call9101(select * from call9401n);
insert into call9101(select * from call9501n);

insert into call9102 (select * from call9102y);
insert into call9102(select * from call1302n);
insert into call9102(select * from call1902n);
insert into call9102(select * from call2202n);
insert into call9102(select * from call2302n);
insert into call9102(select * from call3402n);
insert into call9102(select * from call3902n);
insert into call9102(select * from call4202n);
insert into call9102(select * from call4602n);
insert into call9102(select * from call6602n);
insert into call9102(select * from call7102n);
insert into call9102(select * from call7402n);
insert into call9102(select * from call8302n);
insert into call9102(select * from call9402n);
insert into call9102(select * from call9502n);

insert into call9103 (select * from call9103y);
insert into call9103(select * from call1303n);
insert into call9103(select * from call1903n);
insert into call9103(select * from call2203n);
insert into call9103(select * from call2303n);
insert into call9103(select * from call3403n);
insert into call9103(select * from call3903n);
insert into call9103(select * from call4203n);
insert into call9103(select * from call4603n);
insert into call9103(select * from call6603n);
insert into call9103(select * from call7103n);
insert into call9103(select * from call7403n);
insert into call9103(select * from call8303n);
insert into call9103(select * from call9403n);
insert into call9103(select * from call9503n);

insert into call9104 (select * from call9104y);
insert into call9104(select * from call1304n);
insert into call9104(select * from call1904n);
insert into call9104(select * from call2204n);
insert into call9104(select * from call2304n);
insert into call9104(select * from call3404n);
insert into call9104(select * from call3904n);
insert into call9104(select * from call4204n);
insert into call9104(select * from call4604n);
insert into call9104(select * from call6604n);
insert into call9104(select * from call7104n);
insert into call9104(select * from call7404n);
insert into call9104(select * from call8304n);
insert into call9104(select * from call9404n);
insert into call9104(select * from call9504n);

insert into call9105 (select * from call9105y);
insert into call9105(select * from call1305n);
insert into call9105(select * from call1905n);
insert into call9105(select * from call2205n);
insert into call9105(select * from call2305n);
insert into call9105(select * from call3405n);
insert into call9105(select * from call3905n);
insert into call9105(select * from call4205n);
insert into call9105(select * from call4605n);
insert into call9105(select * from call6605n);
insert into call9105(select * from call7105n);
insert into call9105(select * from call7405n);
insert into call9105(select * from call8305n);
insert into call9105(select * from call9405n);
insert into call9105(select * from call9505n);

insert into call9106 (select * from call9106y);
insert into call9106(select * from call1306n);
insert into call9106(select * from call1906n);
insert into call9106(select * from call2206n);
insert into call9106(select * from call2306n);
insert into call9106(select * from call3406n);
insert into call9106(select * from call3906n);
insert into call9106(select * from call4206n);
insert into call9106(select * from call4606n);
insert into call9106(select * from call6606n);
insert into call9106(select * from call7106n);
insert into call9106(select * from call7406n);
insert into call9106(select * from call8306n);
insert into call9106(select * from call9406n);
insert into call9106(select * from call9506n);

insert into call9107 (select * from call9107y);
insert into call9107(select * from call1307n);
insert into call9107(select * from call1907n);
insert into call9107(select * from call2207n);
insert into call9107(select * from call2307n);
insert into call9107(select * from call3407n);
insert into call9107(select * from call3907n);
insert into call9107(select * from call4207n);
insert into call9107(select * from call4607n);
insert into call9107(select * from call6607n);
insert into call9107(select * from call7107n);
insert into call9107(select * from call7407n);
insert into call9107(select * from call8307n);
insert into call9107(select * from call9407n);
insert into call9107(select * from call9507n);

insert into call9108 (select * from call9108y);
insert into call9108(select * from call1308n);
insert into call9108(select * from call1908n);
insert into call9108(select * from call2208n);
insert into call9108(select * from call2308n);
insert into call9108(select * from call3408n);
insert into call9108(select * from call3908n);
insert into call9108(select * from call4208n);
insert into call9108(select * from call4608n);
insert into call9108(select * from call6608n);
insert into call9108(select * from call7108n);
insert into call9108(select * from call7408n);
insert into call9108(select * from call8308n);
insert into call9108(select * from call9408n);
insert into call9108(select * from call9508n);

insert into call9109 (select * from call9109y);
insert into call9109(select * from call1309n);
insert into call9109(select * from call1909n);
insert into call9109(select * from call2209n);
insert into call9109(select * from call2309n);
insert into call9109(select * from call3409n);
insert into call9109(select * from call3909n);
insert into call9109(select * from call4209n);
insert into call9109(select * from call4609n);
insert into call9109(select * from call6609n);
insert into call9109(select * from call7109n);
insert into call9109(select * from call7409n);
insert into call9109(select * from call8309n);
insert into call9109(select * from call9409n);
insert into call9109(select * from call9509n);

insert into call9110 (select * from call9110y);
insert into call9110(select * from call1310n);
insert into call9110(select * from call1910n);
insert into call9110(select * from call2210n);
insert into call9110(select * from call2310n);
insert into call9110(select * from call3410n);
insert into call9110(select * from call3910n);
insert into call9110(select * from call4210n);
insert into call9110(select * from call4610n);
insert into call9110(select * from call6610n);
insert into call9110(select * from call7110n);
insert into call9110(select * from call7410n);
insert into call9110(select * from call8310n);
insert into call9110(select * from call9410n);
insert into call9110(select * from call9510n);
---------------------------------------------------------

insert into call9401 (select * from call9401y);
insert into call9401(select * from call1301n);
insert into call9401(select * from call1901n);
insert into call9401(select * from call2201n);
insert into call9401(select * from call2301n);
insert into call9401(select * from call3401n);
insert into call9401(select * from call3901n);
insert into call9401(select * from call4201n);
insert into call9401(select * from call4601n);
insert into call9401(select * from call6601n);
insert into call9401(select * from call7101n);
insert into call9401(select * from call7401n);
insert into call9401(select * from call8301n);
insert into call9401(select * from call9101n);
insert into call9401(select * from call9501n);

insert into call9402 (select * from call9402y);
insert into call9402(select * from call1302n);
insert into call9402(select * from call1902n);
insert into call9402(select * from call2202n);
insert into call9402(select * from call2302n);
insert into call9402(select * from call3402n);
insert into call9402(select * from call3902n);
insert into call9402(select * from call4202n);
insert into call9402(select * from call4602n);
insert into call9402(select * from call6602n);
insert into call9402(select * from call7102n);
insert into call9402(select * from call7402n);
insert into call9402(select * from call8302n);
insert into call9402(select * from call9102n);
insert into call9402(select * from call9502n);

insert into call9403 (select * from call9403y);
insert into call9403(select * from call1303n);
insert into call9403(select * from call1903n);
insert into call9403(select * from call2203n);
insert into call9403(select * from call2303n);
insert into call9403(select * from call3403n);
insert into call9403(select * from call3903n);
insert into call9403(select * from call4203n);
insert into call9403(select * from call4603n);
insert into call9403(select * from call6603n);
insert into call9403(select * from call7103n);
insert into call9403(select * from call7403n);
insert into call9403(select * from call8303n);
insert into call9403(select * from call9103n);
insert into call9403(select * from call9503n);

insert into call9404 (select * from call9404y);
insert into call9404(select * from call1304n);
insert into call9404(select * from call1904n);
insert into call9404(select * from call2204n);
insert into call9404(select * from call2304n);
insert into call9404(select * from call3404n);
insert into call9404(select * from call3904n);
insert into call9404(select * from call4204n);
insert into call9404(select * from call4604n);
insert into call9404(select * from call6604n);
insert into call9404(select * from call7104n);
insert into call9404(select * from call7404n);
insert into call9404(select * from call8304n);
insert into call9404(select * from call9104n);
insert into call9404(select * from call9504n);

insert into call9405 (select * from call9405y);
insert into call9405(select * from call1305n);
insert into call9405(select * from call1905n);
insert into call9405(select * from call2205n);
insert into call9405(select * from call2305n);
insert into call9405(select * from call3405n);
insert into call9405(select * from call3905n);
insert into call9405(select * from call4205n);
insert into call9405(select * from call4605n);
insert into call9405(select * from call6605n);
insert into call9405(select * from call7105n);
insert into call9405(select * from call7405n);
insert into call9405(select * from call8305n);
insert into call9405(select * from call9105n);
insert into call9405(select * from call9505n);

insert into call9406 (select * from call9406y);
insert into call9406(select * from call1306n);
insert into call9406(select * from call1906n);
insert into call9406(select * from call2206n);
insert into call9406(select * from call2306n);
insert into call9406(select * from call3406n);
insert into call9406(select * from call3906n);
insert into call9406(select * from call4206n);
insert into call9406(select * from call4606n);
insert into call9406(select * from call6606n);
insert into call9406(select * from call7106n);
insert into call9406(select * from call7406n);
insert into call9406(select * from call8306n);
insert into call9406(select * from call9106n);
insert into call9406(select * from call9506n);

insert into call9407 (select * from call9407y);
insert into call9407(select * from call1307n);
insert into call9407(select * from call1907n);
insert into call9407(select * from call2207n);
insert into call9407(select * from call2307n);
insert into call9407(select * from call3407n);
insert into call9407(select * from call3907n);
insert into call9407(select * from call4207n);
insert into call9407(select * from call4607n);
insert into call9407(select * from call6607n);
insert into call9407(select * from call7107n);
insert into call9407(select * from call7407n);
insert into call9407(select * from call8307n);
insert into call9407(select * from call9107n);
insert into call9407(select * from call9507n);

insert into call9408 (select * from call9408y);
insert into call9408(select * from call1308n);
insert into call9408(select * from call1908n);
insert into call9408(select * from call2208n);
insert into call9408(select * from call2308n);
insert into call9408(select * from call3408n);
insert into call9408(select * from call3908n);
insert into call9408(select * from call4208n);
insert into call9408(select * from call4608n);
insert into call9408(select * from call6608n);
insert into call9408(select * from call7108n);
insert into call9408(select * from call7408n);
insert into call9408(select * from call8308n);
insert into call9408(select * from call9108n);
insert into call9408(select * from call9508n);

insert into call9409 (select * from call9409y);
insert into call9409(select * from call1309n);
insert into call9409(select * from call1909n);
insert into call9409(select * from call2209n);
insert into call9409(select * from call2309n);
insert into call9409(select * from call3409n);
insert into call9409(select * from call3909n);
insert into call9409(select * from call4209n);
insert into call9409(select * from call4609n);
insert into call9409(select * from call6609n);
insert into call9409(select * from call7109n);
insert into call9409(select * from call7409n);
insert into call9409(select * from call8309n);
insert into call9409(select * from call9109n);
insert into call9409(select * from call9509n);

insert into call9410 (select * from call9410y);
insert into call9410(select * from call1310n);
insert into call9410(select * from call1910n);
insert into call9410(select * from call2210n);
insert into call9410(select * from call2310n);
insert into call9410(select * from call3410n);
insert into call9410(select * from call3910n);
insert into call9410(select * from call4210n);
insert into call9410(select * from call4610n);
insert into call9410(select * from call6610n);
insert into call9410(select * from call7110n);
insert into call9410(select * from call7410n);
insert into call9410(select * from call8310n);
insert into call9410(select * from call9110n);
insert into call9410(select * from call9510n);
---------------------------------------------------------

insert into call9501 (select * from call9501y);
insert into call9501(select * from call1301n);
insert into call9501(select * from call1901n);
insert into call9501(select * from call2201n);
insert into call9501(select * from call2301n);
insert into call9501(select * from call3401n);
insert into call9501(select * from call3901n);
insert into call9501(select * from call4201n);
insert into call9501(select * from call4601n);
insert into call9501(select * from call6601n);
insert into call9501(select * from call7101n);
insert into call9501(select * from call7401n);
insert into call9501(select * from call8301n);
insert into call9501(select * from call9101n);
insert into call9501(select * from call9401n);

insert into call9502 (select * from call9502y);
insert into call9502(select * from call1302n);
insert into call9502(select * from call1902n);
insert into call9502(select * from call2202n);
insert into call9502(select * from call2302n);
insert into call9502(select * from call3402n);
insert into call9502(select * from call3902n);
insert into call9502(select * from call4202n);
insert into call9502(select * from call4602n);
insert into call9502(select * from call6602n);
insert into call9502(select * from call7102n);
insert into call9502(select * from call7402n);
insert into call9502(select * from call8302n);
insert into call9502(select * from call9102n);
insert into call9502(select * from call9402n);

insert into call9503 (select * from call9503y);
insert into call9503(select * from call1303n);
insert into call9503(select * from call1903n);
insert into call9503(select * from call2203n);
insert into call9503(select * from call2303n);
insert into call9503(select * from call3403n);
insert into call9503(select * from call3903n);
insert into call9503(select * from call4203n);
insert into call9503(select * from call4603n);
insert into call9503(select * from call6603n);
insert into call9503(select * from call7103n);
insert into call9503(select * from call7403n);
insert into call9503(select * from call8303n);
insert into call9503(select * from call9103n);
insert into call9503(select * from call9403n);

insert into call9504 (select * from call9504y);
insert into call9504(select * from call1304n);
insert into call9504(select * from call1904n);
insert into call9504(select * from call2204n);
insert into call9504(select * from call2304n);
insert into call9504(select * from call3404n);
insert into call9504(select * from call3904n);
insert into call9504(select * from call4204n);
insert into call9504(select * from call4604n);
insert into call9504(select * from call6604n);
insert into call9504(select * from call7104n);
insert into call9504(select * from call7404n);
insert into call9504(select * from call8304n);
insert into call9504(select * from call9104n);
insert into call9504(select * from call9404n);

insert into call9505 (select * from call9505y);
insert into call9505(select * from call1305n);
insert into call9505(select * from call1905n);
insert into call9505(select * from call2205n);
insert into call9505(select * from call2305n);
insert into call9505(select * from call3405n);
insert into call9505(select * from call3905n);
insert into call9505(select * from call4205n);
insert into call9505(select * from call4605n);
insert into call9505(select * from call6605n);
insert into call9505(select * from call7105n);
insert into call9505(select * from call7405n);
insert into call9505(select * from call8305n);
insert into call9505(select * from call9105n);
insert into call9505(select * from call9405n);

insert into call9506 (select * from call9506y);
insert into call9506(select * from call1306n);
insert into call9506(select * from call1906n);
insert into call9506(select * from call2206n);
insert into call9506(select * from call2306n);
insert into call9506(select * from call3406n);
insert into call9506(select * from call3906n);
insert into call9506(select * from call4206n);
insert into call9506(select * from call4606n);
insert into call9506(select * from call6606n);
insert into call9506(select * from call7106n);
insert into call9506(select * from call7406n);
insert into call9506(select * from call8306n);
insert into call9506(select * from call9106n);
insert into call9506(select * from call9406n);

insert into call9507 (select * from call9507y);
insert into call9507(select * from call1307n);
insert into call9507(select * from call1907n);
insert into call9507(select * from call2207n);
insert into call9507(select * from call2307n);
insert into call9507(select * from call3407n);
insert into call9507(select * from call3907n);
insert into call9507(select * from call4207n);
insert into call9507(select * from call4607n);
insert into call9507(select * from call6607n);
insert into call9507(select * from call7107n);
insert into call9507(select * from call7407n);
insert into call9507(select * from call8307n);
insert into call9507(select * from call9107n);
insert into call9507(select * from call9407n);

insert into call9508 (select * from call9508y);
insert into call9508(select * from call1308n);
insert into call9508(select * from call1908n);
insert into call9508(select * from call2208n);
insert into call9508(select * from call2308n);
insert into call9508(select * from call3408n);
insert into call9508(select * from call3908n);
insert into call9508(select * from call4208n);
insert into call9508(select * from call4608n);
insert into call9508(select * from call6608n);
insert into call9508(select * from call7108n);
insert into call9508(select * from call7408n);
insert into call9508(select * from call8308n);
insert into call9508(select * from call9108n);
insert into call9508(select * from call9408n);

insert into call9509 (select * from call9509y);
insert into call9509(select * from call1309n);
insert into call9509(select * from call1909n);
insert into call9509(select * from call2209n);
insert into call9509(select * from call2309n);
insert into call9509(select * from call3409n);
insert into call9509(select * from call3909n);
insert into call9509(select * from call4209n);
insert into call9509(select * from call4609n);
insert into call9509(select * from call6609n);
insert into call9509(select * from call7109n);
insert into call9509(select * from call7409n);
insert into call9509(select * from call8309n);
insert into call9509(select * from call9109n);
insert into call9509(select * from call9409n);

insert into call9510 (select * from call9510y);
insert into call9510(select * from call1310n);
insert into call9510(select * from call1910n);
insert into call9510(select * from call2210n);
insert into call9510(select * from call2310n);
insert into call9510(select * from call3410n);
insert into call9510(select * from call3910n);
insert into call9510(select * from call4210n);
insert into call9510(select * from call4610n);
insert into call9510(select * from call6610n);
insert into call9510(select * from call7110n);
insert into call9510(select * from call7410n);
insert into call9510(select * from call8310n);
insert into call9510(select * from call9110n);
insert into call9510(select * from call9410n);

------------------------------------------------------



































































