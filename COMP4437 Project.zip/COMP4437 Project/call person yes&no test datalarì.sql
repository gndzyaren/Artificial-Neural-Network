create table if not exists callt13y as(select * from callt1301);
alter table callt13y add person varchar(3);
update callt13y set person='YES';

create table if not exists callt13n as(select * from callt1301);
alter table callt13n add person varchar(3);
update callt13n set person='NO';

create table if not exists callt17y as(select * from callt1701);
alter table callt17y add person varchar(3);
update callt17y set person='YES';

create table if not exists callt17n as(select * from callt1701);
alter table callt17n add person varchar(3);
update callt17n set person='NO';

create table if not exists callt22y as(select * from callt2201);
alter table callt22y add person varchar(3);
update callt22y set person='YES';

create table if not exists callt22n as(select * from callt2201);
alter table callt22n add person varchar(3);
update callt22n set person='NO';

create table if not exists callt23y as(select * from callt2301);
alter table callt23y add person varchar(3);
update callt23y set person='YES';

create table if not exists callt23n as(select * from callt2301);
alter table callt23n add person varchar(3);
update callt23n set person='NO';

create table if not exists callt34y as(select * from callt3401);
alter table callt34y add person varchar(3);
update callt34y set person='YES';

create table if not exists callt34n as(select * from callt3401);
alter table callt34n add person varchar(3);
update callt34n set person='NO';

create table if not exists callt39y as(select * from callt3901);
alter table callt39y add person varchar(3);
update callt39y set person='YES';

create table if not exists callt39n as(select * from callt3901);
alter table callt39n add person varchar(3);
update callt39n set person='NO';

create table if not exists callt42y as(select * from callt4201);
alter table callt42y add person varchar(3);
update callt42y set person='YES';

create table if not exists callt42n as(select * from callt4201);
alter table callt42n add person varchar(3);
update callt42n set person='NO';

create table if not exists callt46y as(select * from callt4601);
alter table callt46y add person varchar(3);
update callt46y set person='YES';

create table if not exists callt46n as(select * from callt4601);
alter table callt46n add person varchar(3);
update callt46n set person='NO';

create table if not exists callt66y as(select * from callt6601);
alter table callt66y add person varchar(3);
update callt66y set person='YES';

create table if not exists callt66n as(select * from callt6601);
alter table callt66n add person varchar(3);
update callt66n set person='NO';

create table if not exists callt71y as(select * from callt7101);
alter table callt71y add person varchar(3);
update callt71y set person='YES';

create table if not exists callt71n as(select * from callt7101);
alter table callt71n add person varchar(3);
update callt71n set person='NO';

create table if not exists callt83y as(select * from callt8301);
alter table callt83y add person varchar(3);
update callt83y set person='YES';

create table if not exists callt83n as(select * from callt8301);
alter table callt83n add person varchar(3);
update callt83n set person='NO';


create table if not exists callt91y as(select * from callt9101);
alter table callt91y add person varchar(3);
update callt91y set person='YES';

create table if not exists callt91n as(select * from callt9101);
alter table callt91n add person varchar(3);
update callt91n set person='NO';

create table if not exists callt94y as(select * from callt9401);
alter table callt94y add person varchar(3);
update callt94y set person='YES';

create table if not exists callt94n as(select * from callt9401);
alter table callt94n add person varchar(3);
update callt94n set person='NO';


create table if not exists callt95y as(select * from callt9501);
alter table callt95y add person varchar(3);
update callt95y set person='YES';

create table if not exists callt95n as(select * from callt9501);
alter table callt95n add person varchar(3);
update callt95n set person='NO';
