SELECT * FROM cspan13a;

--İçinden 140 kayıt rastgele seçilcek --->Bunu 10 kere tekrarla--Herbiri için ayrı tablolar aç call 1501y 1502 y diye açıcaz.
--Bu rastgele alınan 10 kayıt 10 kere gelecek.--->bunlarda 1501n olacak.Kayıtı az olan no,yüksek olan yes.

---B tablolarından 50 kayıt aldım.Tek seferlik callt15 olacak bunun adın.


---ASPAN95--
create table activity9501y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9502y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9503y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9504y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9505y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9506y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9507y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9508y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9509y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 
create table activity9510y as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 350; 

create table activity9501n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9502n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9503n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9504n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9505n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9506n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9507n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9508n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9509n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 
create table activity9510n as SELECT * FROM aspan95a ORDER BY RAND() LIMIT 25; 

create table activityt9501 as select * from aspan95b ORDER BY RAND() LIMIT 120;


