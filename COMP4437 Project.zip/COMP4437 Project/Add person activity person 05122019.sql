
-----------activitySPAN-------------
alter table activity1301y add person varchar(3);
alter table activity1302y add person varchar(3);
alter table activity1303y add person varchar(3);
alter table activity1304y add person varchar(3);
alter table activity1305y add person varchar(3);
alter table activity1306y add person varchar(3);
alter table activity1307y add person varchar(3);
alter table activity1308y add person varchar(3);
alter table activity1309y add person varchar(3);
alter table activity1310y  add person varchar(3);

alter table activity1301n add person varchar(3);
alter table activity1302n add person varchar(3);
alter table activity1303n add person varchar(3);
alter table activity1304n add person varchar(3);
alter table activity1305n add person varchar(3);
alter table activity1306n add person varchar(3);
alter table activity1307n add person varchar(3);
alter table activity1308n add person varchar(3);
alter table activity1309n add person varchar(3);
alter table activity1310n add person varchar(3);

--------------------------------------------------------
alter table activity1701y add person varchar(3);
alter table activity1702y add person varchar(3);
alter table activity1703y add person varchar(3);
alter table activity1704y add person varchar(3);
alter table activity1705y add person varchar(3);
alter table activity1706y add person varchar(3);
alter table activity1707y add person varchar(3);
alter table activity1708y add person varchar(3);
alter table activity1709y add person varchar(3);
alter table activity1710y  add person varchar(3);

alter table activity1701n add person varchar(3);
alter table activity1702n add person varchar(3);
alter table activity1703n add person varchar(3);
alter table activity1704n add person varchar(3);
alter table activity1705n add person varchar(3);
alter table activity1706n add person varchar(3);
alter table activity1707n add person varchar(3);
alter table activity1708n add person varchar(3);
alter table activity1709n add person varchar(3);
alter table activity1710n add person varchar(3);

------------------------------------------------------
alter table activity2201y add person varchar(3);
alter table activity2202y add person varchar(3);
alter table activity2203y add person varchar(3);
alter table activity2204y add person varchar(3);
alter table activity2205y add person varchar(3);
alter table activity2206y add person varchar(3);
alter table activity2207y add person varchar(3);
alter table activity2208y add person varchar(3);
alter table activity2209y add person varchar(3);
alter table activity2210y  add person varchar(3);

alter table activity2201n add person varchar(3);
alter table activity2202n add person varchar(3);
alter table activity2203n add person varchar(3);
alter table activity2204n add person varchar(3);
alter table activity2205n add person varchar(3);
alter table activity2206n add person varchar(3);
alter table activity2207n add person varchar(3);
alter table activity2208n add person varchar(3);
alter table activity2209n add person varchar(3);
alter table activity2210n add person varchar(3);
------------------------------------------------------

alter table activity2301y add person varchar(3);
alter table activity2302y add person varchar(3);
alter table activity2303y add person varchar(3);
alter table activity2304y add person varchar(3);
alter table activity2305y add person varchar(3);
alter table activity2306y add person varchar(3);
alter table activity2307y add person varchar(3);
alter table activity2308y add person varchar(3);
alter table activity2309y add person varchar(3);
alter table activity2310y  add person varchar(3);

alter table activity2301n add person varchar(3);
alter table activity2302n add person varchar(3);
alter table activity2303n add person varchar(3);
alter table activity2304n add person varchar(3);
alter table activity2305n add person varchar(3);
alter table activity2306n add person varchar(3);
alter table activity2307n add person varchar(3);
alter table activity2308n add person varchar(3);
alter table activity2309n add person varchar(3);
alter table activity2310n add person varchar(3);

------------------------------------------------------
alter table activity3401y add person varchar(3);
alter table activity3402y add person varchar(3);
alter table activity3403y add person varchar(3);
alter table activity3404y add person varchar(3);
alter table activity3405y add person varchar(3);
alter table activity3406y add person varchar(3);
alter table activity3407y add person varchar(3);
alter table activity3408y add person varchar(3);
alter table activity3409y add person varchar(3);
alter table activity3410y  add person varchar(3);

alter table activity3401n add person varchar(3);
alter table activity3402n add person varchar(3);
alter table activity3403n add person varchar(3);
alter table activity3404n add person varchar(3);
alter table activity3405n add person varchar(3);
alter table activity3406n add person varchar(3);
alter table activity3407n add person varchar(3);
alter table activity3408n add person varchar(3);
alter table activity3409n add person varchar(3);
alter table activity3410n add person varchar(3);
---------------------------------------------

alter table activity3901y add person varchar(3);
alter table activity3902y add person varchar(3);
alter table activity3903y add person varchar(3);
alter table activity3904y add person varchar(3);
alter table activity3905y add person varchar(3);
alter table activity3906y add person varchar(3);
alter table activity3907y add person varchar(3);
alter table activity3908y add person varchar(3);
alter table activity3909y add person varchar(3);
alter table activity3910y  add person varchar(3);

alter table activity3901n add person varchar(3);
alter table activity3902n add person varchar(3);
alter table activity3903n add person varchar(3);
alter table activity3904n add person varchar(3);
alter table activity3905n add person varchar(3);
alter table activity3906n add person varchar(3);
alter table activity3907n add person varchar(3);
alter table activity3908n add person varchar(3);
alter table activity3909n add person varchar(3);
alter table activity3910n add person varchar(3);
-----------------------------------------------

alter table activity4201y add person varchar(3);
alter table activity4202y add person varchar(3);
alter table activity4203y add person varchar(3);
alter table activity4204y add person varchar(3);
alter table activity4205y add person varchar(3);
alter table activity4206y add person varchar(3);
alter table activity4207y add person varchar(3);
alter table activity4208y add person varchar(3);
alter table activity4209y add person varchar(3);
alter table activity4210y  add person varchar(3);

alter table activity4201n add person varchar(3);
alter table activity4202n add person varchar(3);
alter table activity4203n add person varchar(3);
alter table activity4204n add person varchar(3);
alter table activity4205n add person varchar(3);
alter table activity4206n add person varchar(3);
alter table activity4207n add person varchar(3);
alter table activity4208n add person varchar(3);
alter table activity4209n add person varchar(3);
alter table activity4210n add person varchar(3);
-------------------------------------------------

alter table activity4601y add person varchar(3);
alter table activity4602y add person varchar(3);
alter table activity4603y add person varchar(3);
alter table activity4604y add person varchar(3);
alter table activity4605y add person varchar(3);
alter table activity4606y add person varchar(3);
alter table activity4607y add person varchar(3);
alter table activity4608y add person varchar(3);
alter table activity4609y add person varchar(3);
alter table activity4610y  add person varchar(3);

alter table activity4601n add person varchar(3);
alter table activity4602n add person varchar(3);
alter table activity4603n add person varchar(3);
alter table activity4604n add person varchar(3);
alter table activity4605n add person varchar(3);
alter table activity4606n add person varchar(3);
alter table activity4607n add person varchar(3);
alter table activity4608n add person varchar(3);
alter table activity4609n add person varchar(3);
alter table activity4610n add person varchar(3);

----------------------------

alter table activity6601y add person varchar(3);
alter table activity6602y add person varchar(3);
alter table activity6603y add person varchar(3);
alter table activity6604y add person varchar(3);
alter table activity6605y add person varchar(3);
alter table activity6606y add person varchar(3);
alter table activity6607y add person varchar(3);
alter table activity6608y add person varchar(3);
alter table activity6609y add person varchar(3);
alter table activity6610y  add person varchar(3);

alter table activity6601n add person varchar(3);
alter table activity6602n add person varchar(3);
alter table activity6603n add person varchar(3);
alter table activity6604n add person varchar(3);
alter table activity6605n add person varchar(3);
alter table activity6606n add person varchar(3);
alter table activity6607n add person varchar(3);
alter table activity6608n add person varchar(3);
alter table activity6609n add person varchar(3);
alter table activity6610n add person varchar(3);
---------------------------------------------

alter table activity7101y add person varchar(3);
alter table activity7102y add person varchar(3);
alter table activity7103y add person varchar(3);
alter table activity7104y add person varchar(3);
alter table activity7105y add person varchar(3);
alter table activity7106y add person varchar(3);
alter table activity7107y add person varchar(3);
alter table activity7108y add person varchar(3);
alter table activity7109y add person varchar(3);
alter table activity7110y  add person varchar(3);

alter table activity7101n add person varchar(3);
alter table activity7102n add person varchar(3);
alter table activity7103n add person varchar(3);
alter table activity7104n add person varchar(3);
alter table activity7105n add person varchar(3);
alter table activity7106n add person varchar(3);
alter table activity7107n add person varchar(3);
alter table activity7108n add person varchar(3);
alter table activity7109n add person varchar(3);
alter table activity7110n add person varchar(3);

------------------------------------------------

alter table activity7401y add person varchar(3);
alter table activity7402y add person varchar(3);
alter table activity7403y add person varchar(3);
alter table activity7404y add person varchar(3);
alter table activity7405y add person varchar(3);
alter table activity7406y add person varchar(3);
alter table activity7407y add person varchar(3);
alter table activity7408y add person varchar(3);
alter table activity7409y add person varchar(3);
alter table activity7410y  add person varchar(3);

alter table activity7401n add person varchar(3);
alter table activity7402n add person varchar(3);
alter table activity7403n add person varchar(3);
alter table activity7404n add person varchar(3);
alter table activity7405n add person varchar(3);
alter table activity7406n add person varchar(3);
alter table activity7407n add person varchar(3);
alter table activity7408n add person varchar(3);
alter table activity7409n add person varchar(3);
alter table activity7410n add person varchar(3);

-----------------------------------------------

alter table activity8301y add person varchar(3);
alter table activity8302y add person varchar(3);
alter table activity8303y add person varchar(3);
alter table activity8304y add person varchar(3);
alter table activity8305y add person varchar(3);
alter table activity8306y add person varchar(3);
alter table activity8307y add person varchar(3);
alter table activity8308y add person varchar(3);
alter table activity8309y add person varchar(3);
alter table activity8310y  add person varchar(3);

alter table activity8301n add person varchar(3);
alter table activity8302n add person varchar(3);
alter table activity8303n add person varchar(3);
alter table activity8304n add person varchar(3);
alter table activity8305n add person varchar(3);
alter table activity8306n add person varchar(3);
alter table activity8307n add person varchar(3);
alter table activity8308n add person varchar(3);
alter table activity8309n add person varchar(3);
alter table activity8310n add person varchar(3);

-------------------------------------------
alter table activity9101y add person varchar(3);
alter table activity9102y add person varchar(3);
alter table activity9103y add person varchar(3);
alter table activity9104y add person varchar(3);
alter table activity9105y add person varchar(3);
alter table activity9106y add person varchar(3);
alter table activity9107y add person varchar(3);
alter table activity9108y add person varchar(3);
alter table activity9109y add person varchar(3);
alter table activity9110y  add person varchar(3);

alter table activity9101n add person varchar(3);
alter table activity9102n add person varchar(3);
alter table activity9103n add person varchar(3);
alter table activity9104n add person varchar(3);
alter table activity9105n add person varchar(3);
alter table activity9106n add person varchar(3);
alter table activity9107n add person varchar(3);
alter table activity9108n add person varchar(3);
alter table activity9109n add person varchar(3);
alter table activity9110n add person varchar(3);
--------------------------------------------

alter table activity9401y add person varchar(3);
alter table activity9402y add person varchar(3);
alter table activity9403y add person varchar(3);
alter table activity9404y add person varchar(3);
alter table activity9405y add person varchar(3);
alter table activity9406y add person varchar(3);
alter table activity9407y add person varchar(3);
alter table activity9408y add person varchar(3);
alter table activity9409y add person varchar(3);
alter table activity9410y  add person varchar(3);

alter table activity9401n add person varchar(3);
alter table activity9402n add person varchar(3);
alter table activity9403n add person varchar(3);
alter table activity9404n add person varchar(3);
alter table activity9405n add person varchar(3);
alter table activity9406n add person varchar(3);
alter table activity9407n add person varchar(3);
alter table activity9408n add person varchar(3);
alter table activity9409n add person varchar(3);
alter table activity9410n add person varchar(3);
---------------------------------------------

alter table activity9501y add person varchar(3);
alter table activity9502y add person varchar(3);
alter table activity9503y add person varchar(3);
alter table activity9504y add person varchar(3);
alter table activity9505y add person varchar(3);
alter table activity9506y add person varchar(3);
alter table activity9507y add person varchar(3);
alter table activity9508y add person varchar(3);
alter table activity9509y add person varchar(3);
alter table activity9510y  add person varchar(3);

alter table activity9501n add person varchar(3);
alter table activity9502n add person varchar(3);
alter table activity9503n add person varchar(3);
alter table activity9504n add person varchar(3);
alter table activity9505n add person varchar(3);
alter table activity9506n add person varchar(3);
alter table activity9507n add person varchar(3);
alter table activity9508n add person varchar(3);
alter table activity9509n add person varchar(3);
alter table activity9510n add person varchar(3);