SELECT * FROM mitclean.call1301y;
/*callspan-- phone_numberoid,cnid,dirid,deid,dd,wd,mn,duration,stime,person*/ -->Varyasyon için gerkeli olacak
/*callspan-- celltower_oid,dd,wd,mn,duration,stime,person */ -->Varyasyon için gerekli olacak
/*activityspan-- dd,wd,mn,duration,stime,person*/ -->Varyasyon için gerekli olacak
/*devicespan-- deviec_oid,dd,wd,mn,duration,stime,person */ -->Varyasyon için gerekli olacak

ALTER TABLE "table_name" DROP COLUMN "column_name";
ALTER TABLE "table_name" Change "column 1" "column 2" ["Data Type"];



