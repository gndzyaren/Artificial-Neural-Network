create table if not exists devicet13y as(select * from devicet1301);
alter table devicet13y add person varchar(3);
update devicet13y set person='YES';

create table if not exists devicet13n as(select * from devicet1301);
alter table devicet13n add person varchar(3);
update devicet13n set person='NO';

create table if not exists devicet17y as(select * from devicet1701);
alter table devicet17y add person varchar(3);
update devicet17y set person='YES';

create table if not exists devicet17n as(select * from devicet1701);
alter table devicet17n add person varchar(3);
update devicet17n set person='NO';

create table if not exists devicet22y as(select * from devicet2201);
alter table devicet22y add person varchar(3);
update devicet22y set person='YES';

create table if not exists devicet22n as(select * from devicet2201);
alter table devicet22n add person varchar(3);
update devicet22n set person='NO';

create table if not exists devicet23y as(select * from devicet2301);
alter table devicet23y add person varchar(3);
update devicet23y set person='YES';

create table if not exists devicet23n as(select * from devicet2301);
alter table devicet23n add person varchar(3);
update devicet23n set person='NO';

create table if not exists devicet34y as(select * from devicet3401);
alter table devicet34y add person varchar(3);
update devicet34y set person='YES';

create table if not exists devicet34n as(select * from devicet3401);
alter table devicet34n add person varchar(3);
update devicet34n set person='NO';

create table if not exists devicet39y as(select * from devicet3901);
alter table devicet39y add person varchar(3);
update devicet39y set person='YES';

create table if not exists devicet39n as(select * from devicet3901);
alter table devicet39n add person varchar(3);
update devicet39n set person='NO';

create table if not exists devicet42y as(select * from devicet4201);
alter table devicet42y add person varchar(3);
update devicet42y set person='YES';

create table if not exists devicet42n as(select * from devicet4201);
alter table devicet42n add person varchar(3);
update devicet42n set person='NO';

create table if not exists devicet46y as(select * from devicet4601);
alter table devicet46y add person varchar(3);
update devicet46y set person='YES';

create table if not exists devicet46n as(select * from devicet4601);
alter table devicet46n add person varchar(3);
update devicet46n set person='NO';

create table if not exists devicet66y as(select * from devicet6601);
alter table devicet66y add person varchar(3);
update devicet66y set person='YES';

create table if not exists devicet66n as(select * from devicet6601);
alter table devicet66n add person varchar(3);
update devicet66n set person='NO';

create table if not exists devicet71y as(select * from devicet7101);
alter table devicet71y add person varchar(3);
update devicet71y set person='YES';

create table if not exists devicet71n as(select * from devicet7101);
alter table devicet71n add person varchar(3);
update devicet71n set person='NO';

create table if not exists devicet83y as(select * from devicet8301);
alter table devicet83y add person varchar(3);
update devicet83y set person='YES';

create table if not exists devicet83n as(select * from devicet8301);
alter table devicet83n add person varchar(3);
update devicet83n set person='NO';


create table if not exists devicet91y as(select * from devicet9101);
alter table devicet91y add person varchar(3);
update devicet91y set person='YES';

create table if not exists devicet91n as(select * from devicet9101);
alter table devicet91n add person varchar(3);
update devicet91n set person='NO';

create table if not exists devicet94y as(select * from devicet9401);
alter table devicet94y add person varchar(3);
update devicet94y set person='YES';

create table if not exists devicet94n as(select * from devicet9401);
alter table devicet94n add person varchar(3);
update devicet94n set person='NO';


create table if not exists devicet95y as(select * from devicet9501);
alter table devicet95y add person varchar(3);
update devicet95y set person='YES';

create table if not exists devicet95n as(select * from devicet9501);
alter table devicet95n add person varchar(3);
update devicet95n set person='NO';
