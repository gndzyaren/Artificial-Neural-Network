SELECT * FROM cspan1;
ALTER TABLE mitclean.cspan1
DROP COLUMN oid,
DROP COLUMN	endtime,
DROP COLUMN person_oid,
DROP COLUMN callid,
DROP COLUMN contact,
DROP COLUMN description,
DROP COLUMN	direction,
DROP COLUMN ctid;
SELECT * FROM cspan1;

SELECT * FROM cspan1;

CREATE TABLE cspan1 SELECT * FROM callspanclean;
ALTER TABLE cspan1 DROP did,DROP drid;
ALTER TABLE cspan1 DROP COLUMN cid,DROP COLUMN dd;
ALTER TABLE cspan1 ADD dirid int;
ALTER TABLE cspan1 ADD cnid int;
UPDATE cspan1 SET dirid=IF(direction='Outgoing',3,IF(direction='Incoming',2,1));
SET SQL_SAFE_UPDATES=0;
UPDATE cspan1 SET cnid=2 WHERE contact=-1;
UPDATE cspan1 SET cnid=1 WHERE contact!=-1;
UPDATE cspan1 SET wd=1 WHERE dayname(starttime)='Monday';
UPDATE cspan1 SET wd=2 WHERE dayname(starttime)='Tuesday';
UPDATE cspan1 SET wd=3 WHERE dayname(starttime)='Wednesday';
UPDATE cspan1 SET wd=4 WHERE dayname(starttime)='Thursday';  
UPDATE cspan1 SET wd=5 WHERE dayname(starttime)='Friday';
UPDATE cspan1 SET wd=6 WHERE dayname(starttime)='Saturday';
UPDATE cspan1 SET wd=7 WHERE dayname(starttime)='Sunday';
ALTER TABLE cspan1 ADD deid int;
UPDATE cspan1 SET deid=IF(cspan1.description='Voice Call',2,IF(cspan1.description='Short Message',3,1));
ALTER TABLE cspan1 CHANGE COLUMN md mn int;
ALTER TABLE cspan1 ADD COLUMN dd int;
UPDATE cspan1 
    SET dd = (
        SELECT dd
        FROM callspanclean
        WHERE cspan1.oid=callspanclean.oid
    );
    /*Her bir tablo için bu kullanıcılardan kaçtane var*/