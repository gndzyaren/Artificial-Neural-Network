SELECT * FROM mitclean.aspan13b order by starttime;
SELECT * FROM aspan13a order by starttime;
Select * from aspan13 order by starttime;

create table cellspan39b as SELECT * FROM (
    SELECT * FROM cellspan39 ORDER BY starttime DESC LIMIT 0,1600
) sub ORDER BY starttime ASC;
CREATE TABLE cellspan39b AS SELECT * FROM cellspan23 order by starttime limit 6400,1600;