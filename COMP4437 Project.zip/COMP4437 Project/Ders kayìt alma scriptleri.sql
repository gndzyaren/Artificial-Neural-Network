select * from cspan1 where person_oid=45 order by  rand() limit 400;
select * from cspan1 where person_oid=45 order by starttime ,rand() limit 320;
select * from cspan1 where person_oid=45 order by starttime ,rand() limit 320,80;  -- böyle çalışmıyor 

create table cspan45 as select * from cspan1 person_oid=45 order by rand() not exists; -- bu şekilde çalıştır
select * from cspan45 order by starttime limit 0,4; -- 1 yazılmayacak   ilk 4 satırı verecek

select * from cspan45 order by starttime limit 0,320; -- 320 ye kadar saymış olacak
 
create table cspan45a as select * from cspan45 order by starttime limit 0,320; -- 0 ile 320 arasında veriyi alıyoruz
select * from cspan45a;

create table cspan45b as select * from cspan45 order by starttime 3,1 -- 3. rowdaki 1.kayıt 
select * from cspan45 order by starttime limit 320,1 -- 320 kayıttan birini alıyorum demek oluyor bu //80  kayıtı o zaman 320 ye 80 olarka alabiliriz 




select * from cspan1;