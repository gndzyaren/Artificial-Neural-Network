alter table activityspanclean rename column md to mn;
SELECT person_oid,count(person_oid) from aspan2  group by person_oid  order by person_oid;
SELECT person_oid,count(person_oid) from cspan1  group by person_oid  order by person_oid;
SELECT person_oid,count(person_oid) from dspan1  group by person_oid  order by person_oid;
SELECT person_oid,count(person_oid) from cespan1  group by person_oid  order by person_oid;

		/*69 kullanıcıdan 15 kullanıcı seçicez*/
/*Activity için gerekli */

select * from cspan1  where person_oid = 39 order by starttime;
select * from cspan1 order by rand() limit 400;
create table cspan2 as select * from cspan1 order by rand() limit 400;

