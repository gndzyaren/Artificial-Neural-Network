SELECT * FROM mitclean.call1301n;
SELECT * FROM mitclean.callspanclean;
SELECT * FROM mitclean.cspan1;
SELECT *FROM cspan2;

----------------------CALL13--------------------
ALTER TABLE mitclean.call1301n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1302n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1303n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1304n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1305n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1306n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1307n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1308n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1309n RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1310n RENAME "ctid" TO "cnid" ["int(11)"]

ALTER TABLE mitclean.call1301y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1302y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1303y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1304y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1305y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1306y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1307y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1308y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1309y RENAME "ctid" TO "cnid" ["int(11)"]
ALTER TABLE mitclean.call1310y RENAME "ctid" TO "cnid" ["int(11)"]

---------------------------CALL1302---------
