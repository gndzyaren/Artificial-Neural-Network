-----------CALLSPAN-------------
alter table call1301y add person varchar(3);
alter table call1302y add person varchar(3);
alter table call1303y add person varchar(3);
alter table call1304y add person varchar(3);
alter table call1305y add person varchar(3);
alter table call1306y add person varchar(3);
alter table call1307y add person varchar(3);
alter table call1308y add person varchar(3);
alter table call1309y add person varchar(3);
alter table call1310y  add person varchar(3);

alter table call1301n add person varchar(3);
alter table call1302n add person varchar(3);
alter table call1303n add person varchar(3);
alter table call1304n add person varchar(3);
alter table call1305n add person varchar(3);
alter table call1306n add person varchar(3);
alter table call1307n add person varchar(3);
alter table call1308n add person varchar(3);
alter table call1309n add person varchar(3);
alter table call1310n add person varchar(3);

--------------------------------------------------------
alter table call1701y add person varchar(3);
alter table call1702y add person varchar(3);
alter table call1703y add person varchar(3);
alter table call1704y add person varchar(3);
alter table call1705y add person varchar(3);
alter table call1706y add person varchar(3);
alter table call1707y add person varchar(3);
alter table call1708y add person varchar(3);
alter table call1709y add person varchar(3);
alter table call1710y  add person varchar(3);

alter table call1701n add person varchar(3);
alter table call1702n add person varchar(3);
alter table call1703n add person varchar(3);
alter table call1704n add person varchar(3);
alter table call1705n add person varchar(3);
alter table call1706n add person varchar(3);
alter table call1707n add person varchar(3);
alter table call1708n add person varchar(3);
alter table call1709n add person varchar(3);
alter table call1710n add person varchar(3);

------------------------------------------------------
alter table call2201y add person varchar(3);
alter table call2202y add person varchar(3);
alter table call2203y add person varchar(3);
alter table call2204y add person varchar(3);
alter table call2205y add person varchar(3);
alter table call2206y add person varchar(3);
alter table call2207y add person varchar(3);
alter table call2208y add person varchar(3);
alter table call2209y add person varchar(3);
alter table call2210y  add person varchar(3);

alter table call2201n add person varchar(3);
alter table call2202n add person varchar(3);
alter table call2203n add person varchar(3);
alter table call2204n add person varchar(3);
alter table call2205n add person varchar(3);
alter table call2206n add person varchar(3);
alter table call2207n add person varchar(3);
alter table call2208n add person varchar(3);
alter table call2209n add person varchar(3);
alter table call2210n add person varchar(3);
------------------------------------------------------

alter table call2301y add person varchar(3);
alter table call2302y add person varchar(3);
alter table call2303y add person varchar(3);
alter table call2304y add person varchar(3);
alter table call2305y add person varchar(3);
alter table call2306y add person varchar(3);
alter table call2307y add person varchar(3);
alter table call2308y add person varchar(3);
alter table call2309y add person varchar(3);
alter table call2310y  add person varchar(3);

alter table call2301n add person varchar(3);
alter table call2302n add person varchar(3);
alter table call2303n add person varchar(3);
alter table call2304n add person varchar(3);
alter table call2305n add person varchar(3);
alter table call2306n add person varchar(3);
alter table call2307n add person varchar(3);
alter table call2308n add person varchar(3);
alter table call2309n add person varchar(3);
alter table call2310n add person varchar(3);

------------------------------------------------------
alter table call3401y add person varchar(3);
alter table call3402y add person varchar(3);
alter table call3403y add person varchar(3);
alter table call3404y add person varchar(3);
alter table call3405y add person varchar(3);
alter table call3406y add person varchar(3);
alter table call3407y add person varchar(3);
alter table call3408y add person varchar(3);
alter table call3409y add person varchar(3);
alter table call3410y  add person varchar(3);

alter table call3401n add person varchar(3);
alter table call3402n add person varchar(3);
alter table call3403n add person varchar(3);
alter table call3404n add person varchar(3);
alter table call3405n add person varchar(3);
alter table call3406n add person varchar(3);
alter table call3407n add person varchar(3);
alter table call3408n add person varchar(3);
alter table call3409n add person varchar(3);
alter table call3410n add person varchar(3);
---------------------------------------------

alter table call3901y add person varchar(3);
alter table call3902y add person varchar(3);
alter table call3903y add person varchar(3);
alter table call3904y add person varchar(3);
alter table call3905y add person varchar(3);
alter table call3906y add person varchar(3);
alter table call3907y add person varchar(3);
alter table call3908y add person varchar(3);
alter table call3909y add person varchar(3);
alter table call3910y  add person varchar(3);

alter table call3901n add person varchar(3);
alter table call3902n add person varchar(3);
alter table call3903n add person varchar(3);
alter table call3904n add person varchar(3);
alter table call3905n add person varchar(3);
alter table call3906n add person varchar(3);
alter table call3907n add person varchar(3);
alter table call3908n add person varchar(3);
alter table call3909n add person varchar(3);
alter table call3910n add person varchar(3);
-----------------------------------------------

alter table call4201y add person varchar(3);
alter table call4202y add person varchar(3);
alter table call4203y add person varchar(3);
alter table call4204y add person varchar(3);
alter table call4205y add person varchar(3);
alter table call4206y add person varchar(3);
alter table call4207y add person varchar(3);
alter table call4208y add person varchar(3);
alter table call4209y add person varchar(3);
alter table call4210y  add person varchar(3);

alter table call4201n add person varchar(3);
alter table call4202n add person varchar(3);
alter table call4203n add person varchar(3);
alter table call4204n add person varchar(3);
alter table call4205n add person varchar(3);
alter table call4206n add person varchar(3);
alter table call4207n add person varchar(3);
alter table call4208n add person varchar(3);
alter table call4209n add person varchar(3);
alter table call4210n add person varchar(3);
-------------------------------------------------

alter table call4601y add person varchar(3);
alter table call4602y add person varchar(3);
alter table call4603y add person varchar(3);
alter table call4604y add person varchar(3);
alter table call4605y add person varchar(3);
alter table call4606y add person varchar(3);
alter table call4607y add person varchar(3);
alter table call4608y add person varchar(3);
alter table call4609y add person varchar(3);
alter table call4610y  add person varchar(3);

alter table call4601n add person varchar(3);
alter table call4602n add person varchar(3);
alter table call4603n add person varchar(3);
alter table call4604n add person varchar(3);
alter table call4605n add person varchar(3);
alter table call4606n add person varchar(3);
alter table call4607n add person varchar(3);
alter table call4608n add person varchar(3);
alter table call4609n add person varchar(3);
alter table call4610n add person varchar(3);

----------------------------

alter table call6601y add person varchar(3);
alter table call6602y add person varchar(3);
alter table call6603y add person varchar(3);
alter table call6604y add person varchar(3);
alter table call6605y add person varchar(3);
alter table call6606y add person varchar(3);
alter table call6607y add person varchar(3);
alter table call6608y add person varchar(3);
alter table call6609y add person varchar(3);
alter table call6610y  add person varchar(3);

alter table call6601n add person varchar(3);
alter table call6602n add person varchar(3);
alter table call6603n add person varchar(3);
alter table call6604n add person varchar(3);
alter table call6605n add person varchar(3);
alter table call6606n add person varchar(3);
alter table call6607n add person varchar(3);
alter table call6608n add person varchar(3);
alter table call6609n add person varchar(3);
alter table call6610n add person varchar(3);
---------------------------------------------

alter table call7101y add person varchar(3);
alter table call7102y add person varchar(3);
alter table call7103y add person varchar(3);
alter table call7104y add person varchar(3);
alter table call7105y add person varchar(3);
alter table call7106y add person varchar(3);
alter table call7107y add person varchar(3);
alter table call7108y add person varchar(3);
alter table call7109y add person varchar(3);
alter table call7110y  add person varchar(3);

alter table call7101n add person varchar(3);
alter table call7102n add person varchar(3);
alter table call7103n add person varchar(3);
alter table call7104n add person varchar(3);
alter table call7105n add person varchar(3);
alter table call7106n add person varchar(3);
alter table call7107n add person varchar(3);
alter table call7108n add person varchar(3);
alter table call7109n add person varchar(3);
alter table call7110n add person varchar(3);

------------------------------------------------

alter table call7401y add person varchar(3);
alter table call7402y add person varchar(3);
alter table call7403y add person varchar(3);
alter table call7404y add person varchar(3);
alter table call7405y add person varchar(3);
alter table call7406y add person varchar(3);
alter table call7407y add person varchar(3);
alter table call7408y add person varchar(3);
alter table call7409y add person varchar(3);
alter table call7410y  add person varchar(3);

alter table call7401n add person varchar(3);
alter table call7402n add person varchar(3);
alter table call7403n add person varchar(3);
alter table call7404n add person varchar(3);
alter table call7405n add person varchar(3);
alter table call7406n add person varchar(3);
alter table call7407n add person varchar(3);
alter table call7408n add person varchar(3);
alter table call7409n add person varchar(3);
alter table call7410n add person varchar(3);

-----------------------------------------------

alter table call8301y add person varchar(3);
alter table call8302y add person varchar(3);
alter table call8303y add person varchar(3);
alter table call8304y add person varchar(3);
alter table call8305y add person varchar(3);
alter table call8306y add person varchar(3);
alter table call8307y add person varchar(3);
alter table call8308y add person varchar(3);
alter table call8309y add person varchar(3);
alter table call8310y  add person varchar(3);

alter table call8301n add person varchar(3);
alter table call8302n add person varchar(3);
alter table call8303n add person varchar(3);
alter table call8304n add person varchar(3);
alter table call8305n add person varchar(3);
alter table call8306n add person varchar(3);
alter table call8307n add person varchar(3);
alter table call8308n add person varchar(3);
alter table call8309n add person varchar(3);
alter table call8310n add person varchar(3);

-------------------------------------------
alter table call9101y add person varchar(3);
alter table call9102y add person varchar(3);
alter table call9103y add person varchar(3);
alter table call9104y add person varchar(3);
alter table call9105y add person varchar(3);
alter table call9106y add person varchar(3);
alter table call9107y add person varchar(3);
alter table call9108y add person varchar(3);
alter table call9109y add person varchar(3);
alter table call9110y  add person varchar(3);

alter table call9101n add person varchar(3);
alter table call9102n add person varchar(3);
alter table call9103n add person varchar(3);
alter table call9104n add person varchar(3);
alter table call9105n add person varchar(3);
alter table call9106n add person varchar(3);
alter table call9107n add person varchar(3);
alter table call9108n add person varchar(3);
alter table call9109n add person varchar(3);
alter table call9110n add person varchar(3);
--------------------------------------------

alter table call9401y add person varchar(3);
alter table call9402y add person varchar(3);
alter table call9403y add person varchar(3);
alter table call9404y add person varchar(3);
alter table call9405y add person varchar(3);
alter table call9406y add person varchar(3);
alter table call9407y add person varchar(3);
alter table call9408y add person varchar(3);
alter table call9409y add person varchar(3);
alter table call9410y  add person varchar(3);

alter table call9401n add person varchar(3);
alter table call9402n add person varchar(3);
alter table call9403n add person varchar(3);
alter table call9404n add person varchar(3);
alter table call9405n add person varchar(3);
alter table call9406n add person varchar(3);
alter table call9407n add person varchar(3);
alter table call9408n add person varchar(3);
alter table call9409n add person varchar(3);
alter table call9410n add person varchar(3);
---------------------------------------------

alter table call9501y add person varchar(3);
alter table call9502y add person varchar(3);
alter table call9503y add person varchar(3);
alter table call9504y add person varchar(3);
alter table call9505y add person varchar(3);
alter table call9506y add person varchar(3);
alter table call9507y add person varchar(3);
alter table call9508y add person varchar(3);
alter table call9509y add person varchar(3);
alter table call9510y  add person varchar(3);

alter table call9501n add person varchar(3);
alter table call9502n add person varchar(3);
alter table call9503n add person varchar(3);
alter table call9504n add person varchar(3);
alter table call9505n add person varchar(3);
alter table call9506n add person varchar(3);
alter table call9507n add person varchar(3);
alter table call9508n add person varchar(3);
alter table call9509n add person varchar(3);
alter table call9510n add person varchar(3);