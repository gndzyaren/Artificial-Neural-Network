SELECT * FROM mitclean.cspan2;
---------------------------
-----------------------------CSPAN------------------
CREATE TABLE cspan39 as select * from cspan2 where person_oid=39 order by rand() limit 400;
create table cspan39a as select * from mitclean.cspan39 order by starttime limit 320;
create table cspan39b as SELECT * FROM (
    SELECT * FROM cspan39 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;

---------------------------ASPAN---------------------------------
CREATE TABLE aspan39 AS SELECT * FROM aspan2 where person_oid = 39 order by rand() limit 800;
create table aspan39a as select * from mitclean.aspan39 order by starttime limit 640;
create table aspan39b as SELECT * FROM (
    SELECT * FROM aspan39 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;

-----------------------------DSPAN-------------------------------------
CREATE TABLE dspan39 AS SELECT * FROM dspan2 where person_oid = 39 order by rand() limit 800;
create table dspan39a as select * from mitclean.dspan39 order by starttime limit 640;
create table dspan39b as SELECT * FROM (
    SELECT * FROM dspan39 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;

----------------------------CESPAN---------------------------
CREATE TABLE cespan39 AS SELECT * FROM cespan2 where person_oid = 39 order by rand() limit 8000;
create table cespan39a as select * from mitclean.cespan39 order by starttime limit 6400;
create table cespan39b as SELECT * FROM (
    SELECT * FROM cespan39 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;





-------------------------------
/*Kullanıcı 13 için*/
-------------------------------
-----------------------CESPAN-----------------
CREATE TABLE cespan13 AS SELECT * FROM cespan2 where person_oid = 13 order by rand() limit 8000;
create table cespan13a as select * from mitclean.cespan13 order by starttime limit 6400;
create table cespan13b as SELECT * FROM (
    SELECT * FROM cespan13 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;

---------------------CSPAN-----------------
CREATE TABLE cspan13 as select * from cspan2 where person_oid=13 order by rand() limit 400;
create table cspan13a as select * from mitclean.cspan13 order by starttime limit 320;
create table cspan13b as SELECT * FROM (
    SELECT * FROM cspan13 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;

----------------------ASPAN------------------
CREATE TABLE aspan13 AS SELECT * FROM aspan2 where person_oid = 13 order by rand() limit 800;
create table aspan13a as select * from mitclean.aspan13 order by starttime limit 640;
create table aspan13b as SELECT * FROM (
    SELECT * FROM aspan13 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;

----------------------DSPAN------------------------
CREATE TABLE dspan13 AS SELECT * FROM dspan2 where person_oid = 13 order by rand() limit 800;
create table dspan13a as select * from mitclean.dspan13 order by starttime limit 640;
create table dspan13b as SELECT * FROM (
    SELECT * FROM dspan13 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------------





/*Kullanıcı 17 için*/
----------------------------CESPAN--------------------
CREATE TABLE cespan17 AS SELECT * FROM cespan2 where person_oid = 17 order by rand() limit 8000;
create table cespan17a as select * from mitclean.cespan17 order by starttime limit 6400;
create table cespan17b as SELECT * FROM (
    SELECT * FROM cespan17 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;

---------------------------CSPAN----------------------
CREATE TABLE cspan17 as select * from cspan2 where person_oid=17 order by rand() limit 400;
create table cspan17a as select * from mitclean.cspan17 order by starttime limit 320;
create table cspan17b as SELECT * FROM (
    SELECT * FROM mitclean.cspan17 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
--------------------------ASPAN----------------------------
CREATE TABLE aspan17 AS SELECT * FROM aspan2 where person_oid = 17 order by rand() limit 800;
create table aspan17a as select * from mitclean.aspan17 order by starttime limit 640;
create table aspan17b as SELECT * FROM (
    SELECT * FROM aspan2 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;

---------------------------------DSPAN----------------
CREATE TABLE dspan17 AS SELECT * FROM dspan2 where person_oid = 17 order by rand() limit 800;
create table dspan17a as select * from mitclean.dspan17 order by starttime limit 640;
create table dspan17b as SELECT * FROM (
    SELECT * FROM dspan2 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------




/* Kullanıcı 22 için*/
----------------------------------------CESPAN----------------------
CREATE TABLE cespan22 AS SELECT * FROM cespan2 where person_oid = 22 order by rand() limit 8000;
create table cespan22a as select * from mitclean.cespan22 order by starttime limit 6400;
create table cespan22b as SELECT * FROM (
    SELECT * FROM cespan22 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
------------------------------------CSPAN-----------------
CREATE TABLE cspan22 as select * from cspan2 where person_oid=22 order by rand() limit 400;
create table cspan22a as select * from mitclean.cspan22 order by starttime limit 320;
create table cspan22b as SELECT * FROM (
    SELECT * FROM cspan22 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;

------------------------------ASPAN------------------------------
CREATE TABLE aspan22 AS SELECT * FROM aspan2 where person_oid = 22 order by rand() limit 800;
create table aspan22a as select * from mitclean.aspan22 order by starttime limit 640;
create table aspan22b as SELECT * FROM (
    SELECT * FROM aspan22 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;

-------------------------------------DSPAN-------------------
CREATE TABLE dspan22 AS SELECT * FROM dspan2 where person_oid = 22 order by rand() limit 800;
create table dspan22a as select * from mitclean.dspan22 order by starttime limit 640;
create table dspan22b as SELECT * FROM (
    SELECT * FROM dspan22 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
---------------------------------------------------------






/* Kullanıcı 23 için*/
--------------------CESPAN------------------------
CREATE TABLE cespan23 AS SELECT * FROM cespan2 where person_oid = 23 order by rand() limit 8000;
create table cespan23a as select * from mitclean.cespan23 order by starttime limit 6400;
create table cespan23b as SELECT * FROM (
    SELECT * FROM cespan23 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
--------------------------CSPAN----------------------
CREATE TABLE cspan23 as select * from cspan2 where person_oid=23 order by rand() limit 400;
create table cspan23a as select * from mitclean.cspan23 order by starttime limit 320;
create table cspan23b as SELECT * FROM (
    SELECT * FROM cspan23 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan23 AS SELECT * FROM aspan2 where person_oid = 23 order by rand() limit 800;
create table aspan23a as select * from mitclean.aspan23 order by starttime limit 640;
create table aspan23b as SELECT * FROM (
    SELECT * FROM aspan23 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
-------------------------DSPAN--------
CREATE TABLE dspan23 AS SELECT * FROM dspan2 where person_oid = 23 order by rand() limit 800;
create table dspan23a as select * from mitclean.dspan23 order by starttime limit 640;
create table dspan23b as SELECT * FROM (
    SELECT * FROM dspan23 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
----------------------------------------------







/*Kullanıcı 34 için*/
---------------------------CESPAN--------------
CREATE TABLE cespan34 AS SELECT * FROM cespan2 where person_oid = 34 order by rand() limit 8000;
create table cespan34a as select * from mitclean.cespan34 order by starttime limit 6400;
create table cespan34b as SELECT * FROM (
    SELECT * FROM cespan34 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan34 as select * from cspan2 where person_oid=34 order by rand() limit 400;
create table cspan34a as select * from mitclean.cspan34 order by starttime limit 320;
create table cspan34b as SELECT * FROM (
    SELECT * FROM cspan34 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan34 AS SELECT * FROM aspan2 where person_oid = 34 order by rand() limit 800;
create table aspan34a as select * from mitclean.aspan34 order by starttime limit 640;
create table aspan34b as SELECT * FROM (
    SELECT * FROM aspan34 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan34 AS SELECT * FROM dspan2 where person_oid = 34 order by rand() limit 800;
create table dspan34a as select * from mitclean.dspan34 order by starttime limit 640;
create table dspan34b as SELECT * FROM (
    SELECT * FROM dspan34 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
-------------------------------------




/*Kullanıcı 42 için*/
---------------------------CESPAN--------------
CREATE TABLE cespan42 AS SELECT * FROM cespan2 where person_oid = 42 order by rand() limit 8000;
create table cespan42a as select * from mitclean.cespan42 order by starttime limit 6400;
create table cespan42b as SELECT * FROM (
    SELECT * FROM cespan42 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan42 as select * from cspan2 where person_oid=42 order by rand() limit 400;
create table cspan42a as select * from mitclean.cspan42 order by starttime limit 320;
create table cspan42b as SELECT * FROM (
    SELECT * FROM cspan42 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan42 AS SELECT * FROM aspan2 where person_oid = 42 order by rand() limit 800;
create table aspan42a as select * from mitclean.aspan42 order by starttime limit 640;
create table aspan42b as SELECT * FROM (
    SELECT * FROM aspan42 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan42 AS SELECT * FROM dspan2 where person_oid = 42 order by rand() limit 800;
create table dspan42a as select * from mitclean.dspan42 order by starttime limit 640;
create table dspan42b as SELECT * FROM (
    SELECT * FROM dspan42 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
-------------------------------------





/* Kullanıcı 46 için*/
---------------------------CESPAN--------------
CREATE TABLE cespan46 AS SELECT * FROM cespan2 where person_oid = 46 order by rand() limit 8000;
create table cespan46a as select * from mitclean.cespan46 order by starttime limit 6400;
create table cespan46b as SELECT * FROM (
    SELECT * FROM cespan46 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan46 as select * from cspan2 where person_oid=46 order by rand() limit 400;
create table cspan46a as select * from mitclean.cspan46 order by starttime limit 320;
create table cspan46b as SELECT * FROM (
    SELECT * FROM cspan46 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan46 AS SELECT * FROM aspan2 where person_oid = 46 order by rand() limit 800;
create table aspan46a as select * from mitclean.aspan46 order by starttime limit 640;
create table aspan46b as SELECT * FROM (
    SELECT * FROM aspan46 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan46 AS SELECT * FROM dspan2 where person_oid = 46 order by rand() limit 800;
create table dspan46a as select * from mitclean.dspan46 order by starttime limit 640;
create table dspan46b as SELECT * FROM (
    SELECT * FROM dspan46 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;

/*Kullanıcı 66 için*/
---------------------------CESPAN--------------
CREATE TABLE cespan66 AS SELECT * FROM cespan2 where person_oid = 66 order by rand() limit 8000;
create table cespan66a as select * from mitclean.cespan66 order by starttime limit 6400;
create table cespan66b as SELECT * FROM (
    SELECT * FROM cespan66 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan66 as select * from cspan2 where person_oid=66 order by rand() limit 400;
create table cspan66a as select * from mitclean.cspan66 order by starttime limit 320;
create table cspan66b as SELECT * FROM (
    SELECT * FROM cspan66 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan66 AS SELECT * FROM aspan2 where person_oid = 66 order by rand() limit 800;
create table aspan66a as select * from mitclean.aspan66 order by starttime limit 640;
create table aspan66b as SELECT * FROM (
    SELECT * FROM aspan66 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan66 AS SELECT * FROM dspan2 where person_oid = 66 order by rand() limit 800;
create table dspan66a as select * from mitclean.dspan66 order by starttime limit 640;
create table dspan66b as SELECT * FROM (
    SELECT * FROM dspan66 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;


/*Kullanıcı 71 için */
---------------------------CESPAN--------------
CREATE TABLE cespan71 AS SELECT * FROM cespan2 where person_oid = 71 order by rand() limit 8000;
create table cespan71a as select * from mitclean.cespan71 order by starttime limit 6400;
create table cespan71b as SELECT * FROM (
    SELECT * FROM cespan71 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan71 as select * from cspan2 where person_oid=71 order by rand() limit 400;
create table cspan71a as select * from mitclean.cspan71 order by starttime limit 320;
create table cspan71b as SELECT * FROM (
    SELECT * FROM cspan71 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan71 AS SELECT * FROM aspan2 where person_oid = 71 order by rand() limit 800;
create table aspan71a as select * from mitclean.aspan71 order by starttime limit 640;
create table aspan71b as SELECT * FROM (
    SELECT * FROM aspan71 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan71 AS SELECT * FROM dspan2 where person_oid = 71 order by rand() limit 800;
create table dspan71a as select * from mitclean.dspan71 order by starttime limit 640;
create table dspan71b as SELECT * FROM (
    SELECT * FROM dspan71 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;

/*Kullanıcı 74 için*/
---------------------------CESPAN--------------
CREATE TABLE cespan74 AS SELECT * FROM cespan2 where person_oid = 74 order by rand() limit 8000;
create table cespan74a as select * from mitclean.cespan74 order by starttime limit 6400;
create table cespan74b as SELECT * FROM (
    SELECT * FROM cespan74 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan74 as select * from cspan2 where person_oid=74 order by rand() limit 400;
create table cspan74a as select * from mitclean.cspan74 order by starttime limit 320;
create table cspan74b as SELECT * FROM (
    SELECT * FROM cspan74 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan74 AS SELECT * FROM aspan2 where person_oid = 74 order by rand() limit 800;
create table aspan74a as select * from mitclean.aspan74 order by starttime limit 640;
create table aspan74b as SELECT * FROM (
    SELECT * FROM aspan74 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan74 AS SELECT * FROM dspan2 where person_oid = 74 order by rand() limit 800;
create table dspan74a as select * from mitclean.dspan74 order by starttime limit 640;
create table dspan74b as SELECT * FROM (
    SELECT * FROM dspan74 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;




/*Kullanıcı 83 için*/
---------------------------CESPAN--------------
CREATE TABLE cespan83 AS SELECT * FROM cespan2 where person_oid = 83 order by rand() limit 8000;
create table cespan83a as select * from mitclean.cespan83 order by starttime limit 6400;
create table cespan83b as SELECT * FROM (
    SELECT * FROM cespan83 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan83 as select * from cspan2 where person_oid=83 order by rand() limit 400;
create table cspan83a as select * from mitclean.cspan83 order by starttime limit 320;
create table cspan83b as SELECT * FROM (
    SELECT * FROM cspan83 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan83 AS SELECT * FROM aspan2 where person_oid = 83 order by rand() limit 800;
create table aspan83a as select * from mitclean.aspan83 order by starttime limit 640;
create table aspan83b as SELECT * FROM (
    SELECT * FROM aspan83 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan83 AS SELECT * FROM dspan2 where person_oid = 83 order by rand() limit 800;
create table dspan83a as select * from mitclean.dspan83 order by starttime limit 640;
create table dspan83b as SELECT * FROM (
    SELECT * FROM dspan83 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;




/*Kullanıcı 91 için*/

---------------------------CESPAN--------------
CREATE TABLE cespan91 AS SELECT * FROM cespan2 where person_oid = 91 order by rand() limit 8000;
create table cespan91a as select * from mitclean.cespan91 order by starttime limit 6400;
create table cespan91b as SELECT * FROM (
    SELECT * FROM cespan91 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan91 as select * from cspan2 where person_oid=91 order by rand() limit 400;
create table cspan91a as select * from mitclean.cspan91 order by starttime limit 320;
create table cspan91b as SELECT * FROM (
    SELECT * FROM cspan91 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan91 AS SELECT * FROM aspan2 where person_oid = 91 order by rand() limit 800;
create table aspan91a as select * from mitclean.aspan91 order by starttime limit 640;
create table aspan91b as SELECT * FROM (
    SELECT * FROM aspan91 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan91 AS SELECT * FROM dspan2 where person_oid = 91 order by rand() limit 800;
create table dspan91a as select * from mitclean.dspan91 order by starttime limit 640;
create table dspan91b as SELECT * FROM (
    SELECT * FROM dspan91 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;



/*Kullanıcı 94 için*/

---------------------------CESPAN--------------
CREATE TABLE cespan94 AS SELECT * FROM cespan2 where person_oid = 94 order by rand() limit 8000;
create table cespan94a as select * from mitclean.cespan94 order by starttime limit 6400;
create table cespan94b as SELECT * FROM (
    SELECT * FROM cespan94 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan94 as select * from cspan2 where person_oid=94 order by rand() limit 400;
create table cspan94a as select * from mitclean.cspan94 order by starttime limit 320;
create table cspan94b as SELECT * FROM (
    SELECT * FROM cspan94 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan94 AS SELECT * FROM aspan2 where person_oid = 94 order by rand() limit 800;
create table aspan94a as select * from mitclean.aspan94 order by starttime limit 640;
create table aspan94b as SELECT * FROM (
    SELECT * FROM aspan94 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan94 AS SELECT * FROM dspan2 where person_oid = 94 order by rand() limit 800;
create table dspan94a as select * from mitclean.dspan94 order by starttime limit 640;
create table dspan94b as SELECT * FROM (
    SELECT * FROM dspan94 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;


/*Kullanıcı 95 için*/

---------------------------CESPAN--------------
CREATE TABLE cespan95 AS SELECT * FROM cespan2 where person_oid = 95 order by rand() limit 8000;
create table cespan95a as select * from mitclean.cespan95 order by starttime limit 6400;
create table cespan95b as SELECT * FROM (
    SELECT * FROM cespan95 ORDER BY starttime DESC LIMIT 1600
) sub ORDER BY starttime ASC;
-------------------------CSPAN---------------
CREATE TABLE cspan95 as select * from cspan2 where person_oid=95 order by rand() limit 400;
create table cspan95a as select * from mitclean.cspan95 order by starttime limit 320;
create table cspan95b as SELECT * FROM (
    SELECT * FROM cspan95 ORDER BY starttime DESC LIMIT 80
) sub ORDER BY starttime ASC;
------------------------ASPAN--------------
CREATE TABLE aspan95 AS SELECT * FROM aspan2 where person_oid = 95 order by rand() limit 800;
create table aspan95a as select * from mitclean.aspan95 order by starttime limit 640;
create table aspan95b as SELECT * FROM (
    SELECT * FROM aspan95 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;
------------------------DSPAN---------------
CREATE TABLE dspan95 AS SELECT * FROM dspan2 where person_oid = 95 order by rand() limit 800;
create table dspan95a as select * from mitclean.dspan95 order by starttime limit 640;
create table dspan95b as SELECT * FROM (
    SELECT * FROM dspan95 ORDER BY starttime DESC LIMIT 160
) sub ORDER BY starttime ASC;





