********************DEVICESPAN13***********
create table device1301y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1302y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1303y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1304y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1305y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1306y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1307y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1308y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1309y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 
create table device1310y as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 350; 

create table device1301n as SELECT * FROM dspan13a ORDER by RAND() LIMIT 25;
create table device1302n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1303n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1304n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1305n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1306n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1307n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1308n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1309n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 
create table device1310n as SELECT * FROM dspan13a ORDER BY RAND() LIMIT 25; 

create table devicet1301 as SELECT * FROM dspan13b ORDER BY RAND() LIMIT 120;


************************************************************************
----------------DEVICESPAN17-----
create table device1701y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1702y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1703y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1704y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1705y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1706y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1707y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1708y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1709y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 
create table device1710y as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 350; 

create table device1701n as SELECT * FROM dspan17a ORDER by RAND() LIMIT 25;
create table device1702n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1703n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1704n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1705n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1706n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1707n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1708n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1709n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 
create table device1710n as SELECT * FROM dspan17a ORDER BY RAND() LIMIT 25; 

create table devicet1701 as SELECT * FROM dspan17b ORDER BY RAND() LIMIT 120;
***************************************************************************
--------------------DEVIECSPAN22----------------
create table device2201y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2202y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2203y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2204y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2205y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2206y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2207y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2208y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2209y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 
create table device2210y as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 350; 

create table device2201n as SELECT * FROM dspan22a ORDER by RAND() LIMIT 25;
create table device2202n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2203n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2204n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2205n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2206n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2207n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2208n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2209n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 
create table device2210n as SELECT * FROM dspan22a ORDER BY RAND() LIMIT 25; 

create table devicet2201 as SELECT * FROM dspan22b ORDER BY RAND() LIMIT 120;   
******************************************************************************
------------------------DEVICESPAN23-----------
create table device2301y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2302y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2303y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2304y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2305y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2306y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2307y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2308y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2309y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 
create table device2310y as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 350; 

create table device2301n as SELECT * FROM dspan23a ORDER by RAND() LIMIT 25;
create table device2302n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2303n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2304n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2305n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2306n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2307n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2308n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2309n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device2310n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 

create table devicet2301 as SELECT * FROM dspan23b ORDER BY RAND() LIMIT 120;

**************************DEVICESPAN34****************
create table device3401y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3402y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3403y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3404y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3405y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3406y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3407y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3408y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3409y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 
create table device3410y as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 350; 

create table device3401n as SELECT * FROM dspan34a ORDER by RAND() LIMIT 25;
create table device3402n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 
create table device3403n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 
create table device3404n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 
create table device3405n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 
create table device3406n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 
create table device3407n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 
create table device3408n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device3409n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 
create table device3410n as SELECT * FROM dspan34a ORDER BY RAND() LIMIT 25; 

create table devicet3401 as SELECT * FROM dspan34b ORDER BY RAND() LIMIT 120;


**********************************************
-------------------DEVICESPAN39------------------
create table device3901y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3902y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3903y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3904y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3905y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3906y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3907y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3908y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3909y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 
create table device3910y as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 350; 

create table device3901n as SELECT * FROM dspan39a ORDER by RAND() LIMIT 25;
create table device3902n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 
create table device3903n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 
create table device3904n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 
create table device3905n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 
create table device3906n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 
create table device3907n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 
create table device3908n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device3909n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 
create table device3910n as SELECT * FROM dspan39a ORDER BY RAND() LIMIT 25; 

create table devicet3901 as SELECT * FROM dspan39b ORDER BY RAND() LIMIT 120;
**********************************************************************************
-------------------DEVICESPAN42--------------------
create table device4201y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4202y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4203y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4204y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4205y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4206y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4207y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4208y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4209y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 
create table device4210y as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 350; 

create table device4201n as SELECT * FROM dspan42a ORDER by RAND() LIMIT 25;
create table device4202n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 
create table device4203n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 
create table device4204n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 
create table device4205n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 
create table device4206n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 
create table device4207n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 
create table device4208n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device4209n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 
create table device4210n as SELECT * FROM dspan42a ORDER BY RAND() LIMIT 25; 

create table devicet4201 as SELECT * FROM dspan42b ORDER BY RAND() LIMIT 120;
**********************************************************************************
--------------------------DEVICESPAN46----------
create table device4601y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4602y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4603y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4604y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4605y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4606y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4607y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4608y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4609y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 
create table device4610y as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 350; 

create table device4601n as SELECT * FROM dspan46a ORDER by RAND() LIMIT 25;
create table device4602n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 
create table device4603n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 
create table device4604n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 
create table device4605n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 
create table device4606n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 
create table device4607n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 
create table device4608n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device4609n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 
create table device4610n as SELECT * FROM dspan46a ORDER BY RAND() LIMIT 25; 

create table devicet4601 as SELECT * FROM dspan46b ORDER BY RAND() LIMIT 120;
***********************************************************************************
----------------------------DEVICESPAN66-----------------
create table device6601y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6602y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6603y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6604y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6605y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6606y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6607y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6608y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6609y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 
create table device6610y as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 350; 

create table device6601n as SELECT * FROM dspan66a ORDER by RAND() LIMIT 25;
create table device6602n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 
create table device6603n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 
create table device6604n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 
create table device6605n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 
create table device6606n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 
create table device6607n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 
create table device6608n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device6609n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 
create table device6610n as SELECT * FROM dspan66a ORDER BY RAND() LIMIT 25; 

create table devicet6601 as SELECT * FROM dspan66b ORDER BY RAND() LIMIT 120;
****************************************************************************
-----------------------------DEVICESPAN71------------
create table device7101y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7102y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7103y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7104y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7105y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7106y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7107y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7108y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7109y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 
create table device7110y as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 350; 

create table device7101n as SELECT * FROM dspan71a ORDER by RAND() LIMIT 25;
create table device7102n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 
create table device7103n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 
create table device7104n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 
create table device7105n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 
create table device7106n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 
create table device7107n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 
create table device7108n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device7109n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 
create table device7110n as SELECT * FROM dspan71a ORDER BY RAND() LIMIT 25; 

create table devicet7101 as SELECT * FROM dspan71b ORDER BY RAND() LIMIT 120;
**********************************************
---------DEVICESPAN74----------
create table device7401y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7402y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7403y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7404y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7405y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7406y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7407y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7408y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7409y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 
create table device7410y as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 350; 

create table device7401n as SELECT * FROM dspan74a ORDER by RAND() LIMIT 25;
create table device7402n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 
create table device7403n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 
create table device7404n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 
create table device7405n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 
create table device7406n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 
create table device7407n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 
create table device7408n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device7409n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 
create table device7410n as SELECT * FROM dspan74a ORDER BY RAND() LIMIT 25; 

create table devicet7401 as SELECT * FROM dspan74b ORDER BY RAND() LIMIT 120;
****************************************************
------------DEVICESPAN83----------
create table device8301y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8302y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8303y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8304y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8305y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8306y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8307y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8308y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8309y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 
create table device8310y as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 350; 

create table device8301n as SELECT * FROM dspan83a ORDER by RAND() LIMIT 25;
create table device8302n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 
create table device8303n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 
create table device8304n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 
create table device8305n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 
create table device8306n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 
create table device8307n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 
create table device8308n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device8309n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 
create table device8310n as SELECT * FROM dspan83a ORDER BY RAND() LIMIT 25; 

create table devicet8301 as SELECT * FROM dspan83b ORDER BY RAND() LIMIT 120;
************************************************************
--------------------DEVICESPAN91-----------
create table device9101y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9102y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9103y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9104y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9105y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9106y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9107y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9108y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9109y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 
create table device9110y as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 350; 

create table device9101n as SELECT * FROM dspan91a ORDER by RAND() LIMIT 25;
create table device9102n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 
create table device9103n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 
create table device9104n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 
create table device9105n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 
create table device9106n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 
create table device9107n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 
create table device9108n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device9109n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 
create table device9110n as SELECT * FROM dspan91a ORDER BY RAND() LIMIT 25; 

create table devicet9101 as SELECT * FROM dspan91b ORDER BY RAND() LIMIT 120;
***************************************************************
---------------------DEVICESPAN94------------
create table device9401y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9402y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9403y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9404y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9405y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9406y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9407y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9408y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9409y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 
create table device9410y as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 350; 

create table device9401n as SELECT * FROM dspan94a ORDER by RAND() LIMIT 25;
create table device9402n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 
create table device9403n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 
create table device9404n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 
create table device9405n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 
create table device9406n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 
create table device9407n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 
create table device9408n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device9409n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 
create table device9410n as SELECT * FROM dspan94a ORDER BY RAND() LIMIT 25; 

create table devicet9401 as SELECT * FROM dspan94b ORDER BY RAND() LIMIT 120;
*******************************************
--------------------------DEVICESPAN95---------
create table device9501y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9502y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9503y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9504y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9505y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9506y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9507y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9508y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9509y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 
create table device9510y as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 350; 

create table device9501n as SELECT * FROM dspan95a ORDER by RAND() LIMIT 25;
create table device9502n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 
create table device9503n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 
create table device9504n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 
create table device9505n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 
create table device9506n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 
create table device9507n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 
create table device9508n as SELECT * FROM dspan23a ORDER BY RAND() LIMIT 25; 
create table device9509n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 
create table device9510n as SELECT * FROM dspan95a ORDER BY RAND() LIMIT 25; 

create table devicet9501 as SELECT * FROM dspan95b ORDER BY RAND() LIMIT 120;
