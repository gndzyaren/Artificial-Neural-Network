create table if not exists activityt13y as(select * from activityt1301);
alter table activityt13y add person varchar(3);
update activityt13y set person='YES';

create table if not exists activityt13n as(select * from activityt1301);
alter table activityt13n add person varchar(3);
update activityt13n set person='NO';

create table if not exists activityt17y as(select * from activityt1701);
alter table activityt17y add person varchar(3);
update activityt17y set person='YES';

create table if not exists activityt17n as(select * from activityt1701);
alter table activityt17n add person varchar(3);
update activityt17n set person='NO';

create table if not exists activityt22y as(select * from activityt2201);
alter table activityt22y add person varchar(3);
update activityt22y set person='YES';

create table if not exists activityt22n as(select * from activityt2201);
alter table activityt22n add person varchar(3);
update activityt22n set person='NO';

create table if not exists activityt23y as(select * from activityt2301);
alter table activityt23y add person varchar(3);
update activityt23y set person='YES';

create table if not exists activityt23n as(select * from activityt2301);
alter table activityt23n add person varchar(3);
update activityt23n set person='NO';

create table if not exists activityt34y as(select * from activityt3401);
alter table activityt34y add person varchar(3);
update activityt34y set person='YES';

create table if not exists activityt34n as(select * from activityt3401);
alter table activityt34n add person varchar(3);
update activityt34n set person='NO';

create table if not exists activityt39y as(select * from activityt3901);
alter table activityt39y add person varchar(3);
update activityt39y set person='YES';

create table if not exists activityt39n as(select * from activityt3901);
alter table activityt39n add person varchar(3);
update activityt39n set person='NO';

create table if not exists activityt42y as(select * from activityt4201);
alter table activityt42y add person varchar(3);
update activityt42y set person='YES';

create table if not exists activityt42n as(select * from activityt4201);
alter table activityt42n add person varchar(3);
update activityt42n set person='NO';

create table if not exists activityt46y as(select * from activityt4601);
alter table activityt46y add person varchar(3);
update activityt46y set person='YES';

create table if not exists activityt46n as(select * from activityt4601);
alter table activityt46n add person varchar(3);
update activityt46n set person='NO';

create table if not exists activityt66y as(select * from activityt6601);
alter table activityt66y add person varchar(3);
update activityt66y set person='YES';

create table if not exists activityt66n as(select * from activityt6601);
alter table activityt66n add person varchar(3);
update activityt66n set person='NO';

create table if not exists activityt71y as(select * from activityt7101);
alter table activityt71y add person varchar(3);
update activityt71y set person='YES';

create table if not exists activityt71n as(select * from activityt7101);
alter table activityt71n add person varchar(3);
update activityt71n set person='NO';

create table if not exists activityt83y as(select * from activityt8301);
alter table activityt83y add person varchar(3);
update activityt83y set person='YES';

create table if not exists activityt83n as(select * from activityt8301);
alter table activityt83n add person varchar(3);
update activityt83n set person='NO';


create table if not exists activityt91y as(select * from activityt9101);
alter table activityt91y add person varchar(3);
update activityt91y set person='YES';

create table if not exists activityt91n as(select * from activityt9101);
alter table activityt91n add person varchar(3);
update activityt91n set person='NO';

create table if not exists activityt94y as(select * from activityt9401);
alter table activityt94y add person varchar(3);
update activityt94y set person='YES';

create table if not exists activityt94n as(select * from activityt9401);
alter table activityt94n add person varchar(3);
update activityt94n set person='NO';


create table if not exists activityt95y as(select * from activityt9501);
alter table activityt95y add person varchar(3);
update activityt95y set person='YES';

create table if not exists activityt95n as(select * from activityt9501);
alter table activityt95n add person varchar(3);
update activityt95n set person='NO';
