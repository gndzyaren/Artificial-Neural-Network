
-----------deviceSPAN-------------
alter table device1301y add person varchar(3);
alter table device1302y add person varchar(3);
alter table device1303y add person varchar(3);
alter table device1304y add person varchar(3);
alter table device1305y add person varchar(3);
alter table device1306y add person varchar(3);
alter table device1307y add person varchar(3);
alter table device1308y add person varchar(3);
alter table device1309y add person varchar(3);
alter table device1310y  add person varchar(3);

alter table device1301n add person varchar(3);
alter table device1302n add person varchar(3);
alter table device1303n add person varchar(3);
alter table device1304n add person varchar(3);
alter table device1305n add person varchar(3);
alter table device1306n add person varchar(3);
alter table device1307n add person varchar(3);
alter table device1308n add person varchar(3);
alter table device1309n add person varchar(3);
alter table device1310n add person varchar(3);

--------------------------------------------------------
alter table device1701y add person varchar(3);
alter table device1702y add person varchar(3);
alter table device1703y add person varchar(3);
alter table device1704y add person varchar(3);
alter table device1705y add person varchar(3);
alter table device1706y add person varchar(3);
alter table device1707y add person varchar(3);
alter table device1708y add person varchar(3);
alter table device1709y add person varchar(3);
alter table device1710y  add person varchar(3);

alter table device1701n add person varchar(3);
alter table device1702n add person varchar(3);
alter table device1703n add person varchar(3);
alter table device1704n add person varchar(3);
alter table device1705n add person varchar(3);
alter table device1706n add person varchar(3);
alter table device1707n add person varchar(3);
alter table device1708n add person varchar(3);
alter table device1709n add person varchar(3);
alter table device1710n add person varchar(3);

------------------------------------------------------
alter table device2201y add person varchar(3);
alter table device2202y add person varchar(3);
alter table device2203y add person varchar(3);
alter table device2204y add person varchar(3);
alter table device2205y add person varchar(3);
alter table device2206y add person varchar(3);
alter table device2207y add person varchar(3);
alter table device2208y add person varchar(3);
alter table device2209y add person varchar(3);
alter table device2210y  add person varchar(3);

alter table device2201n add person varchar(3);
alter table device2202n add person varchar(3);
alter table device2203n add person varchar(3);
alter table device2204n add person varchar(3);
alter table device2205n add person varchar(3);
alter table device2206n add person varchar(3);
alter table device2207n add person varchar(3);
alter table device2208n add person varchar(3);
alter table device2209n add person varchar(3);
alter table device2210n add person varchar(3);
------------------------------------------------------

alter table device2301y add person varchar(3);
alter table device2302y add person varchar(3);
alter table device2303y add person varchar(3);
alter table device2304y add person varchar(3);
alter table device2305y add person varchar(3);
alter table device2306y add person varchar(3);
alter table device2307y add person varchar(3);
alter table device2308y add person varchar(3);
alter table device2309y add person varchar(3);
alter table device2310y  add person varchar(3);

alter table device2301n add person varchar(3);
alter table device2302n add person varchar(3);
alter table device2303n add person varchar(3);
alter table device2304n add person varchar(3);
alter table device2305n add person varchar(3);
alter table device2306n add person varchar(3);
alter table device2307n add person varchar(3);
alter table device2308n add person varchar(3);
alter table device2309n add person varchar(3);
alter table device2310n add person varchar(3);

------------------------------------------------------
alter table device3401y add person varchar(3);
alter table device3402y add person varchar(3);
alter table device3403y add person varchar(3);
alter table device3404y add person varchar(3);
alter table device3405y add person varchar(3);
alter table device3406y add person varchar(3);
alter table device3407y add person varchar(3);
alter table device3408y add person varchar(3);
alter table device3409y add person varchar(3);
alter table device3410y  add person varchar(3);

alter table device3401n add person varchar(3);
alter table device3402n add person varchar(3);
alter table device3403n add person varchar(3);
alter table device3404n add person varchar(3);
alter table device3405n add person varchar(3);
alter table device3406n add person varchar(3);
alter table device3407n add person varchar(3);
alter table device3408n add person varchar(3);
alter table device3409n add person varchar(3);
alter table device3410n add person varchar(3);
---------------------------------------------

alter table device3901y add person varchar(3);
alter table device3902y add person varchar(3);
alter table device3903y add person varchar(3);
alter table device3904y add person varchar(3);
alter table device3905y add person varchar(3);
alter table device3906y add person varchar(3);
alter table device3907y add person varchar(3);
alter table device3908y add person varchar(3);
alter table device3909y add person varchar(3);
alter table device3910y  add person varchar(3);

alter table device3901n add person varchar(3);
alter table device3902n add person varchar(3);
alter table device3903n add person varchar(3);
alter table device3904n add person varchar(3);
alter table device3905n add person varchar(3);
alter table device3906n add person varchar(3);
alter table device3907n add person varchar(3);
alter table device3908n add person varchar(3);
alter table device3909n add person varchar(3);
alter table device3910n add person varchar(3);
-----------------------------------------------

alter table device4201y add person varchar(3);
alter table device4202y add person varchar(3);
alter table device4203y add person varchar(3);
alter table device4204y add person varchar(3);
alter table device4205y add person varchar(3);
alter table device4206y add person varchar(3);
alter table device4207y add person varchar(3);
alter table device4208y add person varchar(3);
alter table device4209y add person varchar(3);
alter table device4210y  add person varchar(3);

alter table device4201n add person varchar(3);
alter table device4202n add person varchar(3);
alter table device4203n add person varchar(3);
alter table device4204n add person varchar(3);
alter table device4205n add person varchar(3);
alter table device4206n add person varchar(3);
alter table device4207n add person varchar(3);
alter table device4208n add person varchar(3);
alter table device4209n add person varchar(3);
alter table device4210n add person varchar(3);
-------------------------------------------------

alter table device4601y add person varchar(3);
alter table device4602y add person varchar(3);
alter table device4603y add person varchar(3);
alter table device4604y add person varchar(3);
alter table device4605y add person varchar(3);
alter table device4606y add person varchar(3);
alter table device4607y add person varchar(3);
alter table device4608y add person varchar(3);
alter table device4609y add person varchar(3);
alter table device4610y  add person varchar(3);

alter table device4601n add person varchar(3);
alter table device4602n add person varchar(3);
alter table device4603n add person varchar(3);
alter table device4604n add person varchar(3);
alter table device4605n add person varchar(3);
alter table device4606n add person varchar(3);
alter table device4607n add person varchar(3);
alter table device4608n add person varchar(3);
alter table device4609n add person varchar(3);
alter table device4610n add person varchar(3);

----------------------------

alter table device6601y add person varchar(3);
alter table device6602y add person varchar(3);
alter table device6603y add person varchar(3);
alter table device6604y add person varchar(3);
alter table device6605y add person varchar(3);
alter table device6606y add person varchar(3);
alter table device6607y add person varchar(3);
alter table device6608y add person varchar(3);
alter table device6609y add person varchar(3);
alter table device6610y  add person varchar(3);

alter table device6601n add person varchar(3);
alter table device6602n add person varchar(3);
alter table device6603n add person varchar(3);
alter table device6604n add person varchar(3);
alter table device6605n add person varchar(3);
alter table device6606n add person varchar(3);
alter table device6607n add person varchar(3);
alter table device6608n add person varchar(3);
alter table device6609n add person varchar(3);
alter table device6610n add person varchar(3);
---------------------------------------------

alter table device7101y add person varchar(3);
alter table device7102y add person varchar(3);
alter table device7103y add person varchar(3);
alter table device7104y add person varchar(3);
alter table device7105y add person varchar(3);
alter table device7106y add person varchar(3);
alter table device7107y add person varchar(3);
alter table device7108y add person varchar(3);
alter table device7109y add person varchar(3);
alter table device7110y  add person varchar(3);

alter table device7101n add person varchar(3);
alter table device7102n add person varchar(3);
alter table device7103n add person varchar(3);
alter table device7104n add person varchar(3);
alter table device7105n add person varchar(3);
alter table device7106n add person varchar(3);
alter table device7107n add person varchar(3);
alter table device7108n add person varchar(3);
alter table device7109n add person varchar(3);
alter table device7110n add person varchar(3);

------------------------------------------------

alter table device7401y add person varchar(3);
alter table device7402y add person varchar(3);
alter table device7403y add person varchar(3);
alter table device7404y add person varchar(3);
alter table device7405y add person varchar(3);
alter table device7406y add person varchar(3);
alter table device7407y add person varchar(3);
alter table device7408y add person varchar(3);
alter table device7409y add person varchar(3);
alter table device7410y  add person varchar(3);

alter table device7401n add person varchar(3);
alter table device7402n add person varchar(3);
alter table device7403n add person varchar(3);
alter table device7404n add person varchar(3);
alter table device7405n add person varchar(3);
alter table device7406n add person varchar(3);
alter table device7407n add person varchar(3);
alter table device7408n add person varchar(3);
alter table device7409n add person varchar(3);
alter table device7410n add person varchar(3);

-----------------------------------------------

alter table device8301y add person varchar(3);
alter table device8302y add person varchar(3);
alter table device8303y add person varchar(3);
alter table device8304y add person varchar(3);
alter table device8305y add person varchar(3);
alter table device8306y add person varchar(3);
alter table device8307y add person varchar(3);
alter table device8308y add person varchar(3);
alter table device8309y add person varchar(3);
alter table device8310y  add person varchar(3);

alter table device8301n add person varchar(3);
alter table device8302n add person varchar(3);
alter table device8303n add person varchar(3);
alter table device8304n add person varchar(3);
alter table device8305n add person varchar(3);
alter table device8306n add person varchar(3);
alter table device8307n add person varchar(3);
alter table device8308n add person varchar(3);
alter table device8309n add person varchar(3);
alter table device8310n add person varchar(3);

-------------------------------------------
alter table device9101y add person varchar(3);
alter table device9102y add person varchar(3);
alter table device9103y add person varchar(3);
alter table device9104y add person varchar(3);
alter table device9105y add person varchar(3);
alter table device9106y add person varchar(3);
alter table device9107y add person varchar(3);
alter table device9108y add person varchar(3);
alter table device9109y add person varchar(3);
alter table device9110y  add person varchar(3);

alter table device9101n add person varchar(3);
alter table device9102n add person varchar(3);
alter table device9103n add person varchar(3);
alter table device9104n add person varchar(3);
alter table device9105n add person varchar(3);
alter table device9106n add person varchar(3);
alter table device9107n add person varchar(3);
alter table device9108n add person varchar(3);
alter table device9109n add person varchar(3);
alter table device9110n add person varchar(3);
--------------------------------------------

alter table device9401y add person varchar(3);
alter table device9402y add person varchar(3);
alter table device9403y add person varchar(3);
alter table device9404y add person varchar(3);
alter table device9405y add person varchar(3);
alter table device9406y add person varchar(3);
alter table device9407y add person varchar(3);
alter table device9408y add person varchar(3);
alter table device9409y add person varchar(3);
alter table device9410y  add person varchar(3);

alter table device9401n add person varchar(3);
alter table device9402n add person varchar(3);
alter table device9403n add person varchar(3);
alter table device9404n add person varchar(3);
alter table device9405n add person varchar(3);
alter table device9406n add person varchar(3);
alter table device9407n add person varchar(3);
alter table device9408n add person varchar(3);
alter table device9409n add person varchar(3);
alter table device9410n add person varchar(3);
---------------------------------------------

alter table device9501y add person varchar(3);
alter table device9502y add person varchar(3);
alter table device9503y add person varchar(3);
alter table device9504y add person varchar(3);
alter table device9505y add person varchar(3);
alter table device9506y add person varchar(3);
alter table device9507y add person varchar(3);
alter table device9508y add person varchar(3);
alter table device9509y add person varchar(3);
alter table device9510y  add person varchar(3);

alter table device9501n add person varchar(3);
alter table device9502n add person varchar(3);
alter table device9503n add person varchar(3);
alter table device9504n add person varchar(3);
alter table device9505n add person varchar(3);
alter table device9506n add person varchar(3);
alter table device9507n add person varchar(3);
alter table device9508n add person varchar(3);
alter table device9509n add person varchar(3);
alter table device9510n add person varchar(3);