SELECT * FROM mitclean.dspan1;



ALTER TABLE cspan1
DROP COLUMN oid,
DROP COLUMN endtime,
DROP COLUMN callid,
DROP COLUMN contact,
DROP COLUMN description,
DROP COLUMN direction,
DROP COLUMN ctid;


ALTER TABLE cespan1
DROP COLUMN oid,
DROP COLUMN endtime;



ALTER TABLE aspan1
DROP COLUMN oid,
DROP COLUMN endtime;


ALTER TABLE dspan1
DROP COLUMN oid,
DROP COLUMN endtime;



SELECT starttime,wd,dayname(starttime) FROM aspan1 order by starttime;
create table cspan2 as select * from cspan1 order by starttime;
create table aspan2 as select * from aspan1 order by starttime;
create table cespan2 as select * from cespan1 order by starttime;
create table dspan2 as select * from dspan1 order by starttime;

SELECT * FROM cspan2;
SELECT * FROM dspan2;
SELECT * FROM aspan2;
SELECT * FROM cespan2;

