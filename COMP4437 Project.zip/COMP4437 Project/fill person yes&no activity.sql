UPDATE activity1301y SET person = 'YES';
UPDATE activity1302y SET person = 'YES';
UPDATE activity1303y SET person = 'YES';
UPDATE activity1304y SET person = 'YES';
UPDATE activity1305y SET person = 'YES';
UPDATE activity1306y SET person = 'YES';
UPDATE activity1307y SET person = 'YES';
UPDATE activity1308y SET person = 'YES';
UPDATE activity1309y SET person = 'YES';
UPDATE activity1310y SET person = 'YES';


UPDATE activity1301n SET person = 'NO';
UPDATE activity1302n SET person = 'NO';
UPDATE activity1303n SET person = 'NO';
UPDATE activity1304n SET person = 'NO';
UPDATE activity1305n SET person = 'NO';
UPDATE activity1306n SET person = 'NO';
UPDATE activity1307n SET person = 'NO';
UPDATE activity1308n SET person = 'NO';
UPDATE activity1309n SET person = 'NO';
UPDATE activity1310n SET person = 'NO';


UPDATE activity1701y SET person = 'YES';
UPDATE activity1702y SET person = 'YES';
UPDATE activity1703y SET person = 'YES';
UPDATE activity1704y SET person = 'YES';
UPDATE activity1705y SET person = 'YES';
UPDATE activity1706y SET person = 'YES';
UPDATE activity1707y SET person = 'YES';
UPDATE activity1708y SET person = 'YES';
UPDATE activity1709y SET person = 'YES';
UPDATE activity1710y SET person = 'YES';


UPDATE activity1701n SET person = 'NO';
UPDATE activity1702n SET person = 'NO';
UPDATE activity1703n SET person = 'NO';
UPDATE activity1704n SET person = 'NO';
UPDATE activity1705n SET person = 'NO';
UPDATE activity1706n SET person = 'NO';
UPDATE activity1707n SET person = 'NO';
UPDATE activity1708n SET person = 'NO';
UPDATE activity1709n SET person = 'NO';
UPDATE activity1710n SET person = 'NO';


UPDATE activity2201y SET person = 'YES';
UPDATE activity2202y SET person = 'YES';
UPDATE activity2203y SET person = 'YES';
UPDATE activity2204y SET person = 'YES';
UPDATE activity2205y SET person = 'YES';
UPDATE activity2206y SET person = 'YES';
UPDATE activity2207y SET person = 'YES';
UPDATE activity2208y SET person = 'YES';
UPDATE activity2209y SET person = 'YES';
UPDATE activity2210y SET person = 'YES';


UPDATE activity2201n SET person = 'NO';
UPDATE activity2202n SET person = 'NO';
UPDATE activity2203n SET person = 'NO';
UPDATE activity2204n SET person = 'NO';
UPDATE activity2205n SET person = 'NO';
UPDATE activity2206n SET person = 'NO';
UPDATE activity2207n SET person = 'NO';
UPDATE activity2208n SET person = 'NO';
UPDATE activity2209n SET person = 'NO';
UPDATE activity2210n SET person = 'NO';


UPDATE activity2301y SET person = 'YES';
UPDATE activity2302y SET person = 'YES';
UPDATE activity2303y SET person = 'YES';
UPDATE activity2304y SET person = 'YES';
UPDATE activity2305y SET person = 'YES';
UPDATE activity2306y SET person = 'YES';
UPDATE activity2307y SET person = 'YES';
UPDATE activity2308y SET person = 'YES';
UPDATE activity2309y SET person = 'YES';
UPDATE activity2310y SET person = 'YES';


UPDATE activity2301n SET person = 'NO';
UPDATE activity2302n SET person = 'NO';
UPDATE activity2303n SET person = 'NO';
UPDATE activity2304n SET person = 'NO';
UPDATE activity2305n SET person = 'NO';
UPDATE activity2306n SET person = 'NO';
UPDATE activity2307n SET person = 'NO';
UPDATE activity2308n SET person = 'NO';
UPDATE activity2309n SET person = 'NO';
UPDATE activity2310n SET person = 'NO';



UPDATE activity3401y SET person = 'YES';
UPDATE activity3402y SET person = 'YES';
UPDATE activity3403y SET person = 'YES';
UPDATE activity3404y SET person = 'YES';
UPDATE activity3405y SET person = 'YES';
UPDATE activity3406y SET person = 'YES';
UPDATE activity3407y SET person = 'YES';
UPDATE activity3408y SET person = 'YES';
UPDATE activity3409y SET person = 'YES';
UPDATE activity3410y SET person = 'YES';


UPDATE activity3401n SET person = 'NO';
UPDATE activity3402n SET person = 'NO';
UPDATE activity3403n SET person = 'NO';
UPDATE activity3404n SET person = 'NO';
UPDATE activity3405n SET person = 'NO';
UPDATE activity3406n SET person = 'NO';
UPDATE activity3407n SET person = 'NO';
UPDATE activity3408n SET person = 'NO';
UPDATE activity3409n SET person = 'NO';
UPDATE activity3410n SET person = 'NO';

UPDATE activity3901y SET person = 'YES';
UPDATE activity3902y SET person = 'YES';
UPDATE activity3903y SET person = 'YES';
UPDATE activity3904y SET person = 'YES';
UPDATE activity3905y SET person = 'YES';
UPDATE activity3906y SET person = 'YES';
UPDATE activity3907y SET person = 'YES';
UPDATE activity3908y SET person = 'YES';
UPDATE activity3909y SET person = 'YES';
UPDATE activity3910y SET person = 'YES';


UPDATE activity3901n SET person = 'NO';
UPDATE activity3902n SET person = 'NO';
UPDATE activity3903n SET person = 'NO';
UPDATE activity3904n SET person = 'NO';
UPDATE activity3905n SET person = 'NO';
UPDATE activity3906n SET person = 'NO';
UPDATE activity3907n SET person = 'NO';
UPDATE activity3908n SET person = 'NO';
UPDATE activity3909n SET person = 'NO';
UPDATE activity3910n SET person = 'NO';


UPDATE activity4201y SET person = 'YES';
UPDATE activity4202y SET person = 'YES';
UPDATE activity4203y SET person = 'YES';
UPDATE activity4204y SET person = 'YES';
UPDATE activity4205y SET person = 'YES';
UPDATE activity4206y SET person = 'YES';
UPDATE activity4207y SET person = 'YES';
UPDATE activity4208y SET person = 'YES';
UPDATE activity4209y SET person = 'YES';
UPDATE activity4210y SET person = 'YES';


UPDATE activity4201n SET person = 'NO';
UPDATE activity4202n SET person = 'NO';
UPDATE activity4203n SET person = 'NO';
UPDATE activity4204n SET person = 'NO';
UPDATE activity4205n SET person = 'NO';
UPDATE activity4206n SET person = 'NO';
UPDATE activity4207n SET person = 'NO';
UPDATE activity4208n SET person = 'NO';
UPDATE activity4209n SET person = 'NO';
UPDATE activity4210n SET person = 'NO';


UPDATE activity4601y SET person = 'YES';
UPDATE activity4602y SET person = 'YES';
UPDATE activity4603y SET person = 'YES';
UPDATE activity4604y SET person = 'YES';
UPDATE activity4605y SET person = 'YES';
UPDATE activity4606y SET person = 'YES';
UPDATE activity4607y SET person = 'YES';
UPDATE activity4608y SET person = 'YES';
UPDATE activity4609y SET person = 'YES';
UPDATE activity4610y SET person = 'YES';


UPDATE activity4601n SET person = 'NO';
UPDATE activity4602n SET person = 'NO';
UPDATE activity4603n SET person = 'NO';
UPDATE activity4604n SET person = 'NO';
UPDATE activity4605n SET person = 'NO';
UPDATE activity4606n SET person = 'NO';
UPDATE activity4607n SET person = 'NO';
UPDATE activity4608n SET person = 'NO';
UPDATE activity4609n SET person = 'NO';
UPDATE activity4610n SET person = 'NO';


UPDATE activity6601y SET person = 'YES';
UPDATE activity6602y SET person = 'YES';
UPDATE activity6603y SET person = 'YES';
UPDATE activity6604y SET person = 'YES';
UPDATE activity6605y SET person = 'YES';
UPDATE activity6606y SET person = 'YES';
UPDATE activity6607y SET person = 'YES';
UPDATE activity6608y SET person = 'YES';
UPDATE activity6609y SET person = 'YES';
UPDATE activity6610y SET person = 'YES';


UPDATE activity6601n SET person = 'NO';
UPDATE activity6602n SET person = 'NO';
UPDATE activity6603n SET person = 'NO';
UPDATE activity6604n SET person = 'NO';
UPDATE activity6605n SET person = 'NO';
UPDATE activity6606n SET person = 'NO';
UPDATE activity6607n SET person = 'NO';
UPDATE activity6608n SET person = 'NO';
UPDATE activity6609n SET person = 'NO';
UPDATE activity6610n SET person = 'NO';


UPDATE activity7101y SET person = 'YES';
UPDATE activity7102y SET person = 'YES';
UPDATE activity7103y SET person = 'YES';
UPDATE activity7104y SET person = 'YES';
UPDATE activity7105y SET person = 'YES';
UPDATE activity7106y SET person = 'YES';
UPDATE activity7107y SET person = 'YES';
UPDATE activity7108y SET person = 'YES';
UPDATE activity7109y SET person = 'YES';
UPDATE activity7110y SET person = 'YES';


UPDATE activity7101n SET person = 'NO';
UPDATE activity7102n SET person = 'NO';
UPDATE activity7103n SET person = 'NO';
UPDATE activity7104n SET person = 'NO';
UPDATE activity7105n SET person = 'NO';
UPDATE activity7106n SET person = 'NO';
UPDATE activity7107n SET person = 'NO';
UPDATE activity7108n SET person = 'NO';
UPDATE activity7109n SET person = 'NO';
UPDATE activity7110n SET person = 'NO';


UPDATE activity7401y SET person = 'YES';
UPDATE activity7402y SET person = 'YES';
UPDATE activity7403y SET person = 'YES';
UPDATE activity7404y SET person = 'YES';
UPDATE activity7405y SET person = 'YES';
UPDATE activity7406y SET person = 'YES';
UPDATE activity7407y SET person = 'YES';
UPDATE activity7408y SET person = 'YES';
UPDATE activity7409y SET person = 'YES';
UPDATE activity7410y SET person = 'YES';


UPDATE activity7401n SET person = 'NO';
UPDATE activity7402n SET person = 'NO';
UPDATE activity7403n SET person = 'NO';
UPDATE activity7404n SET person = 'NO';
UPDATE activity7405n SET person = 'NO';
UPDATE activity7406n SET person = 'NO';
UPDATE activity7407n SET person = 'NO';
UPDATE activity7408n SET person = 'NO';
UPDATE activity7409n SET person = 'NO';
UPDATE activity7410n SET person = 'NO';


UPDATE activity8301y SET person = 'YES';
UPDATE activity8302y SET person = 'YES';
UPDATE activity8303y SET person = 'YES';
UPDATE activity8304y SET person = 'YES';
UPDATE activity8305y SET person = 'YES';
UPDATE activity8306y SET person = 'YES';
UPDATE activity8307y SET person = 'YES';
UPDATE activity8308y SET person = 'YES';
UPDATE activity8309y SET person = 'YES';
UPDATE activity8310y SET person = 'YES';


UPDATE activity8301n SET person = 'NO';
UPDATE activity8302n SET person = 'NO';
UPDATE activity8303n SET person = 'NO';
UPDATE activity8304n SET person = 'NO';
UPDATE activity8305n SET person = 'NO';
UPDATE activity8306n SET person = 'NO';
UPDATE activity8307n SET person = 'NO';
UPDATE activity8308n SET person = 'NO';
UPDATE activity8309n SET person = 'NO';
UPDATE activity8310n SET person = 'NO';


UPDATE activity9101y SET person = 'YES';
UPDATE activity9102y SET person = 'YES';
UPDATE activity9103y SET person = 'YES';
UPDATE activity9104y SET person = 'YES';
UPDATE activity9105y SET person = 'YES';
UPDATE activity9106y SET person = 'YES';
UPDATE activity9107y SET person = 'YES';
UPDATE activity9108y SET person = 'YES';
UPDATE activity9109y SET person = 'YES';
UPDATE activity9110y SET person = 'YES';


UPDATE activity9101n SET person = 'NO';
UPDATE activity9102n SET person = 'NO';
UPDATE activity9103n SET person = 'NO';
UPDATE activity9104n SET person = 'NO';
UPDATE activity9105n SET person = 'NO';
UPDATE activity9106n SET person = 'NO';
UPDATE activity9107n SET person = 'NO';
UPDATE activity9108n SET person = 'NO';
UPDATE activity9109n SET person = 'NO';
UPDATE activity9110n SET person = 'NO';


UPDATE activity9401y SET person = 'YES';
UPDATE activity9402y SET person = 'YES';
UPDATE activity9403y SET person = 'YES';
UPDATE activity9404y SET person = 'YES';
UPDATE activity9405y SET person = 'YES';
UPDATE activity9406y SET person = 'YES';
UPDATE activity9407y SET person = 'YES';
UPDATE activity9408y SET person = 'YES';
UPDATE activity9409y SET person = 'YES';
UPDATE activity9410y SET person = 'YES';


UPDATE activity9401n SET person = 'NO';
UPDATE activity9402n SET person = 'NO';
UPDATE activity9403n SET person = 'NO';
SET SQL_SAFE_UPDATES=0;


UPDATE activity9404n SET person = 'NO';
UPDATE activity9405n SET person = 'NO';
UPDATE activity9406n SET person = 'NO';
UPDATE activity9407n SET person = 'NO';
UPDATE activity9408n SET person = 'NO';
UPDATE activity9409n SET person = 'NO';
UPDATE activity9410n SET person = 'NO';


UPDATE activity9501y SET person = 'YES';
UPDATE activity9502y SET person = 'YES';
UPDATE activity9503y SET person = 'YES';
UPDATE activity9504y SET person = 'YES';
UPDATE activity9505y SET person = 'YES';
UPDATE activity9506y SET person = 'YES';
UPDATE activity9507y SET person = 'YES';
UPDATE activity9508y SET person = 'YES';
UPDATE activity9509y SET person = 'YES';
UPDATE activity9510y SET person = 'YES';


UPDATE activity9501n SET person = 'NO';
UPDATE activity9502n SET person = 'NO';
UPDATE activity9503n SET person = 'NO';
UPDATE activity9504n SET person = 'NO';
UPDATE activity9505n SET person = 'NO';
UPDATE activity9506n SET person = 'NO';
UPDATE activity9507n SET person = 'NO';
UPDATE activity9508n SET person = 'NO';
UPDATE activity9509n SET person = 'NO';
UPDATE activity9510n SET person = 'NO';

