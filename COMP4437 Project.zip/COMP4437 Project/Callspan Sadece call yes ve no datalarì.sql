SELECT * FROM cspan13a;

--İçinden 140 kayıt rastgele seçilcek --->Bunu 10 kere tekrarla--Herbiri için ayrı tablolar aç call 1501y 1502 y diye açıcaz.
--Bu rastgele alınan 10 kayıt 10 kere gelecek.--->bunlarda 1501n olacak.Kayıtı az olan no,yüksek olan yes.

---B tablolarından 50 kayıt aldım.Tek seferlik callt15 olacak bunun adın.

**************************************************************
----CALLSPAN13----
create table call1301y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1302y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1303y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1304y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1305y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1306y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1307y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1308y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1309y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 
create table call1310y as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 140; 

create table call1301n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1302n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1303n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1304n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1305n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1306n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1307n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1308n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1309n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 
create table call1310n as SELECT * FROM cspan13a ORDER BY RAND() LIMIT 10; 

create table callt1301 as select * from cspan13b ORDER BY RAND() LIMIT 50;

*******************************************
---CALLSPAN17---
create table call1701y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1702y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1703y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1704y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1705y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1706y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1707y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1708y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1709y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 
create table call1710y as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 140; 

create table call1701n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1702n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1703n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1704n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1705n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1706n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1707n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1708n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1709n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 
create table call1710n as SELECT * FROM cspan17a ORDER BY RAND() LIMIT 10; 

create table callt1701 as select * from cspan17b ORDER BY RAND() LIMIT 50;
**************************************************
-----CALLSPAN22-----
create table call2201y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2202y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2203y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2204y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2205y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2206y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2207y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2208y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2209y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 
create table call2210y as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 140; 

create table call2201n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2202n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2203n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2204n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2205n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2206n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2207n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2208n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2209n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 
create table call2210n as SELECT * FROM cspan22a ORDER BY RAND() LIMIT 10; 

create table callt2201 as select * from cspan22b ORDER BY RAND() LIMIT 50;
**************************
-----CALLSPAN23----
create table call2301y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2302y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2303y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2304y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2305y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2306y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2307y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2308y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2309y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call2310y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 

create table call2301n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2302n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2303n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2304n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2305n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2306n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2307n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2308n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2309n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 
create table call2310n as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 10; 

create table callt2301 as select * from cspan23b ORDER BY RAND() LIMIT 50;
*****************************************************************************
-------------------CALLSPAN34------
create table call3401y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3402y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3403y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3404y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3405y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3406y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3407y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3408y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3409y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 
create table call3410y as SELECT * FROM cspan23a ORDER BY RAND() LIMIT 140; 

create table call3401n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3402n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3403n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3404n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3405n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3406n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3407n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3408n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3409n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 
create table call3410n as SELECT * FROM cspan34a ORDER BY RAND() LIMIT 10; 

create table callt3401 as select * from cspan34b ORDER BY RAND() LIMIT 50;
***************************************************************************
---------------CALSPAN39-----------------------
create table call3901y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3902y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3903y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3904y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3905y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3906y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3907y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3908y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3909y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 
create table call3910y as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 140; 

create table call3901n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3902n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3903n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3904n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3905n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3906n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3907n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3908n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3909n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 
create table call3910n as SELECT * FROM cspan39a ORDER BY RAND() LIMIT 10; 

create table callt3901 as select * from cspan39b ORDER BY RAND() LIMIT 50;
***************************************************************************
-------------------CALLSPAN42-----------------
create table call4201y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4202y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4203y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4204y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4205y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4206y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4207y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4208y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4209y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 
create table call4210y as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 140; 

create table call4201n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4202n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4203n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4204n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4205n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4206n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4207n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4208n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4209n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 
create table call4210n as SELECT * FROM cspan42a ORDER BY RAND() LIMIT 10; 

create table callt4201 as select * from cspan42b ORDER BY RAND() LIMIT 50;
*******************************************************************************
--------------CALLSPAN46-------
create table call4601y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4602y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4603y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4604y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4605y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4606y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4607y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4608y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4609y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 
create table call4610y as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 140; 

create table call4601n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4602n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4603n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4604n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4605n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4606n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4607n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4608n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4609n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 
create table call4610n as SELECT * FROM cspan46a ORDER BY RAND() LIMIT 10; 

create table callt4601 as select * from cspan46b ORDER BY RAND() LIMIT 50;
****************************************************************************
-------------CALLSPAN66--------------
create table call6601y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6602y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6603y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6604y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6605y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6606y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6607y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6608y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6609y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 
create table call6610y as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 140; 

create table call6601n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6602n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6603n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6604n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6605n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6606n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6607n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6608n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6609n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 
create table call6610n as SELECT * FROM cspan66a ORDER BY RAND() LIMIT 10; 

create table callt6601 as select * from cspan66b ORDER BY RAND() LIMIT 50;
***************************************************************************
-------------CALLSPAN71------------------
create table call7101y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7102y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7103y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7104y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7105y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7106y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7107y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7108y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7109y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 
create table call7110y as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 140; 

create table call7101n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7102n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7103n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7104n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7105n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7106n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7107n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7108n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7109n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 
create table call7110n as SELECT * FROM cspan71a ORDER BY RAND() LIMIT 10; 

create table callt7101 as select * from cspan71b ORDER BY RAND() LIMIT 50;
********************************************************************
---------------------CALLSPAN74---------------
create table call7401y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7402y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7403y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7404y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7405y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7406y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7407y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7408y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7409y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 
create table call7410y as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 140; 

create table call7401n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7402n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7403n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7404n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7405n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7406n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7407n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7408n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7409n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 
create table call7410n as SELECT * FROM cspan74a ORDER BY RAND() LIMIT 10; 

create table callt7401 as select * from cspan74b ORDER BY RAND() LIMIT 50;
****************************************************************************
-----------------------CALLSPAN83------------------
create table call8301y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8302y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8303y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8304y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8305y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8306y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8307y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8308y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8309y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 
create table call8310y as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 140; 

create table call8301n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8302n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8303n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8304n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8305n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8306n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8307n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8308n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8309n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 
create table call8310n as SELECT * FROM cspan83a ORDER BY RAND() LIMIT 10; 

create table callt8301 as select * from cspan83b ORDER BY RAND() LIMIT 50;
****************************************************************************
-------------------------CALLSPAN91--------------------------------------------
create table call9101y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9102y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9103y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9104y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9105y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9106y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9107y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9108y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9109y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 
create table call9110y as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 140; 

create table call9101n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9102n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9103n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9104n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9105n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9106n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9107n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9108n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9109n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 
create table call9110n as SELECT * FROM cspan91a ORDER BY RAND() LIMIT 10; 

create table callt9101 as select * from cspan91b ORDER BY RAND() LIMIT 50;
*****************************************************************************
----------------CALLSPAN94----------
create table call9401y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9402y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9403y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9404y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9405y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9406y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9407y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9408y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9409y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 
create table call9410y as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 140; 

create table call9401n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9402n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9403n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9404n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9405n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9406n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9407n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9408n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9409n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 
create table call9410n as SELECT * FROM cspan94a ORDER BY RAND() LIMIT 10; 

create table callt9401 as select * from cspan94b ORDER BY RAND() LIMIT 50;
********************************************************************************
------------------CALLSPAN95--------------
create table call9501y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9502y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9503y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9504y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9505y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9506y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9507y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9508y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9509y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 
create table call9510y as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 140; 

create table call9501n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9502n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9503n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9504n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9505n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9506n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9507n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9508n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9509n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 
create table call9510n as SELECT * FROM cspan95a ORDER BY RAND() LIMIT 10; 

create table callt9501 as select * from cspan95b ORDER BY RAND() LIMIT 50;