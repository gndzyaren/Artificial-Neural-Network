
-----------csSPAN-------------
alter table cs1301y add person varchar(3);
alter table cs1302y add person varchar(3);
alter table cs1303y add person varchar(3);
alter table cs1304y add person varchar(3);
alter table cs1305y add person varchar(3);
alter table cs1306y add person varchar(3);
alter table cs1307y add person varchar(3);
alter table cs1308y add person varchar(3);
alter table cs1309y add person varchar(3);
alter table cs1310y  add person varchar(3);

alter table cs1301n add person varchar(3);
alter table cs1302n add person varchar(3);
alter table cs1303n add person varchar(3);
alter table cs1304n add person varchar(3);
alter table cs1305n add person varchar(3);
alter table cs1306n add person varchar(3);
alter table cs1307n add person varchar(3);
alter table cs1308n add person varchar(3);
alter table cs1309n add person varchar(3);
alter table cs1310n add person varchar(3);

--------------------------------------------------------
alter table cs1701y add person varchar(3);
alter table cs1702y add person varchar(3);
alter table cs1703y add person varchar(3);
alter table cs1704y add person varchar(3);
alter table cs1705y add person varchar(3);
alter table cs1706y add person varchar(3);
alter table cs1707y add person varchar(3);
alter table cs1708y add person varchar(3);
alter table cs1709y add person varchar(3);
alter table cs1710y  add person varchar(3);

alter table cs1701n add person varchar(3);
alter table cs1702n add person varchar(3);
alter table cs1703n add person varchar(3);
alter table cs1704n add person varchar(3);
alter table cs1705n add person varchar(3);
alter table cs1706n add person varchar(3);
alter table cs1707n add person varchar(3);
alter table cs1708n add person varchar(3);
alter table cs1709n add person varchar(3);
alter table cs1710n add person varchar(3);

------------------------------------------------------
alter table cs2201y add person varchar(3);
alter table cs2202y add person varchar(3);
alter table cs2203y add person varchar(3);
alter table cs2204y add person varchar(3);
alter table cs2205y add person varchar(3);
alter table cs2206y add person varchar(3);
alter table cs2207y add person varchar(3);
alter table cs2208y add person varchar(3);
alter table cs2209y add person varchar(3);
alter table cs2210y  add person varchar(3);

alter table cs2201n add person varchar(3);
alter table cs2202n add person varchar(3);
alter table cs2203n add person varchar(3);
alter table cs2204n add person varchar(3);
alter table cs2205n add person varchar(3);
alter table cs2206n add person varchar(3);
alter table cs2207n add person varchar(3);
alter table cs2208n add person varchar(3);
alter table cs2209n add person varchar(3);
alter table cs2210n add person varchar(3);
------------------------------------------------------

alter table cs2301y add person varchar(3);
alter table cs2302y add person varchar(3);
alter table cs2303y add person varchar(3);
alter table cs2304y add person varchar(3);
alter table cs2305y add person varchar(3);
alter table cs2306y add person varchar(3);
alter table cs2307y add person varchar(3);
alter table cs2308y add person varchar(3);
alter table cs2309y add person varchar(3);
alter table cs2310y  add person varchar(3);

alter table cs2301n add person varchar(3);
alter table cs2302n add person varchar(3);
alter table cs2303n add person varchar(3);
alter table cs2304n add person varchar(3);
alter table cs2305n add person varchar(3);
alter table cs2306n add person varchar(3);
alter table cs2307n add person varchar(3);
alter table cs2308n add person varchar(3);
alter table cs2309n add person varchar(3);
alter table cs2310n add person varchar(3);

------------------------------------------------------
alter table cs3401y add person varchar(3);
alter table cs3402y add person varchar(3);
alter table cs3403y add person varchar(3);
alter table cs3404y add person varchar(3);
alter table cs3405y add person varchar(3);
alter table cs3406y add person varchar(3);
alter table cs3407y add person varchar(3);
alter table cs3408y add person varchar(3);
alter table cs3409y add person varchar(3);
alter table cs3410y  add person varchar(3);

alter table cs3401n add person varchar(3);
alter table cs3402n add person varchar(3);
alter table cs3403n add person varchar(3);
alter table cs3404n add person varchar(3);
alter table cs3405n add person varchar(3);
alter table cs3406n add person varchar(3);
alter table cs3407n add person varchar(3);
alter table cs3408n add person varchar(3);
alter table cs3409n add person varchar(3);
alter table cs3410n add person varchar(3);
---------------------------------------------

alter table cs3901y add person varchar(3);
alter table cs3902y add person varchar(3);
alter table cs3903y add person varchar(3);
alter table cs3904y add person varchar(3);
alter table cs3905y add person varchar(3);
alter table cs3906y add person varchar(3);
alter table cs3907y add person varchar(3);
alter table cs3908y add person varchar(3);
alter table cs3909y add person varchar(3);
alter table cs3910y  add person varchar(3);

alter table cs3901n add person varchar(3);
alter table cs3902n add person varchar(3);
alter table cs3903n add person varchar(3);
alter table cs3904n add person varchar(3);
alter table cs3905n add person varchar(3);
alter table cs3906n add person varchar(3);
alter table cs3907n add person varchar(3);
alter table cs3908n add person varchar(3);
alter table cs3909n add person varchar(3);
alter table cs3910n add person varchar(3);
-----------------------------------------------

alter table cs4201y add person varchar(3);
alter table cs4202y add person varchar(3);
alter table cs4203y add person varchar(3);
alter table cs4204y add person varchar(3);
alter table cs4205y add person varchar(3);
alter table cs4206y add person varchar(3);
alter table cs4207y add person varchar(3);
alter table cs4208y add person varchar(3);
alter table cs4209y add person varchar(3);
alter table cs4210y  add person varchar(3);

alter table cs4201n add person varchar(3);
alter table cs4202n add person varchar(3);
alter table cs4203n add person varchar(3);
alter table cs4204n add person varchar(3);
alter table cs4205n add person varchar(3);
alter table cs4206n add person varchar(3);
alter table cs4207n add person varchar(3);
alter table cs4208n add person varchar(3);
alter table cs4209n add person varchar(3);
alter table cs4210n add person varchar(3);
-------------------------------------------------

alter table cs4601y add person varchar(3);
alter table cs4602y add person varchar(3);
alter table cs4603y add person varchar(3);
alter table cs4604y add person varchar(3);
alter table cs4605y add person varchar(3);
alter table cs4606y add person varchar(3);
alter table cs4607y add person varchar(3);
alter table cs4608y add person varchar(3);
alter table cs4609y add person varchar(3);
alter table cs4610y  add person varchar(3);

alter table cs4601n add person varchar(3);
alter table cs4602n add person varchar(3);
alter table cs4603n add person varchar(3);
alter table cs4604n add person varchar(3);
alter table cs4605n add person varchar(3);
alter table cs4606n add person varchar(3);
alter table cs4607n add person varchar(3);
alter table cs4608n add person varchar(3);
alter table cs4609n add person varchar(3);
alter table cs4610n add person varchar(3);

----------------------------

alter table cs6601y add person varchar(3);
alter table cs6602y add person varchar(3);
alter table cs6603y add person varchar(3);
alter table cs6604y add person varchar(3);
alter table cs6605y add person varchar(3);
alter table cs6606y add person varchar(3);
alter table cs6607y add person varchar(3);
alter table cs6608y add person varchar(3);
alter table cs6609y add person varchar(3);
alter table cs6610y  add person varchar(3);

alter table cs6601n add person varchar(3);
alter table cs6602n add person varchar(3);
alter table cs6603n add person varchar(3);
alter table cs6604n add person varchar(3);
alter table cs6605n add person varchar(3);
alter table cs6606n add person varchar(3);
alter table cs6607n add person varchar(3);
alter table cs6608n add person varchar(3);
alter table cs6609n add person varchar(3);
alter table cs6610n add person varchar(3);
---------------------------------------------

alter table cs7101y add person varchar(3);
alter table cs7102y add person varchar(3);
alter table cs7103y add person varchar(3);
alter table cs7104y add person varchar(3);
alter table cs7105y add person varchar(3);
alter table cs7106y add person varchar(3);
alter table cs7107y add person varchar(3);
alter table cs7108y add person varchar(3);
alter table cs7109y add person varchar(3);
alter table cs7110y  add person varchar(3);

alter table cs7101n add person varchar(3);
alter table cs7102n add person varchar(3);
alter table cs7103n add person varchar(3);
alter table cs7104n add person varchar(3);
alter table cs7105n add person varchar(3);
alter table cs7106n add person varchar(3);
alter table cs7107n add person varchar(3);
alter table cs7108n add person varchar(3);
alter table cs7109n add person varchar(3);
alter table cs7110n add person varchar(3);

------------------------------------------------

alter table cs7401y add person varchar(3);
alter table cs7402y add person varchar(3);
alter table cs7403y add person varchar(3);
alter table cs7404y add person varchar(3);
alter table cs7405y add person varchar(3);
alter table cs7406y add person varchar(3);
alter table cs7407y add person varchar(3);
alter table cs7408y add person varchar(3);
alter table cs7409y add person varchar(3);
alter table cs7410y  add person varchar(3);

alter table cs7401n add person varchar(3);
alter table cs7402n add person varchar(3);
alter table cs7403n add person varchar(3);
alter table cs7404n add person varchar(3);
alter table cs7405n add person varchar(3);
alter table cs7406n add person varchar(3);
alter table cs7407n add person varchar(3);
alter table cs7408n add person varchar(3);
alter table cs7409n add person varchar(3);
alter table cs7410n add person varchar(3);

-----------------------------------------------

alter table cs8301y add person varchar(3);
alter table cs8302y add person varchar(3);
alter table cs8303y add person varchar(3);
alter table cs8304y add person varchar(3);
alter table cs8305y add person varchar(3);
alter table cs8306y add person varchar(3);
alter table cs8307y add person varchar(3);
alter table cs8308y add person varchar(3);
alter table cs8309y add person varchar(3);
alter table cs8310y  add person varchar(3);

alter table cs8301n add person varchar(3);
alter table cs8302n add person varchar(3);
alter table cs8303n add person varchar(3);
alter table cs8304n add person varchar(3);
alter table cs8305n add person varchar(3);
alter table cs8306n add person varchar(3);
alter table cs8307n add person varchar(3);
alter table cs8308n add person varchar(3);
alter table cs8309n add person varchar(3);
alter table cs8310n add person varchar(3);

-------------------------------------------
alter table cs9101y add person varchar(3);
alter table cs9102y add person varchar(3);
alter table cs9103y add person varchar(3);
alter table cs9104y add person varchar(3);
alter table cs9105y add person varchar(3);
alter table cs9106y add person varchar(3);
alter table cs9107y add person varchar(3);
alter table cs9108y add person varchar(3);
alter table cs9109y add person varchar(3);
alter table cs9110y  add person varchar(3);

alter table cs9101n add person varchar(3);
alter table cs9102n add person varchar(3);
alter table cs9103n add person varchar(3);
alter table cs9104n add person varchar(3);
alter table cs9105n add person varchar(3);
alter table cs9106n add person varchar(3);
alter table cs9107n add person varchar(3);
alter table cs9108n add person varchar(3);
alter table cs9109n add person varchar(3);
alter table cs9110n add person varchar(3);
--------------------------------------------

alter table cs9401y add person varchar(3);
alter table cs9402y add person varchar(3);
alter table cs9403y add person varchar(3);
alter table cs9404y add person varchar(3);
alter table cs9405y add person varchar(3);
alter table cs9406y add person varchar(3);
alter table cs9407y add person varchar(3);
alter table cs9408y add person varchar(3);
alter table cs9409y add person varchar(3);
alter table cs9410y  add person varchar(3);

alter table cs9401n add person varchar(3);
alter table cs9402n add person varchar(3);
alter table cs9403n add person varchar(3);
alter table cs9404n add person varchar(3);
alter table cs9405n add person varchar(3);
alter table cs9406n add person varchar(3);
alter table cs9407n add person varchar(3);
alter table cs9408n add person varchar(3);
alter table cs9409n add person varchar(3);
alter table cs9410n add person varchar(3);
---------------------------------------------

alter table cs9501y add person varchar(3);
alter table cs9502y add person varchar(3);
alter table cs9503y add person varchar(3);
alter table cs9504y add person varchar(3);
alter table cs9505y add person varchar(3);
alter table cs9506y add person varchar(3);
alter table cs9507y add person varchar(3);
alter table cs9508y add person varchar(3);
alter table cs9509y add person varchar(3);
alter table cs9510y  add person varchar(3);

alter table cs9501n add person varchar(3);
alter table cs9502n add person varchar(3);
alter table cs9503n add person varchar(3);
alter table cs9504n add person varchar(3);
alter table cs9505n add person varchar(3);
alter table cs9506n add person varchar(3);
alter table cs9507n add person varchar(3);
alter table cs9508n add person varchar(3);
alter table cs9509n add person varchar(3);
alter table cs9510n add person varchar(3);