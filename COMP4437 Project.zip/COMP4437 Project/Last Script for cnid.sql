SELECT * FROM mitclean.call1301y;
/*callX01--X10*/
/*cspan2,cspan1*/
/*cspanX,cspanXa,cspanXb*/  /* cid ler cnid olacak*/
SELECT * FROM cspan2;

ALTER TABLE cspan2 CHANGE `cid` `cnid` int(11);

