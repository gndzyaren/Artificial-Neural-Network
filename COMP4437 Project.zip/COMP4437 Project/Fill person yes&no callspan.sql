UPDATE call1301y SET person = 'YES';
SET SQL_SAFE_UPDATES=0;


UPDATE call1302y SET person = 'YES';
UPDATE call1303y SET person = 'YES';
UPDATE call1304y SET person = 'YES';
UPDATE call1305y SET person = 'YES';
UPDATE call1306y SET person = 'YES';
UPDATE call1307y SET person = 'YES';
UPDATE call1308y SET person = 'YES';
UPDATE call1309y SET person = 'YES';
UPDATE call1310y SET person = 'YES';


UPDATE call1301n SET person = 'NO';
UPDATE call1302n SET person = 'NO';
UPDATE call1303n SET person = 'NO';
UPDATE call1304n SET person = 'NO';
UPDATE call1305n SET person = 'NO';
UPDATE call1306n SET person = 'NO';
UPDATE call1307n SET person = 'NO';
UPDATE call1308n SET person = 'NO';
UPDATE call1309n SET person = 'NO';
UPDATE call1310n SET person = 'NO';


UPDATE call1701y SET person = 'YES';
UPDATE call1702y SET person = 'YES';
UPDATE call1703y SET person = 'YES';
UPDATE call1704y SET person = 'YES';
UPDATE call1705y SET person = 'YES';
UPDATE call1706y SET person = 'YES';
UPDATE call1707y SET person = 'YES';
UPDATE call1708y SET person = 'YES';
UPDATE call1709y SET person = 'YES';
UPDATE call1710y SET person = 'YES';


UPDATE call1701n SET person = 'NO';
UPDATE call1702n SET person = 'NO';
UPDATE call1703n SET person = 'NO';
UPDATE call1704n SET person = 'NO';
UPDATE call1705n SET person = 'NO';
UPDATE call1706n SET person = 'NO';
UPDATE call1707n SET person = 'NO';
UPDATE call1708n SET person = 'NO';
UPDATE call1709n SET person = 'NO';
UPDATE call1710n SET person = 'NO';


UPDATE call2201y SET person = 'YES';
UPDATE call2202y SET person = 'YES';
UPDATE call2203y SET person = 'YES';
UPDATE call2204y SET person = 'YES';
UPDATE call2205y SET person = 'YES';
UPDATE call2206y SET person = 'YES';
UPDATE call2207y SET person = 'YES';
UPDATE call2208y SET person = 'YES';
UPDATE call2209y SET person = 'YES';
UPDATE call2210y SET person = 'YES';


UPDATE call2201n SET person = 'NO';
UPDATE call2202n SET person = 'NO';
UPDATE call2203n SET person = 'NO';
UPDATE call2204n SET person = 'NO';
UPDATE call2205n SET person = 'NO';
UPDATE call2206n SET person = 'NO';
UPDATE call2207n SET person = 'NO';
UPDATE call2208n SET person = 'NO';
UPDATE call2209n SET person = 'NO';
UPDATE call2210n SET person = 'NO';


UPDATE call2301y SET person = 'YES';
UPDATE call2302y SET person = 'YES';
UPDATE call2303y SET person = 'YES';
UPDATE call2304y SET person = 'YES';
UPDATE call2305y SET person = 'YES';
UPDATE call2306y SET person = 'YES';
UPDATE call2307y SET person = 'YES';
UPDATE call2308y SET person = 'YES';
UPDATE call2309y SET person = 'YES';
UPDATE call2310y SET person = 'YES';


UPDATE call2301n SET person = 'NO';
UPDATE call2302n SET person = 'NO';
UPDATE call2303n SET person = 'NO';
UPDATE call2304n SET person = 'NO';
UPDATE call2305n SET person = 'NO';
UPDATE call2306n SET person = 'NO';
UPDATE call2307n SET person = 'NO';
UPDATE call2308n SET person = 'NO';
UPDATE call2309n SET person = 'NO';
UPDATE call2310n SET person = 'NO';



UPDATE call3401y SET person = 'YES';
UPDATE call3402y SET person = 'YES';
UPDATE call3403y SET person = 'YES';
UPDATE call3404y SET person = 'YES';
UPDATE call3405y SET person = 'YES';
UPDATE call3406y SET person = 'YES';
UPDATE call3407y SET person = 'YES';
UPDATE call3408y SET person = 'YES';
UPDATE call3409y SET person = 'YES';
UPDATE call3410y SET person = 'YES';


UPDATE call3401n SET person = 'NO';
UPDATE call3402n SET person = 'NO';
UPDATE call3403n SET person = 'NO';
UPDATE call3404n SET person = 'NO';
UPDATE call3405n SET person = 'NO';
UPDATE call3406n SET person = 'NO';
UPDATE call3407n SET person = 'NO';
UPDATE call3408n SET person = 'NO';
UPDATE call3409n SET person = 'NO';
UPDATE call3410n SET person = 'NO';

UPDATE call3901y SET person = 'YES';
UPDATE call3902y SET person = 'YES';
UPDATE call3903y SET person = 'YES';
UPDATE call3904y SET person = 'YES';
UPDATE call3905y SET person = 'YES';
UPDATE call3906y SET person = 'YES';
UPDATE call3907y SET person = 'YES';
UPDATE call3908y SET person = 'YES';
UPDATE call3909y SET person = 'YES';
UPDATE call3910y SET person = 'YES';


UPDATE call3901n SET person = 'NO';
UPDATE call3902n SET person = 'NO';
UPDATE call3903n SET person = 'NO';
UPDATE call3904n SET person = 'NO';
UPDATE call3905n SET person = 'NO';
UPDATE call3906n SET person = 'NO';
UPDATE call3907n SET person = 'NO';
UPDATE call3908n SET person = 'NO';
UPDATE call3909n SET person = 'NO';
UPDATE call3910n SET person = 'NO';


UPDATE call4201y SET person = 'YES';
UPDATE call4202y SET person = 'YES';
UPDATE call4203y SET person = 'YES';
UPDATE call4204y SET person = 'YES';
UPDATE call4205y SET person = 'YES';
UPDATE call4206y SET person = 'YES';
UPDATE call4207y SET person = 'YES';
UPDATE call4208y SET person = 'YES';
UPDATE call4209y SET person = 'YES';
UPDATE call4210y SET person = 'YES';


UPDATE call4201n SET person = 'NO';
UPDATE call4202n SET person = 'NO';
UPDATE call4203n SET person = 'NO';
UPDATE call4204n SET person = 'NO';
UPDATE call4205n SET person = 'NO';
UPDATE call4206n SET person = 'NO';
UPDATE call4207n SET person = 'NO';
UPDATE call4208n SET person = 'NO';
UPDATE call4209n SET person = 'NO';
UPDATE call4210n SET person = 'NO';


UPDATE call4601y SET person = 'YES';
UPDATE call4602y SET person = 'YES';
UPDATE call4603y SET person = 'YES';
UPDATE call4604y SET person = 'YES';
UPDATE call4605y SET person = 'YES';
UPDATE call4606y SET person = 'YES';
UPDATE call4607y SET person = 'YES';
UPDATE call4608y SET person = 'YES';
UPDATE call4609y SET person = 'YES';
UPDATE call4610y SET person = 'YES';


UPDATE call4601n SET person = 'NO';
UPDATE call4602n SET person = 'NO';
UPDATE call4603n SET person = 'NO';
UPDATE call4604n SET person = 'NO';
UPDATE call4605n SET person = 'NO';
UPDATE call4606n SET person = 'NO';
UPDATE call4607n SET person = 'NO';
UPDATE call4608n SET person = 'NO';
UPDATE call4609n SET person = 'NO';
UPDATE call4610n SET person = 'NO';


UPDATE call6601y SET person = 'YES';
UPDATE call6602y SET person = 'YES';
UPDATE call6603y SET person = 'YES';
UPDATE call6604y SET person = 'YES';
UPDATE call6605y SET person = 'YES';
UPDATE call6606y SET person = 'YES';
UPDATE call6607y SET person = 'YES';
UPDATE call6608y SET person = 'YES';
UPDATE call6609y SET person = 'YES';
UPDATE call6610y SET person = 'YES';


UPDATE call6601n SET person = 'NO';
UPDATE call6602n SET person = 'NO';
UPDATE call6603n SET person = 'NO';
UPDATE call6604n SET person = 'NO';
UPDATE call6605n SET person = 'NO';
UPDATE call6606n SET person = 'NO';
UPDATE call6607n SET person = 'NO';
UPDATE call6608n SET person = 'NO';
UPDATE call6609n SET person = 'NO';
UPDATE call6610n SET person = 'NO';


UPDATE call7101y SET person = 'YES';
UPDATE call7102y SET person = 'YES';
UPDATE call7103y SET person = 'YES';
UPDATE call7104y SET person = 'YES';
UPDATE call7105y SET person = 'YES';
UPDATE call7106y SET person = 'YES';
UPDATE call7107y SET person = 'YES';
UPDATE call7108y SET person = 'YES';
UPDATE call7109y SET person = 'YES';
UPDATE call7110y SET person = 'YES';


UPDATE call7101n SET person = 'NO';
UPDATE call7102n SET person = 'NO';
UPDATE call7103n SET person = 'NO';
UPDATE call7104n SET person = 'NO';
UPDATE call7105n SET person = 'NO';
UPDATE call7106n SET person = 'NO';
UPDATE call7107n SET person = 'NO';
UPDATE call7108n SET person = 'NO';
UPDATE call7109n SET person = 'NO';
UPDATE call7110n SET person = 'NO';


UPDATE call7401y SET person = 'YES';
UPDATE call7402y SET person = 'YES';
UPDATE call7403y SET person = 'YES';
UPDATE call7404y SET person = 'YES';
UPDATE call7405y SET person = 'YES';
UPDATE call7406y SET person = 'YES';
UPDATE call7407y SET person = 'YES';
UPDATE call7408y SET person = 'YES';
UPDATE call7409y SET person = 'YES';
UPDATE call7410y SET person = 'YES';


UPDATE call7401n SET person = 'NO';
UPDATE call7402n SET person = 'NO';
UPDATE call7403n SET person = 'NO';
UPDATE call7404n SET person = 'NO';
UPDATE call7405n SET person = 'NO';
UPDATE call7406n SET person = 'NO';
UPDATE call7407n SET person = 'NO';
UPDATE call7408n SET person = 'NO';
UPDATE call7409n SET person = 'NO';
UPDATE call7410n SET person = 'NO';


UPDATE call8301y SET person = 'YES';
UPDATE call8302y SET person = 'YES';
UPDATE call8303y SET person = 'YES';
UPDATE call8304y SET person = 'YES';
UPDATE call8305y SET person = 'YES';
UPDATE call8306y SET person = 'YES';
UPDATE call8307y SET person = 'YES';
UPDATE call8308y SET person = 'YES';
UPDATE call8309y SET person = 'YES';
UPDATE call8310y SET person = 'YES';


UPDATE call8301n SET person = 'NO';
UPDATE call8302n SET person = 'NO';
UPDATE call8303n SET person = 'NO';
UPDATE call8304n SET person = 'NO';
UPDATE call8305n SET person = 'NO';
UPDATE call8306n SET person = 'NO';
UPDATE call8307n SET person = 'NO';
UPDATE call8308n SET person = 'NO';
UPDATE call8309n SET person = 'NO';
UPDATE call8310n SET person = 'NO';


UPDATE call9101y SET person = 'YES';
UPDATE call9102y SET person = 'YES';
UPDATE call9103y SET person = 'YES';
UPDATE call9104y SET person = 'YES';
UPDATE call9105y SET person = 'YES';
UPDATE call9106y SET person = 'YES';
UPDATE call9107y SET person = 'YES';
UPDATE call9108y SET person = 'YES';
UPDATE call9109y SET person = 'YES';
UPDATE call9110y SET person = 'YES';


UPDATE call9101n SET person = 'NO';
UPDATE call9102n SET person = 'NO';
UPDATE call9103n SET person = 'NO';
UPDATE call9104n SET person = 'NO';
UPDATE call9105n SET person = 'NO';
UPDATE call9106n SET person = 'NO';
UPDATE call9107n SET person = 'NO';
UPDATE call9108n SET person = 'NO';
UPDATE call9109n SET person = 'NO';
UPDATE call9110n SET person = 'NO';


UPDATE call9401y SET person = 'YES';
UPDATE call9402y SET person = 'YES';
UPDATE call9403y SET person = 'YES';
UPDATE call9404y SET person = 'YES';
UPDATE call9405y SET person = 'YES';
UPDATE call9406y SET person = 'YES';
UPDATE call9407y SET person = 'YES';
UPDATE call9408y SET person = 'YES';
UPDATE call9409y SET person = 'YES';
UPDATE call9410y SET person = 'YES';


UPDATE call9401n SET person = 'NO';
UPDATE call9402n SET person = 'NO';
UPDATE call9403n SET person = 'NO';
UPDATE call9404n SET person = 'NO';
UPDATE call9405n SET person = 'NO';
UPDATE call9406n SET person = 'NO';
UPDATE call9407n SET person = 'NO';
UPDATE call9408n SET person = 'NO';
UPDATE call9409n SET person = 'NO';
UPDATE call9410n SET person = 'NO';


UPDATE call9501y SET person = 'YES';
UPDATE call9502y SET person = 'YES';
UPDATE call9503y SET person = 'YES';
UPDATE call9504y SET person = 'YES';
UPDATE call9505y SET person = 'YES';
UPDATE call9506y SET person = 'YES';
UPDATE call9507y SET person = 'YES';
UPDATE call9508y SET person = 'YES';
UPDATE call9509y SET person = 'YES';
UPDATE call9510y SET person = 'YES';


UPDATE call9501n SET person = 'NO';
UPDATE call9502n SET person = 'NO';
UPDATE call9503n SET person = 'NO';
UPDATE call9504n SET person = 'NO';
UPDATE call9505n SET person = 'NO';
UPDATE call9506n SET person = 'NO';
UPDATE call9507n SET person = 'NO';
UPDATE call9508n SET person = 'NO';
UPDATE call9509n SET person = 'NO';
UPDATE call9510n SET person = 'NO';

