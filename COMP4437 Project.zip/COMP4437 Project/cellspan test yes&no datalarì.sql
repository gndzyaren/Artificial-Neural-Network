create table if not exists cst13y as(select * from cst1301);
alter table cst13y add person varchar(3);
update cst13y set person='YES';

create table if not exists cst13n as(select * from cst1301);
alter table cst13n add person varchar(3);
update cst13n set person='NO';

create table if not exists cst17y as(select * from cst1701);
alter table cst17y add person varchar(3);
update cst17y set person='YES';

create table if not exists cst17n as(select * from cst1701);
alter table cst17n add person varchar(3);
update cst17n set person='NO';

create table if not exists cst22y as(select * from cst2201);
alter table cst22y add person varchar(3);
update cst22y set person='YES';

create table if not exists cst22n as(select * from cst2201);
alter table cst22n add person varchar(3);
update cst22n set person='NO';

create table if not exists cst23y as(select * from cst2301);
alter table cst23y add person varchar(3);
update cst23y set person='YES';

create table if not exists cst23n as(select * from cst2301);
alter table cst23n add person varchar(3);
update cst23n set person='NO';

create table if not exists cst34y as(select * from cst3401);
alter table cst34y add person varchar(3);
update cst34y set person='YES';

create table if not exists cst34n as(select * from cst3401);
alter table cst34n add person varchar(3);
update cst34n set person='NO';

create table if not exists cst39y as(select * from cst3901);
alter table cst39y add person varchar(3);
update cst39y set person='YES';

create table if not exists cst39n as(select * from cst3901);
alter table cst39n add person varchar(3);
update cst39n set person='NO';

create table if not exists cst42y as(select * from cst4201);
alter table cst42y add person varchar(3);
update cst42y set person='YES';

create table if not exists cst42n as(select * from cst4201);
alter table cst42n add person varchar(3);
update cst42n set person='NO';

create table if not exists cst46y as(select * from cst4601);
alter table cst46y add person varchar(3);
update cst46y set person='YES';

create table if not exists cst46n as(select * from cst4601);
alter table cst46n add person varchar(3);
update cst46n set person='NO';

create table if not exists cst66y as(select * from cst6601);
alter table cst66y add person varchar(3);
update cst66y set person='YES';

create table if not exists cst66n as(select * from cst6601);
alter table cst66n add person varchar(3);
update cst66n set person='NO';

create table if not exists cst71y as(select * from cst7101);
alter table cst71y add person varchar(3);
update cst71y set person='YES';

create table if not exists cst71n as(select * from cst7101);
alter table cst71n add person varchar(3);
update cst71n set person='NO';

create table if not exists cst83y as(select * from cst8301);
alter table cst83y add person varchar(3);
update cst83y set person='YES';

create table if not exists cst83n as(select * from cst8301);
alter table cst83n add person varchar(3);
update cst83n set person='NO';


create table if not exists cst91y as(select * from cst9101);
alter table cst91y add person varchar(3);
update cst91y set person='YES';

create table if not exists cst91n as(select * from cst9101);
alter table cst91n add person varchar(3);
update cst91n set person='NO';

create table if not exists cst94y as(select * from cst9401);
alter table cst94y add person varchar(3);
update cst94y set person='YES';

create table if not exists cst94n as(select * from cst9401);
alter table cst94n add person varchar(3);
update cst94n set person='NO';


create table if not exists cst95y as(select * from cst9501);
alter table cst95y add person varchar(3);
update cst95y set person='YES';

create table if not exists cst95n as(select * from cst9501);
alter table cst95n add person varchar(3);
update cst95n set person='NO';
