ALTER TABLE dspan13a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan13b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan17a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan17b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan95a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan95b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan94a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan94b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan91a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan91b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE dspan83a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan83b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE dspan74a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan74b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan71a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan71b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE dspan66a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan66b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan46a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan46b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan42a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan42b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan39a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan39b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan34a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan34b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan23a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan23b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan22a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE dspan22b
DROP COLUMN starttime,
DROP COLUMN person_oid;



SELECT * FROM dspan22a;
SELECT * FROM dspan22b;
