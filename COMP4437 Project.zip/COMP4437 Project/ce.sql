ALTER TABLE cspan13a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan13b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan17a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan17b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan95a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan95b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan94a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan94b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan91a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan91b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE cspan83a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan83b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE cspan74a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan74b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan71a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan71b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE cspan66a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan66b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan46a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan46b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan42a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan42b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan39a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan39b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan34a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan34b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan23a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan23b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan22a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cspan22b
DROP COLUMN starttime,
DROP COLUMN person_oid;



SELECT * FROM cspan22a;
SELECT * FROM cspan22b;
