create table cs9501y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9502y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9503y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9504y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9505y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9506y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9507y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9508y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9509y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 
create table cs9510y as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 3500; 

create table cs9501n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9502n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9503n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9504n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9505n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9506n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9507n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9508n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9509n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 
create table cs9510n as SELECT * FROM cespan95a ORDER BY RAND() LIMIT 250; 

create table cst9501 as select * from cespan95b ORDER BY RAND() LIMIT 1200;