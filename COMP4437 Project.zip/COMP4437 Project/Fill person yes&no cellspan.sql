SET SQL_SAFE_UPDATES=0;


UPDATE cs1301y SET person = 'YES';
UPDATE cs1302y SET person = 'YES';
UPDATE cs1303y SET person = 'YES';
UPDATE cs1304y SET person = 'YES';
UPDATE cs1305y SET person = 'YES';
UPDATE cs1306y SET person = 'YES';
UPDATE cs1307y SET person = 'YES';
UPDATE cs1308y SET person = 'YES';
UPDATE cs1309y SET person = 'YES';
UPDATE cs1310y SET person = 'YES';


UPDATE cs1301n SET person = 'NO';
UPDATE cs1302n SET person = 'NO';
UPDATE cs1303n SET person = 'NO';
UPDATE cs1304n SET person = 'NO';
UPDATE cs1305n SET person = 'NO';
UPDATE cs1306n SET person = 'NO';
UPDATE cs1307n SET person = 'NO';
UPDATE cs1308n SET person = 'NO';
UPDATE cs1309n SET person = 'NO';
UPDATE cs1310n SET person = 'NO';


UPDATE cs1701y SET person = 'YES';
UPDATE cs1702y SET person = 'YES';
UPDATE cs1703y SET person = 'YES';
UPDATE cs1704y SET person = 'YES';
UPDATE cs1705y SET person = 'YES';
UPDATE cs1706y SET person = 'YES';
UPDATE cs1707y SET person = 'YES';
UPDATE cs1708y SET person = 'YES';
UPDATE cs1709y SET person = 'YES';
UPDATE cs1710y SET person = 'YES';


UPDATE cs1701n SET person = 'NO';
UPDATE cs1702n SET person = 'NO';
UPDATE cs1703n SET person = 'NO';
UPDATE cs1704n SET person = 'NO';
UPDATE cs1705n SET person = 'NO';
UPDATE cs1706n SET person = 'NO';
UPDATE cs1707n SET person = 'NO';
UPDATE cs1708n SET person = 'NO';
UPDATE cs1709n SET person = 'NO';
UPDATE cs1710n SET person = 'NO';


UPDATE cs2201y SET person = 'YES';
UPDATE cs2202y SET person = 'YES';
UPDATE cs2203y SET person = 'YES';
UPDATE cs2204y SET person = 'YES';
UPDATE cs2205y SET person = 'YES';
UPDATE cs2206y SET person = 'YES';
UPDATE cs2207y SET person = 'YES';
UPDATE cs2208y SET person = 'YES';
UPDATE cs2209y SET person = 'YES';
UPDATE cs2210y SET person = 'YES';


UPDATE cs2201n SET person = 'NO';
UPDATE cs2202n SET person = 'NO';
UPDATE cs2203n SET person = 'NO';
UPDATE cs2204n SET person = 'NO';
UPDATE cs2205n SET person = 'NO';
UPDATE cs2206n SET person = 'NO';
UPDATE cs2207n SET person = 'NO';
UPDATE cs2208n SET person = 'NO';
UPDATE cs2209n SET person = 'NO';
UPDATE cs2210n SET person = 'NO';


UPDATE cs2301y SET person = 'YES';
UPDATE cs2302y SET person = 'YES';
UPDATE cs2303y SET person = 'YES';
UPDATE cs2304y SET person = 'YES';
UPDATE cs2305y SET person = 'YES';
UPDATE cs2306y SET person = 'YES';
UPDATE cs2307y SET person = 'YES';
UPDATE cs2308y SET person = 'YES';
UPDATE cs2309y SET person = 'YES';
UPDATE cs2310y SET person = 'YES';


UPDATE cs2301n SET person = 'NO';
UPDATE cs2302n SET person = 'NO';
UPDATE cs2303n SET person = 'NO';
UPDATE cs2304n SET person = 'NO';
UPDATE cs2305n SET person = 'NO';
UPDATE cs2306n SET person = 'NO';
UPDATE cs2307n SET person = 'NO';
UPDATE cs2308n SET person = 'NO';
UPDATE cs2309n SET person = 'NO';
UPDATE cs2310n SET person = 'NO';



UPDATE cs3401y SET person = 'YES';
UPDATE cs3402y SET person = 'YES';
UPDATE cs3403y SET person = 'YES';
UPDATE cs3404y SET person = 'YES';
UPDATE cs3405y SET person = 'YES';
UPDATE cs3406y SET person = 'YES';
UPDATE cs3407y SET person = 'YES';
UPDATE cs3408y SET person = 'YES';
UPDATE cs3409y SET person = 'YES';
UPDATE cs3410y SET person = 'YES';


UPDATE cs3401n SET person = 'NO';
UPDATE cs3402n SET person = 'NO';
UPDATE cs3403n SET person = 'NO';
UPDATE cs3404n SET person = 'NO';
UPDATE cs3405n SET person = 'NO';
UPDATE cs3406n SET person = 'NO';
UPDATE cs3407n SET person = 'NO';
UPDATE cs3408n SET person = 'NO';
UPDATE cs3409n SET person = 'NO';
UPDATE cs3410n SET person = 'NO';

UPDATE cs3901y SET person = 'YES';
UPDATE cs3902y SET person = 'YES';
UPDATE cs3903y SET person = 'YES';
UPDATE cs3904y SET person = 'YES';
UPDATE cs3905y SET person = 'YES';
UPDATE cs3906y SET person = 'YES';
UPDATE cs3907y SET person = 'YES';
UPDATE cs3908y SET person = 'YES';
UPDATE cs3909y SET person = 'YES';
UPDATE cs3910y SET person = 'YES';


UPDATE cs3901n SET person = 'NO';
UPDATE cs3902n SET person = 'NO';
UPDATE cs3903n SET person = 'NO';
UPDATE cs3904n SET person = 'NO';
UPDATE cs3905n SET person = 'NO';
UPDATE cs3906n SET person = 'NO';
UPDATE cs3907n SET person = 'NO';
UPDATE cs3908n SET person = 'NO';
UPDATE cs3909n SET person = 'NO';
UPDATE cs3910n SET person = 'NO';


UPDATE cs4201y SET person = 'YES';
UPDATE cs4202y SET person = 'YES';
UPDATE cs4203y SET person = 'YES';
UPDATE cs4204y SET person = 'YES';
UPDATE cs4205y SET person = 'YES';
UPDATE cs4206y SET person = 'YES';
UPDATE cs4207y SET person = 'YES';
UPDATE cs4208y SET person = 'YES';
UPDATE cs4209y SET person = 'YES';
UPDATE cs4210y SET person = 'YES';


UPDATE cs4201n SET person = 'NO';
UPDATE cs4202n SET person = 'NO';
UPDATE cs4203n SET person = 'NO';
UPDATE cs4204n SET person = 'NO';
UPDATE cs4205n SET person = 'NO';
UPDATE cs4206n SET person = 'NO';
UPDATE cs4207n SET person = 'NO';
UPDATE cs4208n SET person = 'NO';
UPDATE cs4209n SET person = 'NO';
UPDATE cs4210n SET person = 'NO';


UPDATE cs4601y SET person = 'YES';
UPDATE cs4602y SET person = 'YES';
UPDATE cs4603y SET person = 'YES';
UPDATE cs4604y SET person = 'YES';
UPDATE cs4605y SET person = 'YES';
UPDATE cs4606y SET person = 'YES';
UPDATE cs4607y SET person = 'YES';
UPDATE cs4608y SET person = 'YES';
UPDATE cs4609y SET person = 'YES';
UPDATE cs4610y SET person = 'YES';


UPDATE cs4601n SET person = 'NO';
UPDATE cs4602n SET person = 'NO';
UPDATE cs4603n SET person = 'NO';
UPDATE cs4604n SET person = 'NO';
UPDATE cs4605n SET person = 'NO';
UPDATE cs4606n SET person = 'NO';
UPDATE cs4607n SET person = 'NO';
UPDATE cs4608n SET person = 'NO';
UPDATE cs4609n SET person = 'NO';
UPDATE cs4610n SET person = 'NO';


UPDATE cs6601y SET person = 'YES';
UPDATE cs6602y SET person = 'YES';
UPDATE cs6603y SET person = 'YES';
UPDATE cs6604y SET person = 'YES';
UPDATE cs6605y SET person = 'YES';
UPDATE cs6606y SET person = 'YES';
UPDATE cs6607y SET person = 'YES';
UPDATE cs6608y SET person = 'YES';
UPDATE cs6609y SET person = 'YES';
UPDATE cs6610y SET person = 'YES';


UPDATE cs6601n SET person = 'NO';
UPDATE cs6602n SET person = 'NO';
UPDATE cs6603n SET person = 'NO';
UPDATE cs6604n SET person = 'NO';
UPDATE cs6605n SET person = 'NO';
UPDATE cs6606n SET person = 'NO';
UPDATE cs6607n SET person = 'NO';
UPDATE cs6608n SET person = 'NO';
UPDATE cs6609n SET person = 'NO';
UPDATE cs6610n SET person = 'NO';


UPDATE cs7101y SET person = 'YES';
UPDATE cs7102y SET person = 'YES';
UPDATE cs7103y SET person = 'YES';
UPDATE cs7104y SET person = 'YES';
UPDATE cs7105y SET person = 'YES';
UPDATE cs7106y SET person = 'YES';
UPDATE cs7107y SET person = 'YES';
UPDATE cs7108y SET person = 'YES';
UPDATE cs7109y SET person = 'YES';
UPDATE cs7110y SET person = 'YES';


UPDATE cs7101n SET person = 'NO';
UPDATE cs7102n SET person = 'NO';
UPDATE cs7103n SET person = 'NO';
UPDATE cs7104n SET person = 'NO';
UPDATE cs7105n SET person = 'NO';
UPDATE cs7106n SET person = 'NO';
UPDATE cs7107n SET person = 'NO';
UPDATE cs7108n SET person = 'NO';
UPDATE cs7109n SET person = 'NO';
UPDATE cs7110n SET person = 'NO';


UPDATE cs7401y SET person = 'YES';
UPDATE cs7402y SET person = 'YES';
UPDATE cs7403y SET person = 'YES';
UPDATE cs7404y SET person = 'YES';
UPDATE cs7405y SET person = 'YES';
UPDATE cs7406y SET person = 'YES';
UPDATE cs7407y SET person = 'YES';
UPDATE cs7408y SET person = 'YES';
UPDATE cs7409y SET person = 'YES';
UPDATE cs7410y SET person = 'YES';


UPDATE cs7401n SET person = 'NO';
UPDATE cs7402n SET person = 'NO';
UPDATE cs7403n SET person = 'NO';
UPDATE cs7404n SET person = 'NO';
UPDATE cs7405n SET person = 'NO';
UPDATE cs7406n SET person = 'NO';
UPDATE cs7407n SET person = 'NO';
UPDATE cs7408n SET person = 'NO';
UPDATE cs7409n SET person = 'NO';
UPDATE cs7410n SET person = 'NO';


UPDATE cs8301y SET person = 'YES';
UPDATE cs8302y SET person = 'YES';
UPDATE cs8303y SET person = 'YES';
UPDATE cs8304y SET person = 'YES';
UPDATE cs8305y SET person = 'YES';
UPDATE cs8306y SET person = 'YES';
UPDATE cs8307y SET person = 'YES';
UPDATE cs8308y SET person = 'YES';
UPDATE cs8309y SET person = 'YES';
UPDATE cs8310y SET person = 'YES';


UPDATE cs8301n SET person = 'NO';
UPDATE cs8302n SET person = 'NO';
UPDATE cs8303n SET person = 'NO';
UPDATE cs8304n SET person = 'NO';
UPDATE cs8305n SET person = 'NO';
UPDATE cs8306n SET person = 'NO';
UPDATE cs8307n SET person = 'NO';
UPDATE cs8308n SET person = 'NO';
UPDATE cs8309n SET person = 'NO';
UPDATE cs8310n SET person = 'NO';


UPDATE cs9101y SET person = 'YES';
UPDATE cs9102y SET person = 'YES';
UPDATE cs9103y SET person = 'YES';
UPDATE cs9104y SET person = 'YES';
UPDATE cs9105y SET person = 'YES';
UPDATE cs9106y SET person = 'YES';
UPDATE cs9107y SET person = 'YES';
UPDATE cs9108y SET person = 'YES';
UPDATE cs9109y SET person = 'YES';
UPDATE cs9110y SET person = 'YES';


UPDATE cs9101n SET person = 'NO';
UPDATE cs9102n SET person = 'NO';
UPDATE cs9103n SET person = 'NO';
UPDATE cs9104n SET person = 'NO';
UPDATE cs9105n SET person = 'NO';
UPDATE cs9106n SET person = 'NO';
UPDATE cs9107n SET person = 'NO';
UPDATE cs9108n SET person = 'NO';
UPDATE cs9109n SET person = 'NO';
UPDATE cs9110n SET person = 'NO';


UPDATE cs9401y SET person = 'YES';
UPDATE cs9402y SET person = 'YES';
UPDATE cs9403y SET person = 'YES';
UPDATE cs9404y SET person = 'YES';
UPDATE cs9405y SET person = 'YES';
UPDATE cs9406y SET person = 'YES';
UPDATE cs9407y SET person = 'YES';
UPDATE cs9408y SET person = 'YES';
UPDATE cs9409y SET person = 'YES';
UPDATE cs9410y SET person = 'YES';


UPDATE cs9401n SET person = 'NO';
UPDATE cs9402n SET person = 'NO';
UPDATE cs9403n SET person = 'NO';
UPDATE cs9404n SET person = 'NO';
UPDATE cs9405n SET person = 'NO';
UPDATE cs9406n SET person = 'NO';
UPDATE cs9407n SET person = 'NO';
UPDATE cs9408n SET person = 'NO';
UPDATE cs9409n SET person = 'NO';
UPDATE cs9410n SET person = 'NO';


UPDATE cs9501y SET person = 'YES';
UPDATE cs9502y SET person = 'YES';
UPDATE cs9503y SET person = 'YES';
UPDATE cs9504y SET person = 'YES';
UPDATE cs9505y SET person = 'YES';
UPDATE cs9506y SET person = 'YES';
UPDATE cs9507y SET person = 'YES';
UPDATE cs9508y SET person = 'YES';
UPDATE cs9509y SET person = 'YES';
UPDATE cs9510y SET person = 'YES';


UPDATE cs9501n SET person = 'NO';
UPDATE cs9502n SET person = 'NO';
UPDATE cs9503n SET person = 'NO';
UPDATE cs9504n SET person = 'NO';
UPDATE cs9505n SET person = 'NO';
UPDATE cs9506n SET person = 'NO';
UPDATE cs9507n SET person = 'NO';
UPDATE cs9508n SET person = 'NO';
UPDATE cs9509n SET person = 'NO';
UPDATE cs9510n SET person = 'NO';

