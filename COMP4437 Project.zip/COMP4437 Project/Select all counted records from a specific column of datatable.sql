SELECT * FROM mitclean.cspan1;
SELECT person_oid,duration from cspan1 group by person_oid;

SELECT person_oid,count(person_oid) from cspan1 group by person_oid; 
/*Bir kişiye ait bütün verilerein sayısını topluyorum*/