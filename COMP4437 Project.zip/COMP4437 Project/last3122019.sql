SELECT * FROM callspanclean;

CREATE TABLE cspan1 SELECT * FROM callspanclean;
CREATE TABLE  aspan1 SELECT * FROM activityspanclean;
CREATE TABLE cespan1 SELECT * FROM cellspanclean;
CREATE TABLE dspan1 SELECT * FROM devicespanclean;

SELECT * from cespan1;
ALTER TABLE cspan1 ADD dirid int;
ALTER TABLE cspan1 ADD cnid int;
UPDATE cspan1 SET dirid=IF(direction='Outgoing',3,IF(direction='Incoming',2,1));
SET SQL_SAFE_UPDATES=0;
UPDATE cspan1 SET cnid=2 WHERE contact=-1;
UPDATE cspan1 SET cnid=1 WHERE contact!=-1;


UPDATE cspan1 SET wd=1 WHERE dayname(starttime)='Monday';
UPDATE cspan1 SET wd=2 WHERE dayname(starttime)='Tuesday';
UPDATE cspan1 SET wd=3 WHERE dayname(starttime)='Wednesday';
UPDATE cspan1 SET wd=4 WHERE dayname(starttime)='Thursday';  
UPDATE cspan1 SET wd=5 WHERE dayname(starttime)='Friday';
UPDATE cspan1 SET wd=6 WHERE dayname(starttime)='Saturday';
UPDATE cspan1 SET wd=7 WHERE dayname(starttime)='Sunday';
UPDATE cspan1 SET wd=7 WHERE dayname(starttime)='Sunday';

ALTER TABLE cspan1 ADD deid int;
UPDATE cspan1 SET deid=IF(cspan1.description='Voice Call',2,IF(cspan1.description='Short Message',3,1));
ALTER TABLE cspan1 CHANGE COLUMN md mn int;
SELECT * FROM cspan1;
ALTER TABLE cspan1 DROP COLUMN cid,DROP COLUMN dd;
ALTER TABLE cspan1 DROP did,DROP drid;
ALTER TABLE cspan1 DROP cid,DROP COLUMN dd;
SELECT * FROM cspan1;
ALTER TABLE cspan1 ADD COLUMN dd int;
UPDATE cspan1 
    SET dd = (
        SELECT dd
        FROM callspanclean
        WHERE cspan1.oid=callspanclean.oid
    );
    
ALTER TABLE dspan1 CHANGE COLUMN md mn int;

UPDATE dspan1 SET wd=1 WHERE dayname(starttime)='Monday';
UPDATE dspan1 SET wd=2 WHERE dayname(starttime)='Tuesday';
UPDATE dspan1 SET wd=3 WHERE dayname(starttime)='Wednesday';
UPDATE dspan1 SET wd=4 WHERE dayname(starttime)='Thursday';  
UPDATE dspan1 SET wd=5 WHERE dayname(starttime)='Friday';
UPDATE dspan1 SET wd=6 WHERE dayname(starttime)='Saturday';
UPDATE dspan1 SET wd=7 WHERE dayname(starttime)='Sunday';      


SELECT * FROM mitclean.aspan1;
ALTER TABLE aspan1 CHANGE COLUMN md mn int;
SELECT starttime,endtime,dayname(starttime),dayname(endtime),wd FROM aspan1;
UPDATE aspan1 SET wd=1 WHERE dayname(starttime)='Monday';
UPDATE aspan1 SET wd=2 WHERE dayname(starttime)='Tuesday';
UPDATE aspan1 SET wd=3 WHERE dayname(starttime)='Wednesday';
UPDATE aspan1 SET wd=4 WHERE dayname(starttime)='Thursday';  
UPDATE aspan1 SET wd=5 WHERE dayname(starttime)='Friday';
UPDATE aspan1 SET wd=6 WHERE dayname(starttime)='Saturday';
UPDATE aspan1 SET wd=7 WHERE dayname(starttime)='Sunday';


ALTER TABLE cespan1 CHANGE COLUMN md mn int;

UPDATE cespan1 SET wd=1 WHERE dayname(starttime)='Monday';
UPDATE cespan1 SET wd=2 WHERE dayname(starttime)='Tuesday';
UPDATE cespan1 SET wd=3 WHERE dayname(starttime)='Wednesday';
UPDATE cespan1 SET wd=4 WHERE dayname(starttime)='Thursday';  
UPDATE cespan1 SET wd=5 WHERE dayname(starttime)='Friday';
SET SQL_SAFE_UPDATES=0;
UPDATE cespan1 SET wd=6 WHERE dayname(starttime)='Saturday';
SET SQL_SAFE_UPDATES=0;
UPDATE cespan1 SET wd=7 WHERE dayname(starttime)='Sunday';
SELECT starttime,dayname(starttime),wd FROM cespan1;