UPDATE device1301y SET person = 'YES';
UPDATE device1302y SET person = 'YES';
UPDATE device1303y SET person = 'YES';
UPDATE device1304y SET person = 'YES';
UPDATE device1305y SET person = 'YES';
UPDATE device1306y SET person = 'YES';
UPDATE device1307y SET person = 'YES';
UPDATE device1308y SET person = 'YES';
UPDATE device1309y SET person = 'YES';
UPDATE device1310y SET person = 'YES';


UPDATE device1301n SET person = 'NO';
UPDATE device1302n SET person = 'NO';
UPDATE device1303n SET person = 'NO';
UPDATE device1304n SET person = 'NO';
UPDATE device1305n SET person = 'NO';
UPDATE device1306n SET person = 'NO';
UPDATE device1307n SET person = 'NO';
UPDATE device1308n SET person = 'NO';
UPDATE device1309n SET person = 'NO';
UPDATE device1310n SET person = 'NO';


UPDATE device1701y SET person = 'YES';
UPDATE device1702y SET person = 'YES';
UPDATE device1703y SET person = 'YES';
UPDATE device1704y SET person = 'YES';
UPDATE device1705y SET person = 'YES';
UPDATE device1706y SET person = 'YES';
UPDATE device1707y SET person = 'YES';
UPDATE device1708y SET person = 'YES';
UPDATE device1709y SET person = 'YES';
UPDATE device1710y SET person = 'YES';


UPDATE device1701n SET person = 'NO';
UPDATE device1702n SET person = 'NO';
UPDATE device1703n SET person = 'NO';
UPDATE device1704n SET person = 'NO';
UPDATE device1705n SET person = 'NO';
UPDATE device1706n SET person = 'NO';
UPDATE device1707n SET person = 'NO';
UPDATE device1708n SET person = 'NO';
UPDATE device1709n SET person = 'NO';
UPDATE device1710n SET person = 'NO';


UPDATE device2201y SET person = 'YES';
UPDATE device2202y SET person = 'YES';
UPDATE device2203y SET person = 'YES';
UPDATE device2204y SET person = 'YES';
UPDATE device2205y SET person = 'YES';
UPDATE device2206y SET person = 'YES';
UPDATE device2207y SET person = 'YES';
UPDATE device2208y SET person = 'YES';
UPDATE device2209y SET person = 'YES';
UPDATE device2210y SET person = 'YES';


UPDATE device2201n SET person = 'NO';
UPDATE device2202n SET person = 'NO';
UPDATE device2203n SET person = 'NO';
UPDATE device2204n SET person = 'NO';
UPDATE device2205n SET person = 'NO';
UPDATE device2206n SET person = 'NO';
UPDATE device2207n SET person = 'NO';
UPDATE device2208n SET person = 'NO';
UPDATE device2209n SET person = 'NO';
UPDATE device2210n SET person = 'NO';


UPDATE device2301y SET person = 'YES';
UPDATE device2302y SET person = 'YES';
UPDATE device2303y SET person = 'YES';
UPDATE device2304y SET person = 'YES';
UPDATE device2305y SET person = 'YES';
UPDATE device2306y SET person = 'YES';
UPDATE device2307y SET person = 'YES';
UPDATE device2308y SET person = 'YES';
UPDATE device2309y SET person = 'YES';
UPDATE device2310y SET person = 'YES';


UPDATE device2301n SET person = 'NO';
UPDATE device2302n SET person = 'NO';
UPDATE device2303n SET person = 'NO';
UPDATE device2304n SET person = 'NO';
UPDATE device2305n SET person = 'NO';
UPDATE device2306n SET person = 'NO';
UPDATE device2307n SET person = 'NO';
UPDATE device2308n SET person = 'NO';
UPDATE device2309n SET person = 'NO';
UPDATE device2310n SET person = 'NO';



UPDATE device3401y SET person = 'YES';
UPDATE device3402y SET person = 'YES';
UPDATE device3403y SET person = 'YES';
UPDATE device3404y SET person = 'YES';
UPDATE device3405y SET person = 'YES';
UPDATE device3406y SET person = 'YES';
UPDATE device3407y SET person = 'YES';
UPDATE device3408y SET person = 'YES';
UPDATE device3409y SET person = 'YES';
UPDATE device3410y SET person = 'YES';


UPDATE device3401n SET person = 'NO';
UPDATE device3402n SET person = 'NO';
UPDATE device3403n SET person = 'NO';
UPDATE device3404n SET person = 'NO';
UPDATE device3405n SET person = 'NO';
UPDATE device3406n SET person = 'NO';
UPDATE device3407n SET person = 'NO';
UPDATE device3408n SET person = 'NO';
UPDATE device3409n SET person = 'NO';
UPDATE device3410n SET person = 'NO';

UPDATE device3901y SET person = 'YES';
UPDATE device3902y SET person = 'YES';
UPDATE device3903y SET person = 'YES';
UPDATE device3904y SET person = 'YES';
UPDATE device3905y SET person = 'YES';
UPDATE device3906y SET person = 'YES';
UPDATE device3907y SET person = 'YES';
UPDATE device3908y SET person = 'YES';
UPDATE device3909y SET person = 'YES';
UPDATE device3910y SET person = 'YES';


UPDATE device3901n SET person = 'NO';
UPDATE device3902n SET person = 'NO';
UPDATE device3903n SET person = 'NO';
UPDATE device3904n SET person = 'NO';
UPDATE device3905n SET person = 'NO';
UPDATE device3906n SET person = 'NO';
UPDATE device3907n SET person = 'NO';
UPDATE device3908n SET person = 'NO';
UPDATE device3909n SET person = 'NO';
UPDATE device3910n SET person = 'NO';


UPDATE device4201y SET person = 'YES';
UPDATE device4202y SET person = 'YES';
UPDATE device4203y SET person = 'YES';
UPDATE device4204y SET person = 'YES';
UPDATE device4205y SET person = 'YES';
UPDATE device4206y SET person = 'YES';
UPDATE device4207y SET person = 'YES';
UPDATE device4208y SET person = 'YES';
UPDATE device4209y SET person = 'YES';
UPDATE device4210y SET person = 'YES';


UPDATE device4201n SET person = 'NO';
UPDATE device4202n SET person = 'NO';
UPDATE device4203n SET person = 'NO';
UPDATE device4204n SET person = 'NO';
UPDATE device4205n SET person = 'NO';
UPDATE device4206n SET person = 'NO';
UPDATE device4207n SET person = 'NO';
UPDATE device4208n SET person = 'NO';
UPDATE device4209n SET person = 'NO';
UPDATE device4210n SET person = 'NO';


UPDATE device4601y SET person = 'YES';
UPDATE device4602y SET person = 'YES';
UPDATE device4603y SET person = 'YES';
UPDATE device4604y SET person = 'YES';
UPDATE device4605y SET person = 'YES';
UPDATE device4606y SET person = 'YES';
UPDATE device4607y SET person = 'YES';
UPDATE device4608y SET person = 'YES';
UPDATE device4609y SET person = 'YES';
UPDATE device4610y SET person = 'YES';


UPDATE device4601n SET person = 'NO';
UPDATE device4602n SET person = 'NO';
UPDATE device4603n SET person = 'NO';
UPDATE device4604n SET person = 'NO';
UPDATE device4605n SET person = 'NO';
UPDATE device4606n SET person = 'NO';
UPDATE device4607n SET person = 'NO';
UPDATE device4608n SET person = 'NO';
UPDATE device4609n SET person = 'NO';
UPDATE device4610n SET person = 'NO';


UPDATE device6601y SET person = 'YES';
UPDATE device6602y SET person = 'YES';
UPDATE device6603y SET person = 'YES';
UPDATE device6604y SET person = 'YES';
UPDATE device6605y SET person = 'YES';
UPDATE device6606y SET person = 'YES';
UPDATE device6607y SET person = 'YES';
UPDATE device6608y SET person = 'YES';
UPDATE device6609y SET person = 'YES';
UPDATE device6610y SET person = 'YES';


UPDATE device6601n SET person = 'NO';
UPDATE device6602n SET person = 'NO';
UPDATE device6603n SET person = 'NO';
UPDATE device6604n SET person = 'NO';
UPDATE device6605n SET person = 'NO';
UPDATE device6606n SET person = 'NO';
UPDATE device6607n SET person = 'NO';
UPDATE device6608n SET person = 'NO';
UPDATE device6609n SET person = 'NO';
UPDATE device6610n SET person = 'NO';


UPDATE device7101y SET person = 'YES';
UPDATE device7102y SET person = 'YES';
UPDATE device7103y SET person = 'YES';
UPDATE device7104y SET person = 'YES';
UPDATE device7105y SET person = 'YES';
UPDATE device7106y SET person = 'YES';
UPDATE device7107y SET person = 'YES';
UPDATE device7108y SET person = 'YES';
UPDATE device7109y SET person = 'YES';
UPDATE device7110y SET person = 'YES';


UPDATE device7101n SET person = 'NO';
UPDATE device7102n SET person = 'NO';
UPDATE device7103n SET person = 'NO';
UPDATE device7104n SET person = 'NO';
UPDATE device7105n SET person = 'NO';
UPDATE device7106n SET person = 'NO';
UPDATE device7107n SET person = 'NO';
UPDATE device7108n SET person = 'NO';
UPDATE device7109n SET person = 'NO';
UPDATE device7110n SET person = 'NO';


UPDATE device7401y SET person = 'YES';
UPDATE device7402y SET person = 'YES';
UPDATE device7403y SET person = 'YES';
UPDATE device7404y SET person = 'YES';
UPDATE device7405y SET person = 'YES';
UPDATE device7406y SET person = 'YES';
UPDATE device7407y SET person = 'YES';
UPDATE device7408y SET person = 'YES';
UPDATE device7409y SET person = 'YES';
UPDATE device7410y SET person = 'YES';


UPDATE device7401n SET person = 'NO';
UPDATE device7402n SET person = 'NO';
UPDATE device7403n SET person = 'NO';
UPDATE device7404n SET person = 'NO';
UPDATE device7405n SET person = 'NO';
UPDATE device7406n SET person = 'NO';
UPDATE device7407n SET person = 'NO';
UPDATE device7408n SET person = 'NO';
UPDATE device7409n SET person = 'NO';
UPDATE device7410n SET person = 'NO';


UPDATE device8301y SET person = 'YES';
UPDATE device8302y SET person = 'YES';
UPDATE device8303y SET person = 'YES';
UPDATE device8304y SET person = 'YES';
UPDATE device8305y SET person = 'YES';
UPDATE device8306y SET person = 'YES';
UPDATE device8307y SET person = 'YES';
UPDATE device8308y SET person = 'YES';
UPDATE device8309y SET person = 'YES';
UPDATE device8310y SET person = 'YES';


UPDATE device8301n SET person = 'NO';
UPDATE device8302n SET person = 'NO';
UPDATE device8303n SET person = 'NO';
UPDATE device8304n SET person = 'NO';
UPDATE device8305n SET person = 'NO';
UPDATE device8306n SET person = 'NO';
UPDATE device8307n SET person = 'NO';
UPDATE device8308n SET person = 'NO';
UPDATE device8309n SET person = 'NO';
UPDATE device8310n SET person = 'NO';


UPDATE device9101y SET person = 'YES';
UPDATE device9102y SET person = 'YES';
UPDATE device9103y SET person = 'YES';
UPDATE device9104y SET person = 'YES';
UPDATE device9105y SET person = 'YES';
UPDATE device9106y SET person = 'YES';
UPDATE device9107y SET person = 'YES';
UPDATE device9108y SET person = 'YES';
UPDATE device9109y SET person = 'YES';
UPDATE device9110y SET person = 'YES';


UPDATE device9101n SET person = 'NO';
UPDATE device9102n SET person = 'NO';
UPDATE device9103n SET person = 'NO';
UPDATE device9104n SET person = 'NO';
UPDATE device9105n SET person = 'NO';
UPDATE device9106n SET person = 'NO';
UPDATE device9107n SET person = 'NO';
UPDATE device9108n SET person = 'NO';
UPDATE device9109n SET person = 'NO';
UPDATE device9110n SET person = 'NO';


UPDATE device9401y SET person = 'YES';
UPDATE device9402y SET person = 'YES';
UPDATE device9403y SET person = 'YES';
UPDATE device9404y SET person = 'YES';
UPDATE device9405y SET person = 'YES';
UPDATE device9406y SET person = 'YES';
UPDATE device9407y SET person = 'YES';
UPDATE device9408y SET person = 'YES';
UPDATE device9409y SET person = 'YES';
UPDATE device9410y SET person = 'YES';


UPDATE device9401n SET person = 'NO';
UPDATE device9402n SET person = 'NO';
UPDATE device9403n SET person = 'NO';
SET SQL_SAFE_UPDATES=0;

UPDATE device9404n SET person = 'NO';
UPDATE device9405n SET person = 'NO';
UPDATE device9406n SET person = 'NO';
UPDATE device9407n SET person = 'NO';
UPDATE device9408n SET person = 'NO';
UPDATE device9409n SET person = 'NO';
UPDATE device9410n SET person = 'NO';


UPDATE device9501y SET person = 'YES';
UPDATE device9502y SET person = 'YES';
UPDATE device9503y SET person = 'YES';
UPDATE device9504y SET person = 'YES';
UPDATE device9505y SET person = 'YES';
UPDATE device9506y SET person = 'YES';
UPDATE device9507y SET person = 'YES';
UPDATE device9508y SET person = 'YES';
UPDATE device9509y SET person = 'YES';
UPDATE device9510y SET person = 'YES';


UPDATE device9501n SET person = 'NO';
UPDATE device9502n SET person = 'NO';
UPDATE device9503n SET person = 'NO';
UPDATE device9504n SET person = 'NO';
UPDATE device9505n SET person = 'NO';
UPDATE device9506n SET person = 'NO';
UPDATE device9507n SET person = 'NO';
UPDATE device9508n SET person = 'NO';
UPDATE device9509n SET person = 'NO';
UPDATE device9510n SET person = 'NO';

