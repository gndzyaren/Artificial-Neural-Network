ALTER TABLE cespan13a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan13b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan17a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan17b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan95a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan95b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan94a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan94b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan91a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan91b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE cespan83a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan83b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE cespan74a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan74b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan71a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan71b
DROP COLUMN starttime,
DROP COLUMN person_oid;


ALTER TABLE cespan66a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan66b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan46a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan46b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan42a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan42b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan39a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan39b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan34a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan34b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan23a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan23b
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan22a
DROP COLUMN starttime,
DROP COLUMN person_oid;

ALTER TABLE cespan22b
DROP COLUMN starttime,
DROP COLUMN person_oid;



SELECT * FROM cespan22a;
SELECT * FROM cespan22b;
