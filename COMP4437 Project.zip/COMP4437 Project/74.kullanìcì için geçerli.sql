create table if not exists activityt74y as(select * from activityt7401);
alter table activityt74y add person varchar(3);
update activityt74y set person='YES';

create table if not exists activityt74n as(select * from activityt7401);
alter table activityt74n add person varchar(3);
update activityt74n set person='NO';


SELECT * FROM mitclean.call